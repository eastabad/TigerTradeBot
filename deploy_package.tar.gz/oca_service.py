"""
OCA Service - Lifecycle management for OCA (One-Cancels-All) order groups

This service handles:
1. Creating OCA protection after entry fills
2. Handling OCA leg fills (stop/take profit triggers)
3. Cancelling OCA groups for manual closes
4. Paper account daily rebuild of DAY orders
5. Modifying stop prices when TrailingStop adjusts
6. Soft stop protection for Paper accounts in extended hours
"""

import logging
from datetime import datetime
from typing import Optional, Tuple, Dict, Any

logger = logging.getLogger(__name__)


def create_oca_protection_for_entry(
    trade_id: int,
    symbol: str,
    account_type: str,
    quantity: float,
    entry_price: float,
    stop_loss_price: float,
    take_profit_price: float,
    trailing_stop_id: Optional[int] = None,
    position_side: str = 'long'
) -> Tuple[Optional[object], str]:
    """Create OCA protection after an entry order fills.
    
    Args:
        trade_id: Related Trade record ID
        symbol: Stock symbol
        account_type: 'real' or 'paper'
        quantity: Number of shares
        entry_price: Filled entry price
        stop_loss_price: Stop loss price from TradingView signal
        take_profit_price: Take profit price from TradingView signal
        trailing_stop_id: Related TrailingStopPosition ID (optional)
        position_side: 'long' or 'short' (default 'long')
        
    Returns:
        Tuple of (OCAGroup record or None, status message)
    """
    from tiger_client import TigerClient, TigerPaperClient
    from models import OCAGroup
    
    try:
        if account_type == 'paper':
            client = TigerPaperClient()
        else:
            client = TigerClient()
        
        result = client.create_oca_orders_for_position(
            symbol=symbol,
            quantity=quantity,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            entry_price=entry_price,
            trade_id=trade_id,
            trailing_stop_id=trailing_stop_id,
            cancel_existing=True,
            skip_position_check=True,
            position_side=position_side
        )
        
        if result.get('success'):
            oca_group_id = result.get('oca_group_record_id')
            if oca_group_id:
                oca_group = OCAGroup.query.get(oca_group_id)
                logger.info(f"OCA protection created for {symbol}: "
                           f"stop={stop_loss_price}, tp={take_profit_price}, "
                           f"OCAGroup ID={oca_group_id}")
                return oca_group, "created"
            return None, "created_no_record"
        else:
            logger.error(f"Failed to create OCA protection: {result.get('error')}")
            return None, f"failed: {result.get('error')}"
            
    except Exception as e:
        logger.error(f"Error in create_oca_protection_for_entry: {e}")
        return None, f"error: {str(e)}"


def create_oca_protection(
    trailing_stop_id: Optional[int],
    symbol: str,
    side: str,
    quantity: float,
    stop_price: float,
    take_profit_price: float,
    account_type: str,
    trade_id: Optional[int] = None,
    entry_price: Optional[float] = None,
    force_replace: bool = False
) -> Tuple[Optional[object], str]:
    """Create OCA protection for a position with duplicate check.
    
    This is the main entry point for OCA creation from various paths.
    Includes check to prevent duplicate OCA groups for same position.
    Supports trailing_stop_id=None when trailing stop is disabled.
    
    Args:
        trailing_stop_id: Related TrailingStopPosition ID (can be None if TS disabled)
        symbol: Stock symbol
        side: 'long' or 'short'
        quantity: Number of shares
        stop_price: Stop loss price
        take_profit_price: Take profit price
        account_type: 'real' or 'paper'
        trade_id: Related Trade ID (used when trailing_stop_id is None)
        entry_price: Entry price (used when trailing_stop_id is None)
        force_replace: If True, cancel existing ACTIVE OCA and create new one (for scaling/加仓)
        
    Returns:
        Tuple of (OCAGroup record or None, status message)
    """
    from app import db
    from models import OCAGroup, OCAStatus, TrailingStopPosition
    
    try:
        clean_symbol = symbol.replace('[PAPER]', '').strip()
        
        existing_oca = None
        
        if trailing_stop_id:
            existing_oca = OCAGroup.query.filter_by(
                trailing_stop_id=trailing_stop_id,
                status=OCAStatus.ACTIVE
            ).first()
        
        if not existing_oca:
            existing_oca = OCAGroup.query.filter_by(
                symbol=clean_symbol,
                account_type=account_type,
                status=OCAStatus.ACTIVE
            ).first()
        
        if existing_oca:
            if force_replace:
                logger.info(f"🔄 force_replace=True: cancelling existing OCAGroup #{existing_oca.id} for {clean_symbol}/{account_type} "
                           f"(old qty={existing_oca.quantity}, new qty={quantity}, old SL={existing_oca.stop_price}, new SL={stop_price})")
                existing_oca.status = OCAStatus.CANCELLED
                existing_oca.cancelled_at = datetime.utcnow()
                existing_oca.cancel_reason = f"Replaced by scaling: new qty={quantity}, new SL={stop_price}, new TP={take_profit_price}"
                db.session.commit()
            else:
                logger.info(f"OCA protection already exists for {clean_symbol}/{account_type}: OCAGroup #{existing_oca.id}")
                return existing_oca, "already_exists"
        
        resolved_trade_id = trade_id
        resolved_entry_price = entry_price or 0
        
        if trailing_stop_id:
            ts_position = TrailingStopPosition.query.get(trailing_stop_id)
            if ts_position:
                resolved_trade_id = resolved_trade_id or ts_position.trade_id
                resolved_entry_price = resolved_entry_price or ts_position.entry_price
            else:
                logger.warning(f"TrailingStopPosition {trailing_stop_id} not found, proceeding without it")
                trailing_stop_id = None
        
        return create_oca_protection_for_entry(
            trade_id=resolved_trade_id or 0,
            symbol=clean_symbol,
            account_type=account_type,
            quantity=quantity,
            entry_price=resolved_entry_price,
            stop_loss_price=stop_price,
            take_profit_price=take_profit_price,
            trailing_stop_id=trailing_stop_id,
            position_side=side
        )
        
    except Exception as e:
        logger.error(f"Error in create_oca_protection: {e}")
        return None, f"error: {str(e)}"


def on_oca_leg_filled(
    tiger_order_id: str,
    filled_price: float,
    filled_quantity: float,
    realized_pnl: Optional[float] = None,
    commission: Optional[float] = None
) -> Tuple[Optional[object], str]:
    """Handle when an OCA leg (stop or take profit) is filled.
    
    This function:
    1. Identifies which OCAGroup this order belongs to
    2. Updates OCAGroup status (triggered_stop or triggered_tp)
    3. Creates ClosedPosition record
    4. Deactivates TrailingStopPosition
    
    Args:
        tiger_order_id: The filled order's Tiger ID
        filled_price: Fill price
        filled_quantity: Fill quantity
        realized_pnl: Realized P&L from Tiger API
        commission: Commission from Tiger API
        
    Returns:
        Tuple of (OCAGroup or None, status message)
    """
    from app import db
    from models import OCAGroup, OCAStatus, TrailingStopPosition, ExitMethod
    from closed_position_service import create_closed_position
    
    try:
        oca_group = OCAGroup.query.filter(
            (OCAGroup.stop_order_id == tiger_order_id) | 
            (OCAGroup.take_profit_order_id == tiger_order_id)
        ).filter(OCAGroup.status == OCAStatus.ACTIVE).first()
        
        if not oca_group:
            logger.debug(f"No active OCAGroup found for order {tiger_order_id}")
            return None, "not_found"
        
        if tiger_order_id == oca_group.stop_order_id:
            oca_group.status = OCAStatus.TRIGGERED_STOP
            exit_method = ExitMethod.STOP_LOSS
            leg_type = "stop_loss"
            logger.info(f"OCA stop loss triggered for {oca_group.symbol}: ${filled_price}")
        else:
            oca_group.status = OCAStatus.TRIGGERED_TP
            exit_method = ExitMethod.TAKE_PROFIT
            leg_type = "take_profit"
            logger.info(f"OCA take profit triggered for {oca_group.symbol}: ${filled_price}")
        
        oca_group.triggered_order_id = tiger_order_id
        oca_group.triggered_price = filled_price
        oca_group.triggered_at = datetime.utcnow()
        
        if oca_group.trailing_stop_id:
            ts_pos = TrailingStopPosition.query.get(oca_group.trailing_stop_id)
            if ts_pos and ts_pos.is_active:
                ts_pos.is_active = False
                ts_pos.is_triggered = True
                ts_pos.triggered_at = datetime.utcnow()
                ts_pos.triggered_price = filled_price
                ts_pos.trigger_reason = f"OCA {leg_type} triggered"
                logger.info(f"Deactivated TrailingStopPosition {ts_pos.id}")
        
        closed_pos, cp_status = create_closed_position(
            symbol=oca_group.symbol,
            account_type=oca_group.account_type,
            side=oca_group.side,
            exit_price=filled_price,
            exit_quantity=filled_quantity,
            exit_time=datetime.utcnow(),
            exit_method=exit_method,
            exit_order_id=tiger_order_id,
            realized_pnl=realized_pnl,
            commission=commission,
            avg_entry_price=oca_group.entry_price,
            trailing_stop_id=oca_group.trailing_stop_id,
            exit_signal_content=f"OCA {leg_type} triggered at ${filled_price}"
        )
        
        if closed_pos:
            oca_group.closed_position_id = closed_pos.id
            logger.info(f"Created ClosedPosition {closed_pos.id} for OCA trigger")
        
        db.session.commit()
        
        return oca_group, f"{leg_type}_triggered"
        
    except Exception as e:
        logger.error(f"Error handling OCA leg fill for {tiger_order_id}: {e}")
        db.session.rollback()
        return None, f"error: {str(e)}"


def cancel_oca_for_manual_close(
    symbol: str,
    account_type: str
) -> Tuple[int, str]:
    """Cancel active OCA groups when manually closing a position.
    
    Args:
        symbol: Stock symbol
        account_type: 'real' or 'paper'
        
    Returns:
        Tuple of (number of groups cancelled, status message)
    """
    from app import db
    from models import OCAGroup, OCAStatus
    from tiger_client import TigerClient, TigerPaperClient
    
    try:
        active_groups = OCAGroup.query.filter_by(
            symbol=symbol,
            account_type=account_type,
            status=OCAStatus.ACTIVE
        ).all()
        
        if not active_groups:
            logger.debug(f"No active OCA groups found for {symbol} ({account_type})")
            return 0, "no_active_groups"
        
        if account_type == 'paper':
            client = TigerPaperClient()
        else:
            client = TigerClient()
        
        cancelled_count = 0
        for group in active_groups:
            order_ids_to_cancel = []
            if group.stop_order_id:
                order_ids_to_cancel.append(group.stop_order_id)
            if group.take_profit_order_id:
                order_ids_to_cancel.append(group.take_profit_order_id)
            
            for order_id in order_ids_to_cancel:
                try:
                    cancel_result = client.cancel_order(order_id)
                    if cancel_result.get('success'):
                        logger.info(f"Cancelled OCA order {order_id}")
                    else:
                        logger.warning(f"Failed to cancel order {order_id}: {cancel_result.get('error')}")
                except Exception as e:
                    logger.warning(f"Error cancelling order {order_id}: {e}")
            
            group.status = OCAStatus.CANCELLED
            cancelled_count += 1
            logger.info(f"Marked OCAGroup {group.id} as cancelled")
        
        db.session.commit()
        return cancelled_count, f"cancelled_{cancelled_count}_groups"
        
    except Exception as e:
        logger.error(f"Error cancelling OCA groups for {symbol}: {e}")
        db.session.rollback()
        return 0, f"error: {str(e)}"


def update_oca_stop_price(
    oca_group_id: int,
    new_stop_price: float
) -> Tuple[bool, str]:
    """Update the stop price in an active OCA group.
    
    This is called when TrailingStop adjusts the stop price (tier progression).
    We try to modify the existing order; if that fails, cancel and recreate.
    
    Args:
        oca_group_id: OCAGroup record ID
        new_stop_price: New stop loss price
        
    Returns:
        Tuple of (success, status message)
    """
    from app import db
    from models import OCAGroup, OCAStatus
    from tiger_client import TigerClient, TigerPaperClient
    
    try:
        group = OCAGroup.query.get(oca_group_id)
        if not group:
            return False, "group_not_found"
        
        if group.status != OCAStatus.ACTIVE:
            return False, f"group_not_active: {group.status.value}"
        
        new_stop_price = round(new_stop_price, 2)
        new_stop_limit_price = round(new_stop_price * 0.995, 2)
        
        if group.account_type == 'paper':
            client = TigerPaperClient()
        else:
            client = TigerClient()
        
        if group.stop_order_id:
            try:
                modify_result = client.modify_order(
                    order_id=group.stop_order_id,
                    limit_price=new_stop_limit_price,
                    aux_price=new_stop_price
                )
                
                if modify_result.get('success'):
                    group.stop_price = new_stop_price
                    group.stop_limit_price = new_stop_limit_price
                    db.session.commit()
                    logger.info(f"Modified OCA stop order {group.stop_order_id} to ${new_stop_price}")
                    return True, "modified"
                else:
                    logger.warning(f"Modify failed: {modify_result.get('error')}, will recreate")
            except Exception as e:
                logger.warning(f"Modify exception: {e}, will recreate")
        
        logger.info(f"Recreating OCA group with new stop price ${new_stop_price}")
        
        old_stop_id = group.stop_order_id
        old_tp_id = group.take_profit_order_id
        
        try:
            result = client.create_oca_orders_for_position(
                symbol=group.symbol,
                quantity=group.quantity,
                stop_loss_price=new_stop_price,
                take_profit_price=group.take_profit_price,
                entry_price=group.entry_price,
                trade_id=group.trade_id,
                trailing_stop_id=group.trailing_stop_id,
                cancel_existing=True
            )
            
            if result.get('success'):
                group.previous_stop_order_id = old_stop_id
                group.previous_tp_order_id = old_tp_id
                group.stop_order_id = result.get('stop_loss_order_id')
                group.take_profit_order_id = result.get('take_profit_order_id')
                group.stop_price = new_stop_price
                group.stop_limit_price = new_stop_limit_price
                group.rebuild_count += 1
                group.last_rebuild_at = datetime.utcnow()
                
                db.session.commit()
                logger.info(f"Recreated OCA group {group.id} with new stop ${new_stop_price}")
                return True, "recreated"
            else:
                logger.error(f"Failed to recreate OCA: {result.get('error')}")
                return False, f"recreate_failed: {result.get('error')}"
                
        except Exception as e:
            logger.error(f"Error recreating OCA: {e}")
            return False, f"recreate_error: {str(e)}"
        
    except Exception as e:
        logger.error(f"Error updating OCA stop price: {e}")
        db.session.rollback()
        return False, f"error: {str(e)}"


def rebuild_paper_oca_daily(app) -> Dict[str, Any]:
    """Rebuild Paper account OCA orders that expired (DAY orders expire at 20:00 ET).
    Also creates OCA protection for positions that have TrailingStopPosition but no OCAGroup.
    
    This should be scheduled to run before market open each trading day.
    
    Args:
        app: Flask app context
        
    Returns:
        Dict with rebuild statistics
    """
    from models import OCAGroup, OCAStatus, TrailingStopPosition
    from tiger_client import TigerPaperClient
    
    results = {
        'checked': 0,
        'rebuilt': 0,
        'created': 0,
        'failed': 0,
        'skipped': 0,
        'errors': []
    }
    
    try:
        with app.app_context():
            from app import db
            
            active_paper_positions = TrailingStopPosition.query.filter_by(
                account_type='paper',
                is_active=True
            ).all()
            
            active_oca_ts_ids = set(
                g.trailing_stop_id for g in OCAGroup.query.filter_by(
                    account_type='paper',
                    status=OCAStatus.ACTIVE
                ).all() if g.trailing_stop_id
            )
            
            positions_without_oca = [p for p in active_paper_positions if p.id not in active_oca_ts_ids]
            
            if positions_without_oca:
                logger.info(f"Found {len(positions_without_oca)} Paper positions without OCA protection")
                for ts_pos in positions_without_oca:
                    try:
                        symbol = ts_pos.symbol.replace('[PAPER]', '')
                        stop_price = ts_pos.fixed_stop_loss or ts_pos.current_trailing_stop
                        take_profit_price = ts_pos.fixed_take_profit
                        
                        if not stop_price or not take_profit_price:
                            logger.warning(f"Missing stop/TP for {symbol}, skipping OCA creation")
                            results['skipped'] += 1
                            continue
                        
                        position_side = 'long' if ts_pos.quantity > 0 else 'short'
                        oca_group, status = create_oca_protection_for_entry(
                            trade_id=ts_pos.trade_id,
                            symbol=symbol,
                            account_type='paper',
                            quantity=abs(ts_pos.quantity),
                            entry_price=ts_pos.entry_price,
                            stop_loss_price=stop_price,
                            take_profit_price=take_profit_price,
                            trailing_stop_id=ts_pos.id,
                            position_side=position_side
                        )
                        
                        if oca_group and status == "success":
                            results['created'] += 1
                            logger.info(f"Created OCA protection for {symbol} (ts_id={ts_pos.id})")
                        else:
                            results['failed'] += 1
                            results['errors'].append(f"{symbol}: {status}")
                            logger.error(f"Failed to create OCA for {symbol}: {status}")
                            
                    except Exception as e:
                        results['failed'] += 1
                        results['errors'].append(f"{ts_pos.symbol}: {str(e)}")
                        logger.error(f"Error creating OCA for {ts_pos.symbol}: {e}")
            
            active_paper_groups = OCAGroup.query.filter_by(
                account_type='paper',
                status=OCAStatus.ACTIVE
            ).all()
            
            results['checked'] = len(active_paper_groups)
            
            if not active_paper_groups:
                logger.info("No active Paper OCA groups to rebuild")
                return results
            
            client = TigerPaperClient()
            
            for group in active_paper_groups:
                try:
                    positions_result = client.get_positions(group.symbol)
                    if not positions_result.get('success') or not positions_result.get('positions'):
                        logger.info(f"No position for {group.symbol}, marking OCA as expired")
                        group.status = OCAStatus.EXPIRED
                        results['skipped'] += 1
                        continue
                    
                    current_stop_price = group.stop_price
                    if group.trailing_stop_id:
                        ts_pos = TrailingStopPosition.query.get(group.trailing_stop_id)
                        if ts_pos and ts_pos.is_active and ts_pos.fixed_stop_loss:
                            current_stop_price = ts_pos.fixed_stop_loss
                            logger.info(f"Using TrailingStop price ${current_stop_price} for rebuild")
                    
                    old_stop_id = group.stop_order_id
                    old_tp_id = group.take_profit_order_id
                    
                    result = client.create_oca_orders_for_position(
                        symbol=group.symbol,
                        quantity=group.quantity,
                        stop_loss_price=current_stop_price,
                        take_profit_price=group.take_profit_price,
                        entry_price=group.entry_price,
                        trade_id=group.trade_id,
                        trailing_stop_id=group.trailing_stop_id,
                        cancel_existing=True
                    )
                    
                    if result.get('success'):
                        group.previous_stop_order_id = old_stop_id
                        group.previous_tp_order_id = old_tp_id
                        group.stop_order_id = result.get('stop_loss_order_id')
                        group.take_profit_order_id = result.get('take_profit_order_id')
                        group.stop_price = current_stop_price
                        group.rebuild_count += 1
                        group.last_rebuild_at = datetime.utcnow()
                        
                        results['rebuilt'] += 1
                        logger.info(f"Rebuilt Paper OCA for {group.symbol}")
                    else:
                        results['failed'] += 1
                        error_msg = result.get('error', 'Unknown error')
                        results['errors'].append(f"{group.symbol}: {error_msg}")
                        logger.error(f"Failed to rebuild OCA for {group.symbol}: {error_msg}")
                        
                except Exception as e:
                    results['failed'] += 1
                    results['errors'].append(f"{group.symbol}: {str(e)}")
                    logger.error(f"Error rebuilding OCA for {group.symbol}: {e}")
            
            db.session.commit()
            
            logger.info(f"Paper OCA daily rebuild: checked={results['checked']}, "
                       f"rebuilt={results['rebuilt']}, failed={results['failed']}")
            
            return results
            
    except Exception as e:
        logger.error(f"Error in rebuild_paper_oca_daily: {e}")
        results['errors'].append(str(e))
        return results


def trigger_soft_stop(
    oca_group_id: int,
    current_price: float
) -> Tuple[bool, str]:
    """Trigger soft stop protection for Paper account in extended hours.
    
    When price hits stop level during pre/post market (when Tiger stop orders
    don't execute), we manually cancel OCA and send a limit close order.
    
    Args:
        oca_group_id: OCAGroup record ID
        current_price: Current market price that triggered the stop
        
    Returns:
        Tuple of (success, status message)
    """
    from app import db
    from models import OCAGroup, OCAStatus, TrailingStopPosition, ExitMethod
    from tiger_client import TigerPaperClient
    from closed_position_service import create_closed_position
    from order_tracker_service import register_order
    
    try:
        group = OCAGroup.query.get(oca_group_id)
        if not group:
            return False, "group_not_found"
        
        if group.status != OCAStatus.ACTIVE:
            return False, f"group_not_active: {group.status.value}"
        
        if group.account_type != 'paper':
            return False, "not_paper_account"
        
        logger.info(f"Triggering soft stop for {group.symbol} at ${current_price}")
        
        client = TigerPaperClient()
        
        order_ids_to_cancel = []
        if group.stop_order_id:
            order_ids_to_cancel.append(group.stop_order_id)
        if group.take_profit_order_id:
            order_ids_to_cancel.append(group.take_profit_order_id)
        
        for order_id in order_ids_to_cancel:
            try:
                client.cancel_order(order_id)
                logger.info(f"Cancelled OCA order {order_id} for soft stop")
            except Exception as e:
                logger.warning(f"Error cancelling {order_id}: {e}")
        
        action = 'SELL' if group.side == 'long' else 'BUY'
        close_price = round(current_price * (0.998 if action == 'SELL' else 1.002), 2)
        
        close_result = client.place_limit_order(
            symbol=group.symbol,
            action=action,
            quantity=int(group.quantity),
            limit_price=close_price,
            outside_rth=True,
            time_in_force='DAY'
        )
        
        if close_result.get('success'):
            close_order_id = close_result.get('order_id')
            logger.info(f"Soft stop close order placed: {close_order_id} at ${close_price}")
            
            register_order(
                tiger_order_id=str(close_order_id),
                symbol=group.symbol,
                account_type='paper',
                role='exit_trailing',
                side=action,
                quantity=group.quantity,
                order_type='LMT',
                limit_price=close_price,
                trade_id=group.trade_id,
                trailing_stop_id=group.trailing_stop_id
            )
            
            group.status = OCAStatus.SOFT_STOP
            group.triggered_price = current_price
            group.triggered_at = datetime.utcnow()
            
            if group.trailing_stop_id:
                ts_pos = TrailingStopPosition.query.get(group.trailing_stop_id)
                if ts_pos and ts_pos.is_active:
                    ts_pos.is_active = False
                    ts_pos.is_triggered = True
                    ts_pos.triggered_at = datetime.utcnow()
                    ts_pos.triggered_price = current_price
                    ts_pos.trigger_reason = "Soft stop (extended hours)"
            
            db.session.commit()
            return True, f"soft_stop_triggered_order_{close_order_id}"
        else:
            logger.error(f"Failed to place soft stop close order: {close_result.get('error')}")
            return False, f"close_order_failed: {close_result.get('error')}"
        
    except Exception as e:
        logger.error(f"Error triggering soft stop: {e}")
        db.session.rollback()
        return False, f"error: {str(e)}"


def get_active_oca_for_position(symbol: str, account_type: str) -> Optional[object]:
    """Get the active OCA group for a position.
    
    Args:
        symbol: Stock symbol
        account_type: 'real' or 'paper'
        
    Returns:
        OCAGroup record or None
    """
    from models import OCAGroup, OCAStatus
    
    return OCAGroup.query.filter_by(
        symbol=symbol,
        account_type=account_type,
        status=OCAStatus.ACTIVE
    ).first()


def sync_oca_with_tiger(app) -> Dict[str, Any]:
    """Sync OCA group status with Tiger API order status.
    
    This should be called on startup and periodically to ensure
    our records match the actual order status at Tiger.
    
    Args:
        app: Flask app context
        
    Returns:
        Dict with sync statistics
    """
    from models import OCAGroup, OCAStatus
    from tiger_client import TigerClient, TigerPaperClient
    
    results = {
        'checked': 0,
        'synced': 0,
        'expired': 0,
        'errors': []
    }
    
    try:
        with app.app_context():
            from app import db
            
            active_groups = OCAGroup.query.filter_by(status=OCAStatus.ACTIVE).all()
            results['checked'] = len(active_groups)
            
            for group in active_groups:
                try:
                    if group.account_type == 'paper':
                        client = TigerPaperClient()
                    else:
                        client = TigerClient()
                    
                    stop_status = None
                    tp_status = None
                    
                    if group.stop_order_id:
                        stop_result = client.get_order_status(group.stop_order_id)
                        stop_status = stop_result.get('status', '').lower()
                    
                    if group.take_profit_order_id:
                        tp_result = client.get_order_status(group.take_profit_order_id)
                        tp_status = tp_result.get('status', '').lower()
                    
                    if stop_status == 'filled':
                        group.status = OCAStatus.TRIGGERED_STOP
                        group.triggered_order_id = group.stop_order_id
                        group.triggered_at = datetime.utcnow()
                        results['synced'] += 1
                        logger.info(f"Synced OCA {group.id}: stop filled")
                    elif tp_status == 'filled':
                        group.status = OCAStatus.TRIGGERED_TP
                        group.triggered_order_id = group.take_profit_order_id
                        group.triggered_at = datetime.utcnow()
                        results['synced'] += 1
                        logger.info(f"Synced OCA {group.id}: TP filled")
                    elif stop_status in ['expired', 'cancelled'] and tp_status in ['expired', 'cancelled']:
                        group.status = OCAStatus.EXPIRED
                        results['expired'] += 1
                        logger.info(f"Synced OCA {group.id}: both orders expired/cancelled")
                        
                except Exception as e:
                    results['errors'].append(f"OCA {group.id}: {str(e)}")
                    logger.error(f"Error syncing OCA {group.id}: {e}")
            
            db.session.commit()
            
            logger.info(f"OCA sync: checked={results['checked']}, synced={results['synced']}, "
                       f"expired={results['expired']}")
            
            return results
            
    except Exception as e:
        logger.error(f"Error in sync_oca_with_tiger: {e}")
        results['errors'].append(str(e))
        return results
