import threading
import time
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

_scheduler_thread = None
_scheduler_running = False
_last_check_time = None
_last_paper_oca_rebuild_date = None


def is_market_hours():
    """Check if current time is within US market hours (9:30 AM - 4:00 PM ET)"""
    import pytz
    
    try:
        et = pytz.timezone('US/Eastern')
        now = datetime.now(et)
        
        if now.weekday() >= 5:
            return False
        
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        extended_open = now.replace(hour=4, minute=0, second=0, microsecond=0)
        extended_close = now.replace(hour=20, minute=0, second=0, microsecond=0)
        
        return extended_open <= now <= extended_close
    except:
        return True


def check_pending_orders_and_create_trailing_stops(app):
    """Check PENDING orders, if filled create trailing stop positions"""
    try:
        with app.app_context():
            from app import db
            from models import Trade, OrderStatus, TrailingStopPosition, TrailingStopMode
            from tiger_client import TigerClient, TigerPaperClient
            from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
            from datetime import datetime, timedelta
            
            ts_config = get_trailing_stop_config()
            ts_enabled = ts_config.is_enabled
            
            cutoff_time = datetime.utcnow() - timedelta(hours=24)
            pending_trades = Trade.query.filter(
                Trade.status == OrderStatus.PENDING,
                Trade.created_at >= cutoff_time
            ).all()
            
            if not pending_trades:
                return
            
            logger.debug(f"Checking {len(pending_trades)} pending orders for fill status (trailing_stop={'ON' if ts_enabled else 'OFF'})")
            
            for trade in pending_trades:
                try:
                    if not trade.tiger_order_id:
                        continue
                    
                    if trade.account_type == 'paper':
                        tiger_client = TigerPaperClient()
                    else:
                        tiger_client = TigerClient()
                    
                    status_result = tiger_client.get_order_status(trade.tiger_order_id)
                    
                    if not status_result.get('success'):
                        continue
                    
                    tiger_status = status_result.get('status')
                    
                    if tiger_status == 'filled':
                        trade.status = OrderStatus.FILLED
                        filled_price = status_result.get('filled_price', 0)
                        filled_qty = status_result.get('filled_quantity', trade.quantity)
                        
                        if filled_price:
                            trade.filled_price = filled_price
                        if filled_qty:
                            trade.filled_quantity = filled_qty
                        
                        logger.info(f"📦 Order {trade.tiger_order_id} ({trade.symbol}) filled at ${filled_price:.2f}")
                        
                        try:
                            from models import EntrySignalRecord
                            existing_entry = EntrySignalRecord.query.filter_by(
                                entry_order_id=trade.tiger_order_id
                            ).first()
                            
                            if not existing_entry and not getattr(trade, 'is_close_position', False):
                                entry_record = EntrySignalRecord(
                                    symbol=trade.symbol,
                                    account_type=trade.account_type or 'real',
                                    side='long' if trade.side.value == 'buy' else 'short',
                                    entry_time=datetime.utcnow(),
                                    entry_price=filled_price or trade.reference_price or trade.price,
                                    quantity=filled_qty or trade.quantity,
                                    is_scaling=False,
                                    entry_order_id=trade.tiger_order_id,
                                    raw_json=trade.signal_data if hasattr(trade, 'signal_data') else None,
                                    signal_stop_loss=trade.stop_loss_price,
                                    signal_take_profit=trade.take_profit_price
                                )
                                db.session.add(entry_record)
                                db.session.flush()
                                logger.info(f"📝 Created EntrySignalRecord #{entry_record.id} for delayed fill: {trade.symbol}")
                        except Exception as entry_err:
                            logger.error(f"❌ Failed to create EntrySignalRecord for delayed fill: {entry_err}")
                        
                        is_entry = not getattr(trade, 'is_close_position', False)
                        ts_side = 'long' if trade.side.value == 'buy' else 'short'
                        entry_price = filled_price or trade.reference_price or trade.price
                        ts_symbol = trade.symbol
                        clean_symbol = ts_symbol.replace('[PAPER]', '').strip()
                        account_type = trade.account_type or 'real'
                        quantity = filled_qty or trade.quantity
                        trailing_position = None
                        
                        existing_ts = TrailingStopPosition.query.filter_by(
                            trade_id=trade.id,
                            is_active=True
                        ).first()
                        
                        if existing_ts:
                            trailing_position = existing_ts
                        elif is_entry and ts_enabled and entry_price and entry_price > 0:
                            trailing_position = create_trailing_stop_for_trade(
                                trade_id=trade.id,
                                symbol=ts_symbol,
                                side=ts_side,
                                entry_price=entry_price,
                                quantity=quantity,
                                account_type=account_type,
                                fixed_stop_loss=trade.stop_loss_price,
                                fixed_take_profit=trade.take_profit_price,
                                stop_loss_order_id=trade.stop_loss_order_id,
                                take_profit_order_id=trade.take_profit_order_id,
                                mode=TrailingStopMode.BALANCED,
                                timeframe='15'
                            )
                            logger.info(f"🎯 Auto-created trailing stop for {ts_symbol}, side={ts_side}, entry=${entry_price:.2f}")
                        
                        if is_entry and (trade.stop_loss_price or trade.take_profit_price):
                            try:
                                from oca_service import create_oca_protection
                                trailing_stop_id = trailing_position.id if trailing_position else None
                                oca_result, oca_status = create_oca_protection(
                                    trailing_stop_id=trailing_stop_id,
                                    symbol=clean_symbol,
                                    side=ts_side,
                                    quantity=quantity,
                                    stop_price=trade.stop_loss_price,
                                    take_profit_price=trade.take_profit_price,
                                    account_type=account_type
                                )
                                if oca_result:
                                    logger.info(f"✅ OCA protection created for {ts_symbol}: {oca_status}")
                                    if trailing_position:
                                        trailing_position.stop_loss_order_id = oca_result.stop_order_id
                                        trailing_position.take_profit_order_id = oca_result.take_profit_order_id
                                    trade.stop_loss_order_id = oca_result.stop_order_id
                                    trade.take_profit_order_id = oca_result.take_profit_order_id
                                else:
                                    logger.warning(f"⚠️ OCA creation failed for {ts_symbol}: {oca_status}")
                            except Exception as oca_err:
                                logger.error(f"❌ OCA creation error for {ts_symbol}: {oca_err}")
                        
                        if hasattr(trade, 'needs_auto_protection') and trade.needs_auto_protection:
                            try:
                                import json as json_mod
                                protection_info = {}
                                if hasattr(trade, 'protection_info') and trade.protection_info:
                                    protection_info = json_mod.loads(trade.protection_info)
                                
                                sl_price = protection_info.get('stop_loss_price') or trade.stop_loss_price
                                tp_price = protection_info.get('take_profit_price') or trade.take_profit_price
                                
                                if sl_price or tp_price:
                                    has_switched = trailing_position.has_switched_to_trailing if trailing_position else False
                                    tp_for_oca = None if has_switched else tp_price
                                    
                                    from oca_service import create_oca_protection as create_oca_scaling
                                    scaling_ts_id = trailing_position.id if trailing_position else None
                                    oca_result, oca_status = create_oca_scaling(
                                        trailing_stop_id=scaling_ts_id,
                                        symbol=clean_symbol,
                                        side=ts_side,
                                        quantity=quantity,
                                        stop_price=sl_price,
                                        take_profit_price=tp_for_oca,
                                        account_type=account_type,
                                        trade_id=trade.id,
                                        entry_price=entry_price,
                                        force_replace=True
                                    )
                                    
                                    if oca_result:
                                        logger.info(f"✅ Auto-protection applied via scheduler for {ts_symbol}: {oca_status}")
                                        trade.stop_loss_order_id = getattr(oca_result, 'stop_order_id', None)
                                        trade.take_profit_order_id = getattr(oca_result, 'take_profit_order_id', None)
                                        
                                        if trailing_position:
                                            from trailing_stop_engine import update_trailing_stop_on_position_increase
                                            position_result = tiger_client.get_positions(symbol=clean_symbol)
                                            if position_result.get('success') and position_result.get('positions'):
                                                avg_cost = position_result['positions'][0].get('average_cost', 0)
                                                current_qty = abs(position_result['positions'][0]['quantity'])
                                                update_trailing_stop_on_position_increase(
                                                    symbol=trade.symbol,
                                                    account_type=account_type,
                                                    new_quantity=current_qty,
                                                    new_entry_price=avg_cost,
                                                    new_stop_loss_price=sl_price,
                                                    new_take_profit_price=tp_price,
                                                    new_stop_loss_order_id=getattr(oca_result, 'stop_order_id', None),
                                                    new_take_profit_order_id=getattr(oca_result, 'take_profit_order_id', None)
                                                )
                                    else:
                                        logger.error(f"❌ Auto-protection failed via scheduler: {oca_status}")
                                
                                trade.needs_auto_protection = False
                                trade.protection_info = None
                            except Exception as ap_err:
                                logger.error(f"❌ Auto-protection error in scheduler: {ap_err}")
                        
                        db.session.commit()
                    
                    elif tiger_status in ['cancelled', 'rejected', 'expired', 'invalid']:
                        if tiger_status == 'cancelled' or tiger_status == 'expired':
                            trade.status = OrderStatus.CANCELLED
                        else:
                            trade.status = OrderStatus.REJECTED
                        
                        # Record reject/cancel reason from Tiger API
                        reason = status_result.get('reason', '')
                        if reason:
                            trade.error_message = f"Tiger: {reason}"
                            logger.warning(f"⚠️ Order {trade.tiger_order_id} ({trade.symbol}) {tiger_status}: {reason}")
                        else:
                            logger.info(f"📋 Order {trade.tiger_order_id} ({trade.symbol}) status: {tiger_status}")
                        
                        db.session.commit()
                        
                        # Send Discord notification for rejected/cancelled orders
                        try:
                            from discord_notifier import get_discord_notifier
                            notifier = get_discord_notifier()
                            if notifier:
                                status_msg = f"❌ {tiger_status.upper()}"
                                if reason:
                                    status_msg += f" - {reason}"
                                notifier.send_order_notification(trade, status_msg, is_close=False)
                        except Exception as notify_err:
                            logger.debug(f"Discord notification skipped: {notify_err}")
                        
                except Exception as e:
                    logger.error(f"Error checking order {trade.tiger_order_id}: {str(e)}")
                    continue
                    
    except Exception as e:
        logger.error(f"Error in check_pending_orders: {str(e)}")


def cleanup_stale_pending_orders(app):
    """Mark old PENDING orders (>24h) as EXPIRED to keep database clean"""
    try:
        with app.app_context():
            from app import db
            from models import Trade, OrderStatus
            from datetime import datetime, timedelta
            
            cutoff_time = datetime.utcnow() - timedelta(hours=24)
            stale_orders = Trade.query.filter(
                Trade.status == OrderStatus.PENDING,
                Trade.created_at < cutoff_time
            ).all()
            
            if stale_orders:
                for trade in stale_orders:
                    trade.status = OrderStatus.CANCELLED
                    logger.info(f"🧹 Auto-cancelled stale PENDING order: {trade.symbol} (created {trade.created_at})")
                db.session.commit()
                logger.info(f"🧹 Cleaned up {len(stale_orders)} stale PENDING orders")
    except Exception as e:
        logger.error(f"Error in cleanup_stale_pending_orders: {str(e)}")


def check_filled_trades_without_trailing_stop(app):
    """
    Fallback: Check for FILLED trades that don't have an active trailing stop.
    This handles cases where trailing stop creation failed during webhook processing.
    """
    try:
        with app.app_context():
            from app import db
            from models import Trade, OrderStatus, TrailingStopPosition, TrailingStopMode
            from tiger_client import TigerClient, TigerPaperClient
            from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
            from datetime import datetime, timedelta
            
            ts_config = get_trailing_stop_config()
            if not ts_config.is_enabled:
                return
            
            # Only check trades from last 2 days
            cutoff_time = datetime.utcnow() - timedelta(days=2)
            
            # Find FILLED entry trades (not close positions)
            filled_trades = Trade.query.filter(
                Trade.status == OrderStatus.FILLED,
                Trade.created_at >= cutoff_time,
                Trade.is_close_position == False
            ).all()
            
            for trade in filled_trades:
                try:
                    # Check if already has active trailing stop
                    existing_ts = TrailingStopPosition.query.filter_by(
                        trade_id=trade.id,
                        is_active=True
                    ).first()
                    
                    if existing_ts:
                        continue
                    
                    # Also check by symbol
                    existing_by_symbol = TrailingStopPosition.query.filter_by(
                        symbol=trade.symbol,
                        account_type=trade.account_type or 'real',
                        is_active=True
                    ).first()
                    
                    if existing_by_symbol:
                        continue
                    
                    # Check if position still exists in Tiger
                    if trade.account_type == 'paper':
                        tiger_client = TigerPaperClient()
                    else:
                        tiger_client = TigerClient()
                    
                    clean_symbol = trade.symbol.replace('[PAPER]', '').strip()
                    positions = tiger_client.get_positions()
                    
                    if not positions.get('success'):
                        continue
                    
                    position_exists = False
                    for pos in positions.get('positions', []):
                        if pos.get('symbol') == clean_symbol:
                            position_exists = True
                            break
                    
                    if not position_exists:
                        # Position already closed, skip
                        continue
                    
                    # Create trailing stop for this trade
                    ts_side = 'long' if trade.side.value == 'buy' else 'short'
                    entry_price = trade.filled_price or trade.reference_price or trade.price
                    
                    if entry_price and entry_price > 0:
                        trailing_position = create_trailing_stop_for_trade(
                            trade_id=trade.id,
                            symbol=trade.symbol,
                            side=ts_side,
                            entry_price=entry_price,
                            quantity=trade.filled_quantity or trade.quantity,
                            account_type=trade.account_type or 'real',
                            fixed_stop_loss=trade.stop_loss_price,
                            fixed_take_profit=trade.take_profit_price,
                            stop_loss_order_id=trade.stop_loss_order_id,
                            take_profit_order_id=trade.take_profit_order_id,
                            mode=TrailingStopMode.BALANCED,
                            timeframe='15'
                        )
                        logger.info(f"🔧 Created missing trailing stop for FILLED trade: {trade.symbol}, entry=${entry_price:.2f}")
                        
                except Exception as e:
                    logger.error(f"Error checking trade {trade.id}: {str(e)}")
                    continue
                    
    except Exception as e:
        logger.error(f"Error in check_filled_trades_without_trailing_stop: {str(e)}")


def detect_closed_positions_fallback(app):
    """
    Fallback mechanism: Compare active TrailingStopPositions against actual Tiger positions.
    If a position no longer exists in Tiger but is still active in our system,
    create a ClosedPosition record and deactivate the TrailingStopPosition.
    
    This handles cases where:
    - WebSocket order fill event was missed
    - Position was closed via Tiger APP directly
    - Stop loss / take profit triggered but we didn't get the push
    """
    try:
        with app.app_context():
            from app import db
            from models import TrailingStopPosition, ClosedPosition, EntrySignalRecord, ExitMethod
            from tiger_client import TigerClient, TigerPaperClient, get_tiger_quote_client
            
            active_positions = TrailingStopPosition.query.filter_by(is_active=True).all()
            if not active_positions:
                return
            
            real_symbols = set()
            paper_symbols = set()
            for p in active_positions:
                clean_symbol = p.symbol.replace('[PAPER]', '').strip()
                if p.account_type == 'paper':
                    paper_symbols.add(clean_symbol)
                else:
                    real_symbols.add(clean_symbol)
            
            tiger_real_positions = {}
            tiger_paper_positions = {}
            real_api_success = False
            paper_api_success = False
            
            if real_symbols:
                try:
                    real_client = TigerClient()
                    result = real_client.get_positions()
                    if result.get('success'):
                        real_api_success = True
                        for pos in result.get('positions', []):
                            if pos.get('quantity', 0) != 0:
                                tiger_real_positions[pos['symbol']] = pos
                except Exception as e:
                    logger.warning(f"Could not fetch real account positions: {e}")
                    # Continue to check paper account instead of returning
            
            if paper_symbols:
                try:
                    paper_client = TigerPaperClient()
                    result = paper_client.get_positions()
                    if result.get('success'):
                        paper_api_success = True
                        for pos in result.get('positions', []):
                            if pos.get('quantity', 0) != 0:
                                tiger_paper_positions[pos['symbol']] = pos
                except Exception as e:
                    logger.warning(f"Could not fetch paper account positions: {e}")
                    # Continue instead of returning
            
            for trailing_pos in active_positions:
                try:
                    clean_symbol = trailing_pos.symbol.replace('[PAPER]', '').strip()
                    
                    if trailing_pos.account_type == 'paper':
                        tiger_positions = tiger_paper_positions
                        api_success = paper_api_success
                    else:
                        tiger_positions = tiger_real_positions
                        api_success = real_api_success
                    
                    # Skip if API call failed for this account type
                    if not api_success:
                        logger.debug(f"Skipping {trailing_pos.symbol} ({trailing_pos.account_type}): API call failed")
                        continue
                    
                    if clean_symbol not in tiger_positions:
                        # Check 1: ClosedPosition already exists for this trailing_stop_id
                        existing_closed = ClosedPosition.query.filter_by(
                            trailing_stop_id=trailing_pos.id
                        ).first()
                        
                        if existing_closed:
                            trailing_pos.is_active = False
                            trailing_pos.deactivated_at = datetime.utcnow()
                            if not trailing_pos.deactivation_reason:
                                trailing_pos.deactivation_reason = "Position closed (ClosedPosition already exists)"
                            db.session.commit()
                            continue
                        
                        # Check 2: ClosedPosition created recently for same symbol/account (e.g., by webhook signal)
                        # If webhook already closed this position, don't create duplicate
                        from datetime import timedelta
                        time_window = datetime.utcnow() - timedelta(seconds=120)  # 2 minute window
                        recent_closed = ClosedPosition.query.filter(
                            ClosedPosition.symbol == clean_symbol,
                            ClosedPosition.account_type == trailing_pos.account_type,
                            ClosedPosition.created_at >= time_window
                        ).first()
                        
                        if recent_closed:
                            logger.info(f"📊 Fallback: Position {clean_symbol} already has ClosedPosition #{recent_closed.id} "
                                       f"(created {recent_closed.created_at}), just deactivating trailing stop")
                            trailing_pos.is_active = False
                            trailing_pos.deactivated_at = datetime.utcnow()
                            trailing_pos.deactivation_reason = f"Position closed via {recent_closed.exit_method.value if recent_closed.exit_method else 'unknown'} (ClosedPosition #{recent_closed.id})"
                            db.session.commit()
                            continue
                        
                        logger.info(f"📊 Fallback: Detected closed position for {trailing_pos.symbol} ({trailing_pos.account_type})")
                        
                        # Get exit price - prioritize WebSocket cache, fallback to API
                        exit_price = trailing_pos.entry_price  # Default fallback
                        
                        try:
                            from trailing_stop_engine import get_realtime_price_with_websocket_fallback
                            quote_client = get_tiger_quote_client()
                            price_data = get_realtime_price_with_websocket_fallback(clean_symbol, quote_client)
                            if price_data and price_data.get('price'):
                                exit_price = price_data['price']
                                logger.debug(f"📊 Got exit price for {clean_symbol}: ${exit_price:.2f} (source: {price_data.get('source', 'unknown')})")
                        except Exception as e:
                            logger.debug(f"Could not get realtime price for {clean_symbol}: {e}")
                            # Use highest/lowest as fallback
                            if trailing_pos.side == 'long' and trailing_pos.highest_price:
                                exit_price = trailing_pos.highest_price
                            elif trailing_pos.side == 'short' and trailing_pos.lowest_price:
                                exit_price = trailing_pos.lowest_price
                        
                        exit_method = ExitMethod.TRAILING_STOP
                        if trailing_pos.fixed_stop_loss:
                            if trailing_pos.side == 'long' and exit_price <= trailing_pos.fixed_stop_loss * 1.01:
                                exit_method = ExitMethod.STOP_LOSS
                            elif trailing_pos.side == 'short' and exit_price >= trailing_pos.fixed_stop_loss * 0.99:
                                exit_method = ExitMethod.STOP_LOSS
                        if trailing_pos.fixed_take_profit:
                            if trailing_pos.side == 'long' and exit_price >= trailing_pos.fixed_take_profit * 0.99:
                                exit_method = ExitMethod.TAKE_PROFIT
                            elif trailing_pos.side == 'short' and exit_price <= trailing_pos.fixed_take_profit * 1.01:
                                exit_method = ExitMethod.TAKE_PROFIT
                        
                        pnl = None
                        pnl_pct = None
                        if exit_price and trailing_pos.entry_price and trailing_pos.quantity:
                            if trailing_pos.side == 'long':
                                pnl = (exit_price - trailing_pos.entry_price) * trailing_pos.quantity
                            else:
                                pnl = (trailing_pos.entry_price - exit_price) * trailing_pos.quantity
                            pnl_pct = pnl / (trailing_pos.entry_price * trailing_pos.quantity) * 100
                        
                        # Use unified service
                        from closed_position_service import create_closed_position as create_closed_position_service
                        
                        closed_pos, status = create_closed_position_service(
                            symbol=trailing_pos.symbol,
                            account_type=trailing_pos.account_type,
                            side=trailing_pos.side,
                            exit_price=exit_price,
                            exit_quantity=trailing_pos.quantity,
                            exit_time=datetime.utcnow(),
                            exit_method=exit_method,
                            trailing_stop_id=trailing_pos.id,
                            realized_pnl=pnl,
                            avg_entry_price=trailing_pos.entry_price,
                            exit_signal_content=f"Position closed (detected via scheduler fallback, exit_method={exit_method.value})"
                        )
                        
                        trailing_pos.is_active = False
                        trailing_pos.deactivated_at = datetime.utcnow()
                        trailing_pos.deactivation_reason = f"Position closed (scheduler fallback detected, {exit_method.value})"
                        
                        db.session.commit()
                        
                        logger.info(f"📊 Created ClosedPosition #{closed_pos.id} via scheduler fallback: "
                                   f"{trailing_pos.symbol} exit@${exit_price:.2f} method={exit_method.value} "
                                   f"P&L=${pnl:.2f if pnl else 0} ({pnl_pct:.2f if pnl_pct else 0}%), "
                                   f"linked {len(unlinked_entries)} entries")
                        
                except Exception as e:
                    logger.error(f"Error processing fallback for {trailing_pos.symbol}: {str(e)}")
                    db.session.rollback()
                    
    except Exception as e:
        logger.error(f"Error in detect_closed_positions_fallback: {str(e)}")


def check_filled_attached_orders(app):
    """
    Check for filled attached orders (stop loss / take profit) and create ClosedPosition records.
    This handles cases where Tiger's attached orders filled but WebSocket didn't push the event.
    
    Logic:
    1. Query recent filled orders from Tiger API
    2. Find orders that are closing orders (is_open=False) with STOP or LIMIT order_type
    3. Match to entry Trade records via parent_id OR by symbol+time proximity
    4. Create ClosedPosition if not already exists
    """
    try:
        with app.app_context():
            from app import db
            from models import Trade, ClosedPosition, EntrySignalRecord, ExitMethod, OrderStatus, CompletedTrade, TrailingStopPosition
            from tiger_client import TigerClient, TigerPaperClient
            from datetime import datetime, timedelta
            
            # Get filled orders from last 24 hours
            today = datetime.now().strftime('%Y-%m-%d')
            yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
            
            for account_type, client_class in [('real', TigerClient), ('paper', TigerPaperClient)]:
                try:
                    client = client_class()
                    result = client.get_filled_orders(start_date=yesterday, end_date=today)
                    
                    if not result.get('success'):
                        logger.debug(f"Failed to get filled orders for {account_type}: {result.get('error')}")
                        continue
                    
                    orders = result.get('orders', [])
                    logger.debug(f"📋 Checking {len(orders)} filled orders for {account_type} account")
                    
                    for order in orders:
                        try:
                            order_id = str(order.get('order_id', ''))
                            parent_id = order.get('parent_id')
                            symbol = order.get('symbol', '')
                            order_type_str = str(order.get('order_type', '')).upper()
                            is_open = order.get('is_open', True)
                            
                            # Skip opening orders
                            if is_open:
                                continue
                            
                            # IMPROVED: Check if this is a stop/limit closing order (even without parent_id)
                            is_stop_order = 'STOP' in order_type_str or 'STP' in order_type_str
                            is_limit_order = 'LIMIT' in order_type_str or 'LMT' in order_type_str
                            
                            # Skip if not a stop/limit order and no parent_id
                            if not parent_id and not is_stop_order and not is_limit_order:
                                continue
                            
                            # Check if ClosedPosition already exists for this order
                            existing_closed = ClosedPosition.query.filter_by(exit_order_id=order_id).first()
                            if existing_closed:
                                continue
                            
                            # Also check by symbol+time (within 5 minutes)
                            five_min_ago = datetime.utcnow() - timedelta(minutes=5)
                            existing_recent = ClosedPosition.query.filter(
                                ClosedPosition.symbol == symbol,
                                ClosedPosition.account_type == account_type,
                                ClosedPosition.exit_time >= five_min_ago
                            ).first()
                            if existing_recent:
                                continue
                            
                            # Find the parent entry Trade - try multiple methods
                            parent_trade = None
                            
                            # Method 1: Match by parent_id
                            if parent_id:
                                parent_trade = Trade.query.filter_by(tiger_order_id=str(parent_id)).first()
                                if parent_trade:
                                    logger.debug(f"📋 Found parent trade via parent_id: {parent_id}")
                            
                            # Method 2: Match by stop_loss_order_id or take_profit_order_id
                            if not parent_trade:
                                parent_trade = Trade.query.filter(
                                    db.or_(
                                        Trade.stop_loss_order_id == order_id,
                                        Trade.take_profit_order_id == order_id
                                    )
                                ).first()
                                if parent_trade:
                                    logger.debug(f"📋 Found parent trade via sl/tp order_id match: {order_id}")
                            
                            # Method 3: Find active TrailingStopPosition for this symbol
                            trailing_pos = None
                            if not parent_trade:
                                trailing_pos = TrailingStopPosition.query.filter_by(
                                    symbol=symbol,
                                    account_type=account_type,
                                    is_active=True
                                ).first()
                                if trailing_pos:
                                    # Find the entry trade via trailing_stop's trade_id
                                    parent_trade = Trade.query.get(trailing_pos.trade_id) if trailing_pos.trade_id else None
                                    if parent_trade:
                                        logger.debug(f"📋 Found parent trade via TrailingStopPosition: {trailing_pos.id}")
                            
                            # Method 4: Find most recent entry trade for this symbol (fallback)
                            if not parent_trade:
                                parent_trade = Trade.query.filter(
                                    Trade.symbol == symbol,
                                    Trade.is_close_position == False,
                                    Trade.status == OrderStatus.FILLED
                                ).order_by(Trade.created_at.desc()).first()
                                if parent_trade:
                                    logger.debug(f"📋 Found parent trade via symbol fallback: {symbol}")
                            
                            if not parent_trade:
                                logger.debug(f"📋 No parent trade found for {symbol} order {order_id}, skipping")
                                continue
                            
                            # Only process if parent trade was an entry (not a close)
                            if getattr(parent_trade, 'is_close_position', False):
                                continue
                            
                            action = order.get('action', '').upper()
                            avg_fill_price = order.get('avg_fill_price', 0)
                            filled_qty = order.get('filled', 0)
                            realized_pnl = order.get('realized_pnl', 0)
                            commission = order.get('commission', 0)
                            
                            # Determine exit method based on action and entry side
                            if parent_trade.side.value == 'buy':
                                position_side = 'long'
                            else:
                                position_side = 'short'
                            
                            # Get entry price for comparison
                            entry_price = parent_trade.filled_price or parent_trade.price or parent_trade.reference_price
                            
                            # Determine exit method - Priority:
                            # 1. Compare exit price to Trade's stop_loss_price and take_profit_price
                            # 2. Compare exit price to entry price (profit = take_profit, loss = stop_loss)
                            # 3. Use order_type (STOP vs LIMIT) as last resort
                            exit_method = None
                            
                            # Method 1: Check against Trade's stop_loss_price and take_profit_price
                            sl = parent_trade.stop_loss_price
                            tp = parent_trade.take_profit_price
                            
                            if sl and avg_fill_price:
                                # Compare exit price to stop loss price (within 1% tolerance)
                                sl_diff = abs(avg_fill_price - sl) / sl if sl > 0 else float('inf')
                                if sl_diff <= 0.02:  # Within 2% of stop loss price
                                    exit_method = ExitMethod.STOP_LOSS
                                    logger.info(f"📊 Exit price ${avg_fill_price:.2f} matches stop_loss ${sl:.2f} -> STOP_LOSS")
                            
                            if not exit_method and tp and avg_fill_price:
                                # Compare exit price to take profit price (within 1% tolerance)
                                tp_diff = abs(avg_fill_price - tp) / tp if tp > 0 else float('inf')
                                if tp_diff <= 0.02:  # Within 2% of take profit price
                                    exit_method = ExitMethod.TAKE_PROFIT
                                    logger.info(f"📊 Exit price ${avg_fill_price:.2f} matches take_profit ${tp:.2f} -> TAKE_PROFIT")
                            
                            # Method 2: Use realized P&L from Tiger (most accurate)
                            if not exit_method and realized_pnl != 0:
                                if realized_pnl > 0:
                                    exit_method = ExitMethod.TAKE_PROFIT
                                    logger.info(f"📊 Realized P&L ${realized_pnl:.2f} > 0 -> TAKE_PROFIT")
                                else:
                                    exit_method = ExitMethod.STOP_LOSS
                                    logger.info(f"📊 Realized P&L ${realized_pnl:.2f} < 0 -> STOP_LOSS")
                            
                            # Method 3: Compare exit price to entry price
                            if not exit_method and entry_price and avg_fill_price:
                                if position_side == 'long':
                                    if avg_fill_price > entry_price:
                                        exit_method = ExitMethod.TAKE_PROFIT
                                        logger.info(f"📊 Long: exit ${avg_fill_price:.2f} > entry ${entry_price:.2f} -> TAKE_PROFIT")
                                    else:
                                        exit_method = ExitMethod.STOP_LOSS
                                        logger.info(f"📊 Long: exit ${avg_fill_price:.2f} < entry ${entry_price:.2f} -> STOP_LOSS")
                                else:  # short
                                    if avg_fill_price < entry_price:
                                        exit_method = ExitMethod.TAKE_PROFIT
                                        logger.info(f"📊 Short: exit ${avg_fill_price:.2f} < entry ${entry_price:.2f} -> TAKE_PROFIT")
                                    else:
                                        exit_method = ExitMethod.STOP_LOSS
                                        logger.info(f"📊 Short: exit ${avg_fill_price:.2f} > entry ${entry_price:.2f} -> STOP_LOSS")
                            
                            # Method 4: Fallback to order type (least accurate)
                            if not exit_method:
                                if is_stop_order:
                                    exit_method = ExitMethod.STOP_LOSS
                                    logger.info(f"📊 Fallback: Order type {order_type_str} -> STOP_LOSS")
                                elif is_limit_order:
                                    exit_method = ExitMethod.TAKE_PROFIT
                                    logger.info(f"📊 Fallback: Order type {order_type_str} -> TAKE_PROFIT")
                                else:
                                    exit_method = ExitMethod.STOP_LOSS  # Ultimate fallback
                                    logger.info(f"📊 Ultimate fallback -> STOP_LOSS")
                            
                            # Calculate P&L
                            pnl = realized_pnl
                            pnl_pct = None
                            if entry_price and filled_qty and entry_price > 0:
                                if not pnl:
                                    if position_side == 'long':
                                        pnl = (avg_fill_price - entry_price) * filled_qty
                                    else:
                                        pnl = (entry_price - avg_fill_price) * filled_qty
                                pnl_pct = pnl / (entry_price * filled_qty) * 100
                            
                            # CRITICAL FIX: Find related TrailingStopPosition to set trailing_stop_id
                            trailing_stop_id = None
                            trailing_pos = TrailingStopPosition.query.filter_by(
                                symbol=symbol,
                                account_type=account_type,
                                is_active=True
                            ).first()
                            if trailing_pos:
                                trailing_stop_id = trailing_pos.id
                            
                            # Create ClosedPosition using unified service with parent_order_id
                            from closed_position_service import create_closed_position as create_closed_position_service
                            
                            closed_pos, status = create_closed_position_service(
                                symbol=symbol,
                                account_type=account_type,
                                side=position_side,
                                exit_price=avg_fill_price,
                                exit_quantity=filled_qty,
                                exit_time=datetime.utcnow(),
                                exit_method=exit_method,
                                exit_order_id=order_id,
                                parent_order_id=parent_order_id,
                                realized_pnl=pnl,
                                commission=commission,
                                avg_entry_price=entry_price,
                                trailing_stop_id=trailing_stop_id,
                                exit_signal_content=f"Tiger attached order filled ({exit_method.value})",
                                exit_indicator=f"Tiger {exit_method.value.replace('_', ' ').title()}"
                            )
                            
                            # Update CompletedTrade to mark as closed (for Trade Analytics)
                            completed_trade = CompletedTrade.query.filter_by(
                                trade_id=parent_trade.id,
                                is_open=True
                            ).first()
                            
                            if not completed_trade:
                                completed_trade = CompletedTrade.query.filter_by(
                                    symbol=symbol,
                                    account_type=account_type,
                                    is_open=True
                                ).order_by(CompletedTrade.entry_time.asc()).first()
                            
                            if completed_trade:
                                completed_trade.is_open = False
                                completed_trade.exit_time = datetime.utcnow()
                                completed_trade.exit_price = avg_fill_price
                                completed_trade.exit_quantity = filled_qty
                                completed_trade.exit_method = exit_method
                                completed_trade.pnl_amount = pnl
                                completed_trade.pnl_percent = pnl_pct
                                completed_trade.remaining_quantity = 0
                                completed_trade.exited_quantity = (completed_trade.exited_quantity or 0) + filled_qty
                                completed_trade.avg_exit_price = avg_fill_price
                                
                                if completed_trade.entry_time:
                                    hold_seconds = int((datetime.utcnow() - completed_trade.entry_time).total_seconds())
                                    completed_trade.hold_duration_seconds = hold_seconds
                                
                                logger.info(f"📊 Updated CompletedTrade #{completed_trade.id} as closed: {symbol} {exit_method.value}")
                            
                            db.session.commit()
                            
                            logger.info(f"📊 Created ClosedPosition #{closed_pos.id} from attached order: "
                                       f"{symbol} {exit_method.value} @ ${avg_fill_price:.2f}, "
                                       f"P&L=${pnl:.2f if pnl else 0} ({pnl_pct:.2f if pnl_pct else 0}%), "
                                       f"parent_order={parent_id}")
                            
                        except Exception as order_err:
                            logger.error(f"Error processing attached order: {str(order_err)}")
                            db.session.rollback()
                            continue
                            
                except Exception as client_err:
                    logger.warning(f"Could not check {account_type} filled orders: {client_err}")
                    continue
                    
    except Exception as e:
        logger.error(f"Error in check_filled_attached_orders: {str(e)}")


def run_trailing_stop_check(app):
    """Run the trailing stop check with app context"""
    global _last_check_time
    
    try:
        check_pending_orders_and_create_trailing_stops(app)
        cleanup_stale_pending_orders(app)
        check_filled_trades_without_trailing_stop(app)  # Fix missing trailing stops
        detect_closed_positions_fallback(app)
        check_filled_attached_orders(app)
        
        # Poll OrderTracker for pending order status updates
        from order_tracker_service import poll_pending_orders
        poll_pending_orders(app)
        
        with app.app_context():
            from trailing_stop_engine import process_all_active_positions, get_trailing_stop_config
            from models import TrailingStopPosition
            
            config = get_trailing_stop_config()
            if not config.is_enabled:
                logger.debug("Trailing stop system is disabled")
                return
            
            active_count = TrailingStopPosition.query.filter_by(is_active=True).count()
            if active_count == 0:
                logger.debug("No active trailing stop positions to check")
                return
            
            logger.info(f"🔄 Auto-check: Processing {active_count} active trailing stop positions")
            
            results = process_all_active_positions()
            
            _last_check_time = datetime.utcnow()
            
            actions_taken = [r for r in results if r.get('action')]
            if actions_taken:
                logger.info(f"🔄 Auto-check complete: {len(actions_taken)} actions taken")
                for r in actions_taken:
                    logger.info(f"  - {r.get('symbol')}: {r.get('action')} - {r.get('message')}")
            else:
                logger.debug(f"🔄 Auto-check complete: No actions needed")
                
    except Exception as e:
        logger.error(f"Error in trailing stop auto-check: {str(e)}")


def _get_last_paper_oca_rebuild_date(app) -> str:
    """Get last Paper OCA rebuild date from database (persistent storage)"""
    try:
        with app.app_context():
            from models import TradingConfig
            config = TradingConfig.query.first()
            if config and hasattr(config, 'extra_data') and config.extra_data:
                return config.extra_data.get('last_paper_oca_rebuild', '')
    except Exception as e:
        logger.debug(f"Could not get last rebuild date: {e}")
    return ''


def _set_last_paper_oca_rebuild_date(app, date_str: str):
    """Store last Paper OCA rebuild date to database (persistent storage)"""
    try:
        with app.app_context():
            from models import TradingConfig
            from app import db
            config = TradingConfig.query.first()
            if config:
                if not config.extra_data:
                    config.extra_data = {}
                config.extra_data = {**config.extra_data, 'last_paper_oca_rebuild': date_str}
                db.session.commit()
    except Exception as e:
        logger.error(f"Could not save last rebuild date: {e}")


def check_and_rebuild_paper_oca(app, force_check_on_startup: bool = False):
    """
    Check if Paper account DAY orders need to be rebuilt (expired at 20:00 ET daily)
    Run once per day around 9:25 ET (before market open at 9:30)
    Also runs on startup if orders are expired (catch-up logic)
    """
    global _last_paper_oca_rebuild_date
    import pytz
    
    try:
        et = pytz.timezone('US/Eastern')
        now = datetime.now(et)
        today = now.date()
        today_str = today.isoformat()
        
        if now.weekday() >= 5:
            return
        
        if _last_paper_oca_rebuild_date == today:
            return
        
        last_rebuild_str = _get_last_paper_oca_rebuild_date(app)
        if last_rebuild_str == today_str:
            _last_paper_oca_rebuild_date = today
            return
        
        should_rebuild = False
        rebuild_reason = ""
        
        if now.hour == 9 and 20 <= now.minute <= 30:
            should_rebuild = True
            rebuild_reason = f"Scheduled rebuild at {now.strftime('%H:%M:%S')} ET"
        elif force_check_on_startup and now.hour >= 4 and now.hour < 20:
            if not last_rebuild_str or last_rebuild_str < today_str:
                should_rebuild = True
                rebuild_reason = f"Startup catch-up (last rebuild: {last_rebuild_str or 'never'})"
        
        if should_rebuild:
            logger.info(f"📊 Starting Paper OCA daily rebuild: {rebuild_reason}")
            
            with app.app_context():
                from oca_service import rebuild_paper_oca_daily
                results = rebuild_paper_oca_daily(app)
                
                _last_paper_oca_rebuild_date = today
                _set_last_paper_oca_rebuild_date(app, today_str)
                
                if results:
                    success_count = sum(1 for r in results if r[0] is not None)
                    fail_count = sum(1 for r in results if r[0] is None)
                    logger.info(f"✅ Paper OCA daily rebuild completed: {success_count} success, {fail_count} failed")
                else:
                    logger.info(f"📊 Paper OCA daily rebuild: no active positions to rebuild")
                    
    except Exception as e:
        logger.error(f"❌ Paper OCA daily rebuild error: {str(e)}")


def scheduler_loop(app, interval_seconds=5):
    """Background loop that runs checks periodically (default 5 seconds for real-time Tiger data)"""
    global _scheduler_running
    
    logger.info(f"📊 Trailing stop scheduler started (interval: {interval_seconds}s)")
    
    first_run = True
    while _scheduler_running:
        try:
            check_and_rebuild_paper_oca(app, force_check_on_startup=first_run)
            first_run = False
            
            if is_market_hours():
                run_trailing_stop_check(app)
            else:
                logger.debug("Outside market hours, skipping check")
            
            with app.app_context():
                from trailing_stop_engine import get_trailing_stop_config
                config = get_trailing_stop_config()
                interval_seconds = config.check_interval_seconds or 5
            
        except Exception as e:
            logger.error(f"Scheduler loop error: {str(e)}")
        
        for _ in range(interval_seconds):
            if not _scheduler_running:
                break
            time.sleep(1)
    
    logger.info("📊 Trailing stop scheduler stopped")


def start_scheduler(app, interval_seconds=5):
    """Start the background scheduler thread"""
    global _scheduler_thread, _scheduler_running
    
    if _scheduler_running:
        logger.info("Scheduler already running")
        return False
    
    _scheduler_running = True
    _scheduler_thread = threading.Thread(
        target=scheduler_loop,
        args=(app, interval_seconds),
        daemon=True,
        name="TrailingStopScheduler"
    )
    _scheduler_thread.start()
    
    logger.info(f"📊 Started trailing stop scheduler thread")
    return True


def stop_scheduler():
    """Stop the background scheduler"""
    global _scheduler_running
    
    _scheduler_running = False
    logger.info("📊 Stopping trailing stop scheduler...")


def get_scheduler_status():
    """Get current scheduler status"""
    global _scheduler_running, _last_check_time
    
    return {
        'running': _scheduler_running,
        'last_check': _last_check_time.isoformat() if _last_check_time else None
    }


def reconcile_tiger_orders(app, account_type='paper', start_date=None, end_date=None):
    """
    对账函数：基于Tiger历史订单流水对账ClosedPosition和EntrySignalRecord
    
    1. 获取Tiger已成交订单（权威数据源）
    2. 补全缺失的EntrySignalRecord（开仓记录）
    3. 补全缺失的ClosedPosition（平仓记录）
    4. 修正ClosedPosition的exit_method和total_pnl
    5. 关联未匹配的EntrySignalRecord到ClosedPosition
    
    Returns:
        dict: 对账结果统计
    """
    try:
        with app.app_context():
            from app import db
            from models import ClosedPosition, EntrySignalRecord, ExitMethod
            from tiger_client import TigerClient, TigerPaperClient
            from datetime import datetime, timedelta
            
            if not start_date:
                start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
            if not end_date:
                end_date = datetime.now().strftime('%Y-%m-%d')
            
            logger.info(f"📊 Starting reconciliation for {account_type} account from {start_date} to {end_date}")
            
            if account_type == 'paper':
                client = TigerPaperClient()
            else:
                client = TigerClient()
            
            result = client.get_filled_orders(start_date=start_date, end_date=end_date, limit=500)
            
            if not result.get('success'):
                logger.error(f"Failed to get Tiger orders: {result.get('error')}")
                return {'success': False, 'error': result.get('error')}
            
            orders = result.get('orders', [])
            logger.info(f"📊 Retrieved {len(orders)} orders from Tiger API")
            
            stats = {
                'total_orders': len(orders),
                'entries_created': 0,
                'entries_existed': 0,
                'exits_created': 0,
                'exits_existed': 0,
                'exits_updated': 0,
                'entries_linked': 0,
                'errors': []
            }
            
            by_symbol = {}
            for order in orders:
                symbol = order.get('symbol', '')
                if symbol not in by_symbol:
                    by_symbol[symbol] = []
                by_symbol[symbol].append(order)
            
            for symbol, symbol_orders in by_symbol.items():
                try:
                    entries = [o for o in symbol_orders if o.get('is_open') == True]
                    exits = [o for o in symbol_orders if o.get('is_open') == False]
                    
                    entries.sort(key=lambda x: x.get('order_time', 0))
                    exits.sort(key=lambda x: x.get('order_time', 0))
                    
                    for entry in entries:
                        order_id = str(entry.get('order_id', ''))
                        if not order_id:
                            continue
                        
                        existing = EntrySignalRecord.query.filter_by(entry_order_id=order_id).first()
                        if existing:
                            stats['entries_existed'] += 1
                            continue
                        
                        action = entry.get('action', '').upper()
                        side = 'long' if 'BUY' in action else 'short'
                        
                        order_time = entry.get('order_time')
                        entry_time = None
                        if order_time:
                            if isinstance(order_time, (int, float)):
                                entry_time = datetime.fromtimestamp(order_time / 1000)
                            else:
                                entry_time = order_time
                        
                        new_entry = EntrySignalRecord(
                            symbol=symbol,
                            account_type=account_type,
                            entry_time=entry_time,
                            entry_price=entry.get('avg_fill_price', 0),
                            quantity=entry.get('filled', 0),
                            side=side,
                            is_scaling=False,
                            entry_order_id=order_id,
                            raw_json=f"Tiger order: {entry.get('order_type', 'N/A')}",
                            indicator_trigger="Tiger API reconciliation"
                        )
                        db.session.add(new_entry)
                        stats['entries_created'] += 1
                        logger.debug(f"📊 Created EntrySignalRecord for {symbol} order {order_id}")
                    
                    for exit_order in exits:
                        order_id = str(exit_order.get('order_id', ''))
                        if not order_id:
                            continue
                        
                        existing = ClosedPosition.query.filter_by(exit_order_id=order_id).first()
                        
                        action = exit_order.get('action', '').upper()
                        position_side = 'short' if 'BUY' in action else 'long'
                        
                        realized_pnl = exit_order.get('realized_pnl', 0) or 0
                        
                        order_type_str = str(exit_order.get('order_type', '')).upper()
                        is_stop_order = 'STP' in order_type_str or 'STOP' in order_type_str
                        
                        if realized_pnl > 0:
                            exit_method = ExitMethod.TAKE_PROFIT
                        elif realized_pnl < 0:
                            exit_method = ExitMethod.STOP_LOSS
                        elif is_stop_order:
                            exit_method = ExitMethod.TRAILING_STOP
                        else:
                            exit_method = ExitMethod.MANUAL_CLOSE
                        
                        exit_time = None
                        order_time = exit_order.get('order_time')
                        if order_time:
                            if isinstance(order_time, (int, float)):
                                exit_time = datetime.fromtimestamp(order_time / 1000)
                            else:
                                exit_time = order_time
                        
                        if existing:
                            updated = False
                            if existing.total_pnl != realized_pnl and realized_pnl != 0:
                                existing.total_pnl = realized_pnl
                                updated = True
                            if existing.exit_method != exit_method:
                                existing.exit_method = exit_method
                                updated = True
                            if updated:
                                stats['exits_updated'] += 1
                                logger.debug(f"📊 Updated ClosedPosition #{existing.id} for {symbol}")
                            else:
                                stats['exits_existed'] += 1
                            continue
                        
                        unlinked_entries = EntrySignalRecord.query.filter_by(
                            symbol=symbol,
                            account_type=account_type,
                            side=position_side,
                            closed_position_id=None
                        ).order_by(EntrySignalRecord.entry_time.asc()).all()
                        
                        avg_entry_price = None
                        if unlinked_entries:
                            total_cost = sum((e.entry_price or 0) * (e.quantity or 0) for e in unlinked_entries)
                            total_qty = sum(e.quantity or 0 for e in unlinked_entries)
                            if total_qty > 0:
                                avg_entry_price = total_cost / total_qty
                        
                        # Use unified service for reconciliation
                        from closed_position_service import create_closed_position as create_closed_position_service
                        
                        new_closed, status = create_closed_position_service(
                            symbol=symbol,
                            account_type=account_type,
                            side=position_side,
                            exit_price=exit_order.get('avg_fill_price', 0),
                            exit_quantity=exit_order.get('filled', 0),
                            exit_time=exit_time,
                            exit_method=exit_method,
                            exit_order_id=order_id,
                            realized_pnl=realized_pnl,
                            commission=exit_order.get('commission', 0),
                            avg_entry_price=avg_entry_price,
                            exit_signal_content=f"Tiger order: {exit_order.get('order_type', 'N/A')}",
                            exit_indicator="Tiger API"
                        )
                        
                        if new_closed and status == "created":
                            stats['exits_created'] += 1
                            # Count linked entries
                            linked_count = EntrySignalRecord.query.filter_by(closed_position_id=new_closed.id).count()
                            stats['entries_linked'] += linked_count
                            logger.debug(f"📊 Created ClosedPosition for {symbol} order {order_id}, linked {linked_count} entries")
                        
                        if avg_entry_price and exit_price and exit_qty > 0:
                            if position_side == 'long':
                                new_closed.total_pnl_pct = (exit_price - avg_entry_price) / avg_entry_price * 100
                            else:
                                new_closed.total_pnl_pct = (avg_entry_price - exit_price) / avg_entry_price * 100
                    
                except Exception as symbol_err:
                    error_msg = f"Error processing {symbol}: {str(symbol_err)}"
                    logger.error(f"📊 {error_msg}")
                    stats['errors'].append(error_msg)
                    continue
            
            db.session.commit()
            
            logger.info(f"📊 Reconciliation complete: "
                       f"entries created={stats['entries_created']}, "
                       f"exits created={stats['exits_created']}, "
                       f"exits updated={stats['exits_updated']}, "
                       f"entries linked={stats['entries_linked']}")
            
            return {
                'success': True,
                'account_type': account_type,
                'date_range': f"{start_date} to {end_date}",
                'stats': stats
            }
            
    except Exception as e:
        logger.error(f"📊 Reconciliation failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return {'success': False, 'error': str(e)}
