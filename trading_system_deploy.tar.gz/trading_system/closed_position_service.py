"""
Unified ClosedPosition creation service with idempotent handling and FIFO entry matching.

This module provides a single entry point for creating ClosedPosition records,
ensuring consistent behavior across all exit scenarios:
1. WEBHOOK_SIGNAL - TradingView close/flat signal
2. STOP_LOSS - Tiger stop loss order triggered
3. TAKE_PROFIT - Tiger take profit order triggered  
4. TRAILING_STOP - Dynamic trailing stop triggered

Key features:
- Idempotent: Uses exit_order_id to prevent duplicate records
- Entry matching: Links exits to entries via parent_order_id or FIFO
- Contribution P&L: Calculates per-entry profit contribution
"""

import logging
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from app import db
from models import ClosedPosition, EntrySignalRecord, ExitMethod, Trade

logger = logging.getLogger(__name__)


def create_closed_position(
    symbol: str,
    account_type: str,
    side: str,
    exit_price: float,
    exit_quantity: float,
    exit_time: datetime,
    exit_method: ExitMethod,
    exit_order_id: str = None,
    parent_order_id: str = None,
    realized_pnl: float = None,
    commission: float = None,
    avg_entry_price: float = None,
    trailing_stop_id: int = None,
    exit_signal_content: str = None,
    exit_indicator: str = None
) -> Tuple[Optional[ClosedPosition], str]:
    """
    Unified service for creating ClosedPosition with entry matching.
    
    Args:
        symbol: Stock symbol (e.g., 'AAPL')
        account_type: 'real' or 'paper'
        side: Original position side - 'long' or 'short'
        exit_price: Exit fill price
        exit_quantity: Exit quantity
        exit_time: Exit timestamp
        exit_method: ExitMethod enum value
        exit_order_id: Tiger order ID for deduplication (required for idempotency)
        parent_order_id: Parent order ID for precise entry matching
        realized_pnl: Tiger API realized P&L (preferred)
        commission: Tiger API commission/fees
        avg_entry_price: Average entry price (if known)
        trailing_stop_id: Related TrailingStopPosition ID
        exit_signal_content: Exit signal JSON (only for WEBHOOK_SIGNAL)
        exit_indicator: Signal indicator name
        
    Returns:
        Tuple of (ClosedPosition or None, message string)
    """
    try:
        logger.info(f"📋 Creating ClosedPosition: {symbol}/{account_type} {side} "
                   f"exit_price={exit_price}, qty={exit_quantity}, method={exit_method.value}, "
                   f"order_id={exit_order_id}, pnl={realized_pnl}")
        
        if exit_quantity is not None:
            exit_quantity = abs(exit_quantity)
        
        if exit_order_id:
            existing = ClosedPosition.query.filter_by(exit_order_id=exit_order_id).first()
            if existing:
                logger.info(f"⏭️ ClosedPosition already exists for order {exit_order_id}")
                return existing, "already_exists"
        
        if trailing_stop_id and not exit_order_id:
            existing = ClosedPosition.query.filter_by(trailing_stop_id=trailing_stop_id).first()
            if existing:
                logger.info(f"⏭️ ClosedPosition already exists for trailing_stop_id {trailing_stop_id}")
                return existing, "already_exists"
        
        if not exit_order_id:
            from datetime import timedelta
            clean_symbol_check = symbol.replace('[PAPER]', '').strip() if symbol else symbol
            time_window = datetime.utcnow() - timedelta(seconds=60)
            recent_close = ClosedPosition.query.filter(
                ClosedPosition.symbol == clean_symbol_check,
                ClosedPosition.account_type == account_type,
                ClosedPosition.created_at >= time_window
            ).first()
            if recent_close:
                logger.info(f"⏭️ ClosedPosition already exists for {clean_symbol_check}/{account_type} "
                           f"within 60s (id={recent_close.id}, created={recent_close.created_at})")
                return recent_close, "already_exists"
        
        total_pnl_pct = None
        if realized_pnl is not None and avg_entry_price and avg_entry_price > 0 and exit_quantity:
            total_pnl_pct = realized_pnl / (avg_entry_price * exit_quantity) * 100
            logger.info(f"💰 P&L from Tiger API: ${realized_pnl:.2f} ({total_pnl_pct:.2f}%)")
        elif realized_pnl is None and exit_price and avg_entry_price and exit_quantity:
            if side == 'long':
                realized_pnl = (exit_price - avg_entry_price) * exit_quantity
            else:
                realized_pnl = (avg_entry_price - exit_price) * exit_quantity
            if avg_entry_price > 0:
                total_pnl_pct = realized_pnl / (avg_entry_price * exit_quantity) * 100
            logger.info(f"💰 P&L calculated manually: ${realized_pnl:.2f} ({total_pnl_pct or 0:.2f}%) "
                       f"[entry={avg_entry_price}, exit={exit_price}, qty={exit_quantity}]")
        else:
            logger.warning(f"⚠️ Cannot calculate P&L: realized_pnl={realized_pnl}, "
                          f"avg_entry={avg_entry_price}, exit_price={exit_price}, qty={exit_quantity}")
        
        # Clean symbol for matching (remove [PAPER] prefix if present)
        clean_symbol = symbol.replace('[PAPER]', '').strip() if symbol else symbol
        
        # Create ClosedPosition record (use clean symbol for consistency)
        closed_pos = ClosedPosition(
            symbol=clean_symbol,  # Store clean symbol for consistency
            account_type=account_type,
            side=side,
            exit_order_id=exit_order_id,
            exit_time=exit_time,
            exit_price=exit_price,
            exit_quantity=exit_quantity,
            exit_method=exit_method,
            exit_signal_content=exit_signal_content,
            exit_indicator=exit_indicator,
            total_pnl=realized_pnl,
            total_pnl_pct=total_pnl_pct,
            avg_entry_price=avg_entry_price,
            trailing_stop_id=trailing_stop_id,
            commission=commission
        )
        db.session.add(closed_pos)
        db.session.flush()  # Get the ID
        
        # Match entry signals using clean symbol
        matched_entries = _match_entry_signals(
            closed_pos=closed_pos,
            symbol=clean_symbol,
            account_type=account_type,
            side=side,
            exit_quantity=exit_quantity,
            exit_price=exit_price,
            parent_order_id=parent_order_id
        )
        
        # NOTE: Do NOT commit here - let caller manage transaction boundaries
        # This allows atomic updates when caller has other DB operations
        
        logger.info(f"✅ Created ClosedPosition #{closed_pos.id} for {symbol} "
                   f"({exit_method.value}), matched {len(matched_entries)} entries")
        
        return closed_pos, "created"
        
    except Exception as e:
        # NOTE: Do NOT rollback here - let caller manage transaction
        logger.error(f"❌ Failed to create ClosedPosition: {str(e)}")
        import traceback
        traceback.print_exc()
        return None, f"error: {str(e)}"


def _match_entry_signals(
    closed_pos: ClosedPosition,
    symbol: str,
    account_type: str,
    side: str,
    exit_quantity: float,
    exit_price: float,
    parent_order_id: str = None
) -> List[EntrySignalRecord]:
    """
    Match exit to entry signals using precise matching or FIFO.
    
    Matching strategy:
    1. If parent_order_id provided, try precise match first
    2. Otherwise, use FIFO (first-in-first-out) matching
    
    Args:
        closed_pos: The ClosedPosition record to link entries to
        symbol: Stock symbol
        account_type: 'real' or 'paper'
        side: Position side
        exit_quantity: Quantity exited
        exit_price: Exit price for P&L calculation
        parent_order_id: Parent order ID for precise matching
        
    Returns:
        List of matched EntrySignalRecord objects
    """
    matched_entries = []
    
    # Build symbol variants for matching (some entries stored with [PAPER] prefix)
    symbol_variants = [symbol]
    if account_type == 'paper' and not symbol.startswith('[PAPER]'):
        symbol_variants.append(f'[PAPER]{symbol}')
    elif symbol.startswith('[PAPER]'):
        symbol_variants.append(symbol.replace('[PAPER]', '').strip())
    
    # Strategy 1: Precise match via parent_order_id (with symbol/account/side validation)
    if parent_order_id:
        from sqlalchemy import or_
        precise_entry = EntrySignalRecord.query.filter(
            EntrySignalRecord.entry_order_id == str(parent_order_id),
            or_(*[EntrySignalRecord.symbol == s for s in symbol_variants]),
            EntrySignalRecord.account_type == account_type,
            EntrySignalRecord.side == side,
            EntrySignalRecord.closed_position_id == None
        ).first()
        
        if precise_entry:
            _link_entry_to_exit(precise_entry, closed_pos, exit_price)
            matched_entries.append(precise_entry)
            logger.info(f"🎯 Precise match: Entry #{precise_entry.id} -> Exit #{closed_pos.id}")
            return matched_entries
    
    # Strategy 2: FIFO matching (check both symbol variants)
    from sqlalchemy import or_
    unlinked_entries = EntrySignalRecord.query.filter(
        or_(*[EntrySignalRecord.symbol == s for s in symbol_variants]),
        EntrySignalRecord.account_type == account_type,
        EntrySignalRecord.side == side,
        EntrySignalRecord.closed_position_id == None
    ).order_by(EntrySignalRecord.entry_time.asc()).all()
    
    if not unlinked_entries:
        logger.warning(f"⚠️ No unlinked entries found for {symbol}/{account_type}/{side}")
        return matched_entries
    
    remaining_qty = exit_quantity
    
    for entry in unlinked_entries:
        if remaining_qty <= 0:
            break
            
        entry_qty = entry.quantity or 0
        matched_qty = min(entry_qty, remaining_qty)
        
        if matched_qty > 0:
            _link_entry_to_exit(entry, closed_pos, exit_price, matched_qty)
            matched_entries.append(entry)
            remaining_qty -= matched_qty
            
            logger.info(f"📊 FIFO match: Entry #{entry.id} (qty={entry_qty}) -> Exit #{closed_pos.id}")
    
    if remaining_qty > 0.01:
        logger.warning(f"⚠️ Unmatched exit quantity: {remaining_qty} for {symbol}")
    
    return matched_entries


def _link_entry_to_exit(
    entry: EntrySignalRecord,
    closed_pos: ClosedPosition,
    exit_price: float,
    matched_qty: float = None
) -> None:
    """
    Link an EntrySignalRecord to a ClosedPosition and calculate contribution P&L.
    
    Args:
        entry: EntrySignalRecord to link
        closed_pos: ClosedPosition to link to
        exit_price: Exit price for P&L calculation
        matched_qty: Quantity matched (None = full entry quantity)
    """
    entry.closed_position_id = closed_pos.id
    
    entry_price = entry.entry_price or 0
    qty = matched_qty if matched_qty else (entry.quantity or 0)
    
    if entry_price > 0 and qty > 0 and exit_price > 0:
        if entry.side == 'long':
            contribution_pnl = (exit_price - entry_price) * qty
        else:
            contribution_pnl = (entry_price - exit_price) * qty
            
        entry.contribution_pnl = contribution_pnl
        
        if entry_price > 0:
            entry.contribution_pct = (contribution_pnl / (entry_price * qty)) * 100
    
    logger.debug(f"Linked entry #{entry.id} to exit #{closed_pos.id}, "
                f"contribution_pnl={entry.contribution_pnl}")


def get_entry_signal_for_order(order_id: str) -> Optional[EntrySignalRecord]:
    """Get EntrySignalRecord by Tiger order ID"""
    return EntrySignalRecord.query.filter_by(entry_order_id=str(order_id)).first()


def get_trade_signal_data(order_id: str) -> Optional[str]:
    """
    Get original signal JSON from Trade table by order ID.
    Used when WebSocket creates EntrySignalRecord but needs raw_json.
    """
    trade = Trade.query.filter_by(tiger_order_id=str(order_id)).first()
    if trade and trade.signal_data:
        return trade.signal_data
    return None


def determine_exit_method(
    realized_pnl: float = None,
    order_type: str = None,
    is_trailing_stop: bool = False,
    is_webhook_signal: bool = False,
    stop_order_id: str = None,
    take_profit_order_id: str = None,
    exit_order_id: str = None
) -> ExitMethod:
    """
    Determine ExitMethod based on available information.
    
    Priority:
    1. Explicit flags (is_webhook_signal, is_trailing_stop)
    2. Order ID matching (stop_order_id, take_profit_order_id)
    3. realized_pnl sign (positive = TAKE_PROFIT, negative = STOP_LOSS)
    4. Fallback to STOP_LOSS
    
    Args:
        realized_pnl: Tiger API realized P&L
        order_type: Order type string
        is_trailing_stop: Flag if this is a trailing stop exit
        is_webhook_signal: Flag if this is a webhook close signal
        stop_order_id: Stop loss order ID
        take_profit_order_id: Take profit order ID
        exit_order_id: The exit order ID
        
    Returns:
        ExitMethod enum value
    """
    if is_webhook_signal:
        logger.debug(f"ExitMethod determined: WEBHOOK_SIGNAL (explicit flag)")
        return ExitMethod.WEBHOOK_SIGNAL
    
    if is_trailing_stop:
        logger.debug(f"ExitMethod determined: TRAILING_STOP (explicit flag)")
        return ExitMethod.TRAILING_STOP
    
    if exit_order_id:
        if stop_order_id and str(exit_order_id) == str(stop_order_id):
            logger.debug(f"ExitMethod determined: STOP_LOSS (order ID match: {exit_order_id})")
            return ExitMethod.STOP_LOSS
        if take_profit_order_id and str(exit_order_id) == str(take_profit_order_id):
            logger.debug(f"ExitMethod determined: TAKE_PROFIT (order ID match: {exit_order_id})")
            return ExitMethod.TAKE_PROFIT
    
    if realized_pnl is not None:
        method = ExitMethod.TAKE_PROFIT if realized_pnl >= 0 else ExitMethod.STOP_LOSS
        logger.debug(f"ExitMethod determined: {method.value} (pnl sign: ${realized_pnl})")
        return method
    
    logger.debug(f"ExitMethod determined: STOP_LOSS (fallback)")
    return ExitMethod.STOP_LOSS
