"""
WebSocket Push Event Handlers
Handles order fills, position changes, and quote updates from Tiger WebSocket
"""
import logging
from datetime import datetime
from typing import Dict, Optional, Any

from app import db
from models import (
    Trade, TrailingStopPosition, EntrySignalRecord, ClosedPosition,
    CompletedTrade, OrderStatus, ExitMethod, OCAGroup, OCAStatus
)

logger = logging.getLogger(__name__)


def handle_order_fill(order_data: Any) -> None:
    """
    Handle order fill event from WebSocket
    Creates EntrySignalRecord for entry orders, ClosedPosition for exit orders
    """
    try:
        symbol = getattr(order_data, 'symbol', None) or getattr(order_data, 'contract', {}).get('symbol')
        order_id = str(getattr(order_data, 'id', None) or getattr(order_data, 'order_id', ''))
        status = getattr(order_data, 'status', None)
        action = getattr(order_data, 'action', None)
        # Get parent_id for attached orders (stop loss / take profit)
        parent_id = getattr(order_data, 'parent_id', None) or getattr(order_data, 'parentId', None)
        if parent_id:
            parent_id = str(parent_id)
        # Try multiple field names for filled quantity (Tiger SDK uses different names)
        filled_quantity = (
            getattr(order_data, 'filledQuantity', 0) or 
            getattr(order_data, 'filled_quantity', 0) or 
            getattr(order_data, 'filled', 0) or
            getattr(order_data, 'totalQuantity', 0)  # Fallback to total if order is filled
        )
        avg_fill_price = (
            getattr(order_data, 'avgFillPrice', 0) or 
            getattr(order_data, 'avg_fill_price', 0)
        )
        realized_pnl = getattr(order_data, 'realized_pnl', 0) or getattr(order_data, 'realizedPnl', 0)
        commission = getattr(order_data, 'commission', 0) or getattr(order_data, 'commissionAndFee', 0)
        account = str(getattr(order_data, 'account', ''))
        
        if hasattr(status, 'value'):
            status = status.value
        if hasattr(action, 'value'):
            action = action.value
        
        # Normalize status to string for comparison
        status_str = str(status).upper() if status else ''
        
        logger.info(f"📋 Processing order event: {symbol} {action} status={status} filled={filled_quantity} @ ${avg_fill_price}")
        
        # Check for FILLED status (case-insensitive)
        if status_str != 'FILLED':
            logger.debug(f"Order {order_id} not filled yet, status={status}")
            return
        
        account_type = 'paper' if '2165530' in account else 'real'
        
        is_sell = action and action.upper() in ['SELL', 'SELL_OPEN', 'SELL_CLOSE']
        is_buy = action and action.upper() in ['BUY', 'BUY_OPEN', 'BUY_CLOSE']
        
        trade = Trade.query.filter_by(tiger_order_id=order_id).first()
        
        if trade:
            trade.status = OrderStatus.FILLED
            trade.filled_price = avg_fill_price
            trade.filled_quantity = filled_quantity
            
            if hasattr(trade, 'is_close_position') and trade.is_close_position:
                _create_closed_position_from_websocket(
                    trade=trade,
                    account_type=account_type,
                    exit_price=avg_fill_price,
                    exit_quantity=filled_quantity,
                    realized_pnl=realized_pnl,
                    commission=commission
                )
            else:
                _create_entry_signal_from_websocket(
                    trade=trade,
                    account_type=account_type,
                    filled_price=avg_fill_price,
                    filled_quantity=filled_quantity
                )
                
                if hasattr(trade, 'needs_auto_protection') and trade.needs_auto_protection:
                    _handle_auto_protection_from_websocket(
                        trade=trade,
                        account_type=account_type,
                        filled_price=avg_fill_price,
                        filled_quantity=filled_quantity
                    )
            
            db.session.commit()
            logger.info(f"✅ Updated trade #{trade.id} from WebSocket: filled @ ${avg_fill_price}")
        else:
            # Trade not found - may be stop loss / take profit order triggered by Tiger
            # Try to match with active TrailingStopPosition or by parent_id
            _handle_external_close_order(
                symbol=symbol,
                order_id=order_id,
                account_type=account_type,
                is_sell=is_sell,
                is_buy=is_buy,
                avg_fill_price=avg_fill_price,
                filled_quantity=filled_quantity,
                realized_pnl=realized_pnl,
                commission=commission,
                parent_order_id=parent_id
            )
            
    except Exception as e:
        logger.error(f"❌ Error handling order fill: {str(e)}")
        db.session.rollback()


def _handle_auto_protection_from_websocket(
    trade: Trade,
    account_type: str,
    filled_price: float,
    filled_quantity: float
) -> None:
    """Handle needs_auto_protection when entry order fills via WebSocket.
    This covers the case where routes.py 1-second poll missed the fill.
    Creates/updates OCA protection for the position (scaling/position increase).
    Routes through oca_service for centralized dedup and OCAGroup record creation.
    """
    try:
        import json
        protection_info = {}
        if hasattr(trade, 'protection_info') and trade.protection_info:
            protection_info = json.loads(trade.protection_info)
        
        stop_loss_price = protection_info.get('stop_loss_price') or trade.stop_loss_price
        take_profit_price = protection_info.get('take_profit_price') or trade.take_profit_price
        
        if not stop_loss_price and not take_profit_price:
            logger.warning(f"⚠️ needs_auto_protection set but no SL/TP prices for {trade.symbol}")
            trade.needs_auto_protection = False
            return
        
        from models import TrailingStopPosition
        existing_ts = TrailingStopPosition.query.filter_by(
            symbol=trade.symbol, account_type=account_type, is_active=True
        ).first()
        has_switched = existing_ts.has_switched_to_trailing if existing_ts else False
        
        take_profit_for_oca = None if has_switched else take_profit_price
        if has_switched:
            logger.info(f"🔄 {trade.symbol} already switched to dynamic trailing, only creating stop loss for scaling")
        
        clean_symbol = trade.symbol.replace('[PAPER]', '').strip()
        ts_side = 'long' if trade.side and trade.side.value == 'buy' else 'short'
        trailing_stop_id = existing_ts.id if existing_ts else None
        
        from oca_service import create_oca_protection
        oca_result, oca_status = create_oca_protection(
            trailing_stop_id=trailing_stop_id,
            symbol=clean_symbol,
            side=ts_side,
            quantity=filled_quantity,
            stop_price=stop_loss_price,
            take_profit_price=take_profit_for_oca,
            account_type=account_type,
            trade_id=trade.id,
            entry_price=filled_price,
            force_replace=True
        )
        
        if oca_result:
            logger.info(f"✅ Auto-protection applied via WebSocket for {trade.symbol}: {oca_status}")
            if hasattr(oca_result, 'stop_order_id'):
                trade.stop_loss_order_id = oca_result.stop_order_id
            if hasattr(oca_result, 'take_profit_order_id'):
                trade.take_profit_order_id = oca_result.take_profit_order_id
            
            if existing_ts:
                try:
                    from trailing_stop_engine import update_trailing_stop_on_position_increase
                    
                    if account_type == 'paper':
                        from tiger_client import TigerPaperClient
                        tiger_client = TigerPaperClient()
                    else:
                        from tiger_client import TigerClient
                        tiger_client = TigerClient()
                    
                    position_result = tiger_client.get_positions(symbol=clean_symbol)
                    if position_result.get('success') and position_result.get('positions'):
                        avg_cost = position_result['positions'][0].get('average_cost', 0)
                        current_quantity = abs(position_result['positions'][0]['quantity'])
                        
                        ts_update = update_trailing_stop_on_position_increase(
                            symbol=trade.symbol,
                            account_type=account_type,
                            new_quantity=current_quantity,
                            new_entry_price=avg_cost,
                            new_stop_loss_price=stop_loss_price,
                            new_take_profit_price=take_profit_price,
                            new_stop_loss_order_id=getattr(oca_result, 'stop_order_id', None),
                            new_take_profit_order_id=getattr(oca_result, 'take_profit_order_id', None)
                        )
                        if ts_update.get('success'):
                            logger.info(f"✅ TrailingStop updated after scaling via WebSocket: {ts_update['message']}")
                        else:
                            logger.warning(f"⚠️ TrailingStop update after scaling: {ts_update.get('message')}")
                except Exception as ts_err:
                    logger.error(f"❌ TrailingStop update error after scaling: {ts_err}")
        else:
            logger.error(f"❌ Auto-protection failed via WebSocket: {oca_status}")
        
        trade.needs_auto_protection = False
        trade.protection_info = None
        
    except Exception as e:
        logger.error(f"❌ Error handling auto-protection from WebSocket: {str(e)}")


def _create_entry_signal_from_websocket(
    trade: Trade,
    account_type: str,
    filled_price: float,
    filled_quantity: float
) -> Optional[EntrySignalRecord]:
    """Create EntrySignalRecord when entry order is filled via WebSocket"""
    try:
        existing = EntrySignalRecord.query.filter_by(entry_order_id=trade.tiger_order_id).first()
        if existing:
            logger.info(f"📊 EntrySignalRecord already exists for order {trade.tiger_order_id}")
            return existing
        
        # Get raw JSON from Trade.signal_data
        raw_json = trade.signal_data if trade.signal_data else None
        
        # Parse signal grades from the original signal
        signal_grades = {}
        if raw_json:
            try:
                from signal_analyzer import parse_signal_grades
                signal_grades = parse_signal_grades(raw_json) or {}
            except Exception as e:
                logger.warning(f"Failed to parse signal grades: {e}")
        
        # Get signal_log_id from Trade's signal_logs relationship
        signal_log_id = None
        if trade.signal_logs:
            first_log = trade.signal_logs[0] if len(trade.signal_logs) > 0 else None
            if first_log:
                signal_log_id = first_log.id
        
        entry_record = EntrySignalRecord(
            symbol=trade.symbol,
            account_type=account_type,
            side='long' if trade.side and trade.side.value == 'buy' else 'short',
            entry_order_id=trade.tiger_order_id,
            entry_time=datetime.utcnow(),
            entry_price=filled_price,
            quantity=filled_quantity,
            raw_json=raw_json,
            signal_log_id=signal_log_id,
            indicator_trigger=signal_grades.get('signal_indicator'),
            signal_grade=signal_grades.get('signal_grade'),
            signal_score=signal_grades.get('signal_score'),
            htf_grade=signal_grades.get('htf_grade'),
            htf_score=signal_grades.get('htf_score'),
            timeframe=signal_grades.get('signal_timeframe'),
            signal_stop_loss=trade.stop_loss_price,
            signal_take_profit=trade.take_profit_price
        )
        db.session.add(entry_record)
        db.session.flush()
        
        logger.info(f"📊 Created EntrySignalRecord #{entry_record.id} from WebSocket fill "
                   f"(raw_json={'YES' if raw_json else 'NO'})")
        
        # Also create trailing stop if not exists
        _create_trailing_stop_from_websocket(trade, account_type, filled_price, filled_quantity)
        
        # Also create CompletedTrade if not exists (for Trade Analytics)
        _create_completed_trade_from_websocket(trade, account_type, filled_price, filled_quantity)
        
        return entry_record
        
    except Exception as e:
        logger.error(f"❌ Failed to create EntrySignalRecord from WebSocket: {str(e)}")
        return None


def _create_trailing_stop_from_websocket(
    trade: Trade,
    account_type: str,
    filled_price: float,
    filled_quantity: float
) -> None:
    """Create TrailingStopPosition when entry order is filled via WebSocket.
    Even if trailing stop is disabled, OCA protection is still created when SL/TP prices exist.
    """
    try:
        from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
        from models import TrailingStopPosition, TrailingStopMode
        
        ts_config = get_trailing_stop_config()
        ts_side = 'long' if trade.side and trade.side.value == 'buy' else 'short'
        clean_symbol = trade.symbol.replace('[PAPER]', '').strip()
        trailing_position = None
        
        if not ts_config.is_enabled:
            logger.debug("Trailing stop disabled, skipping TrailingStopPosition creation from WebSocket")
        else:
            existing_ts = TrailingStopPosition.query.filter_by(
                trade_id=trade.id,
                is_active=True
            ).first()
            
            if existing_ts:
                logger.debug(f"Trailing stop already exists for trade {trade.id}")
                trailing_position = existing_ts
            else:
                existing_by_symbol = TrailingStopPosition.query.filter_by(
                    symbol=trade.symbol,
                    account_type=account_type,
                    is_active=True
                ).first()
                
                if existing_by_symbol:
                    logger.debug(f"Trailing stop already exists for symbol {trade.symbol}")
                    trailing_position = existing_by_symbol
                else:
                    trailing_position = create_trailing_stop_for_trade(
                        trade_id=trade.id,
                        symbol=trade.symbol,
                        side=ts_side,
                        entry_price=filled_price,
                        quantity=filled_quantity,
                        account_type=account_type,
                        fixed_stop_loss=trade.stop_loss_price,
                        fixed_take_profit=trade.take_profit_price,
                        stop_loss_order_id=trade.stop_loss_order_id,
                        take_profit_order_id=trade.take_profit_order_id,
                        mode=TrailingStopMode.BALANCED,
                        timeframe='15'
                    )
                    logger.info(f"🎯 Created trailing stop from WebSocket: {trade.symbol}, entry=${filled_price:.2f}")
        
        if trade.stop_loss_price or trade.take_profit_price:
            try:
                from oca_service import create_oca_protection
                trailing_stop_id = trailing_position.id if trailing_position else None
                oca_result, oca_status = create_oca_protection(
                    trailing_stop_id=trailing_stop_id,
                    symbol=clean_symbol,
                    side=ts_side,
                    quantity=filled_quantity,
                    stop_price=trade.stop_loss_price,
                    take_profit_price=trade.take_profit_price,
                    account_type=account_type
                )
                if oca_result:
                    logger.info(f"✅ OCA protection created from WebSocket for {trade.symbol}: {oca_status}")
                    if trailing_position:
                        trailing_position.stop_loss_order_id = oca_result.stop_order_id
                        trailing_position.take_profit_order_id = oca_result.take_profit_order_id
                    trade.stop_loss_order_id = oca_result.stop_order_id
                    trade.take_profit_order_id = oca_result.take_profit_order_id
                    db.session.commit()
                else:
                    logger.warning(f"⚠️ OCA creation failed from WebSocket for {trade.symbol}: {oca_status}")
            except Exception as oca_err:
                logger.error(f"❌ OCA creation error from WebSocket for {trade.symbol}: {oca_err}")
        
    except Exception as e:
        logger.error(f"❌ Failed to create trailing stop from WebSocket: {str(e)}")


def _create_completed_trade_from_websocket(
    trade: Trade,
    account_type: str,
    filled_price: float,
    filled_quantity: float
) -> None:
    """Create CompletedTrade when entry order is filled via WebSocket (for Trade Analytics)"""
    try:
        # Check if already exists
        existing = CompletedTrade.query.filter_by(trade_id=trade.id).first()
        if existing:
            logger.debug(f"CompletedTrade already exists for trade {trade.id}")
            return
        
        # Also check by symbol and approximate time
        existing_by_symbol = CompletedTrade.query.filter_by(
            symbol=trade.symbol,
            account_type=account_type,
            is_open=True
        ).first()
        
        if existing_by_symbol:
            logger.debug(f"Open CompletedTrade already exists for symbol {trade.symbol}")
            return
        
        ts_side = 'long' if trade.side and trade.side.value == 'buy' else 'short'
        
        completed_trade = CompletedTrade(
            symbol=trade.symbol,
            account_type=account_type,
            entry_signal_content=trade.signal_data,
            entry_time=datetime.utcnow(),
            entry_price=filled_price,
            entry_quantity=filled_quantity,
            side=ts_side,
            original_stop_loss=trade.stop_loss_price,
            original_take_profit=trade.take_profit_price,
            trade_id=trade.id,
            is_open=True,
            remaining_quantity=filled_quantity,
            exited_quantity=0
        )
        db.session.add(completed_trade)
        db.session.flush()
        
        logger.info(f"📊 Created CompletedTrade #{completed_trade.id} from WebSocket fill for {trade.symbol}")
        
    except Exception as e:
        logger.error(f"❌ Failed to create CompletedTrade from WebSocket: {str(e)}")


def _update_completed_trades_on_close(
    symbol: str,
    account_type: str,
    position_side: str,
    exit_price: float,
    exit_quantity: float,
    exit_method: ExitMethod,
    realized_pnl: float = None,
    trailing_stop_id: int = None,
    entry_trade: Trade = None,
    active_position: TrailingStopPosition = None
) -> int:
    """
    Update ALL open CompletedTrade records for a position when it's closed.
    This handles both single-entry and multi-entry (scaling) scenarios.
    
    Returns number of CompletedTrade records updated.
    """
    try:
        clean_symbol = symbol.replace('[PAPER]', '').strip() if symbol else symbol
        symbol_variants = [clean_symbol]
        if account_type == 'paper':
            symbol_variants.append(f'[PAPER]{clean_symbol}')
        
        from sqlalchemy import or_
        open_trades = CompletedTrade.query.filter(
            or_(*[CompletedTrade.symbol == s for s in symbol_variants]),
            CompletedTrade.account_type == account_type,
            CompletedTrade.side == position_side,
            CompletedTrade.is_open == True
        ).order_by(CompletedTrade.entry_time.asc()).all()
        
        if not open_trades:
            logger.warning(f"⚠️ No open CompletedTrade found for {symbol}/{account_type}/{position_side}")
            return 0
        
        updated_count = 0
        for ct in open_trades:
            ct.is_open = False
            ct.exit_time = datetime.utcnow()
            ct.exit_price = exit_price
            per_entry_qty = ct.entry_quantity or exit_quantity
            ct.exit_quantity = per_entry_qty
            ct.exit_method = exit_method
            
            if active_position:
                ct.final_stop_loss = active_position.current_trailing_stop
                ct.highest_price = active_position.highest_price
                ct.lowest_price = active_position.lowest_price
            
            if ct.entry_price and exit_price:
                if position_side == 'long':
                    ct.pnl_amount = (exit_price - ct.entry_price) * per_entry_qty
                    ct.pnl_percent = ((exit_price - ct.entry_price) / ct.entry_price) * 100
                else:
                    ct.pnl_amount = (ct.entry_price - exit_price) * per_entry_qty
                    ct.pnl_percent = ((ct.entry_price - exit_price) / ct.entry_price) * 100
            
            if realized_pnl and len(open_trades) == 1:
                ct.pnl_amount = realized_pnl
            
            ct.remaining_quantity = 0
            ct.exited_quantity = per_entry_qty
            ct.avg_exit_price = exit_price
            
            if ct.entry_time:
                hold_seconds = int((datetime.utcnow() - ct.entry_time).total_seconds())
                ct.hold_duration_seconds = hold_seconds
            
            updated_count += 1
            logger.info(f"📊 Updated CompletedTrade #{ct.id} as closed: {ct.symbol} {exit_method.value} "
                       f"pnl=${ct.pnl_amount or 0:.2f}")
        
        logger.info(f"📊 Total {updated_count} CompletedTrade records closed for {symbol}/{account_type}")
        return updated_count
        
    except Exception as e:
        logger.error(f"❌ Failed to update CompletedTrade on close: {str(e)}")
        return 0


def _create_closed_position_from_websocket(
    trade: Trade,
    account_type: str,
    exit_price: float,
    exit_quantity: float,
    realized_pnl: float = None,
    commission: float = None
) -> Optional[ClosedPosition]:
    """Create ClosedPosition when exit order is filled via WebSocket using unified service"""
    try:
        from closed_position_service import create_closed_position as create_closed_position_service
        
        orig_side = 'long' if trade.side and trade.side.value == 'sell' else 'short'
        avg_entry_price = getattr(trade, 'entry_avg_cost', None)
        
        # Get exit signal content from trade if available
        exit_signal_content = trade.signal_data if trade.signal_data else None
        
        # Call unified service
        closed_pos, status = create_closed_position_service(
            symbol=trade.symbol,
            account_type=account_type,
            side=orig_side,
            exit_price=exit_price,
            exit_quantity=exit_quantity,
            exit_time=datetime.utcnow(),
            exit_method=ExitMethod.WEBHOOK_SIGNAL,
            exit_order_id=str(trade.tiger_order_id) if trade.tiger_order_id else None,
            realized_pnl=realized_pnl,
            commission=commission,
            avg_entry_price=avg_entry_price,
            exit_signal_content=exit_signal_content
        )
        
        if status == "already_exists":
            return closed_pos
        
        if not closed_pos:
            logger.error(f"❌ Failed to create ClosedPosition from WebSocket: {status}")
            return None
        
        _update_completed_trades_on_close(
            symbol=trade.symbol,
            account_type=account_type,
            position_side=orig_side,
            exit_price=exit_price,
            exit_quantity=exit_quantity,
            exit_method=ExitMethod.WEBHOOK_SIGNAL,
            realized_pnl=realized_pnl
        )
        
        db.session.commit()
        
        logger.info(f"📊 Created ClosedPosition #{closed_pos.id} from WebSocket")
        return closed_pos
        
    except Exception as e:
        logger.error(f"❌ Failed to create ClosedPosition from WebSocket: {str(e)}")
        return None


def _handle_external_close_order(
    symbol: str,
    order_id: str,
    account_type: str,
    is_sell: bool,
    is_buy: bool,
    avg_fill_price: float,
    filled_quantity: float,
    realized_pnl: float,
    commission: float,
    parent_order_id: str = None
) -> Optional[ClosedPosition]:
    """
    Handle stop loss / take profit orders triggered by Tiger (not in Trade table)
    Match with active TrailingStopPosition to create ClosedPosition record
    If no active TrailingStopPosition exists, still create a ClosedPosition record
    Uses parent_order_id to match attached orders to their entry order
    Also handles OCA (One-Cancels-All) order fills
    """
    try:
        # Check for duplicate first
        existing = ClosedPosition.query.filter_by(exit_order_id=order_id).first()
        if existing:
            logger.info(f"📊 ClosedPosition already exists for order {order_id}")
            return existing
        
        # Check if this is an OCA leg fill
        oca_group = OCAGroup.query.filter(
            (OCAGroup.stop_order_id == order_id) | 
            (OCAGroup.take_profit_order_id == order_id)
        ).filter(OCAGroup.status == OCAStatus.ACTIVE).first()
        
        if oca_group:
            logger.info(f"📊 Order {order_id} is OCA leg for group {oca_group.id}")
            from oca_service import on_oca_leg_filled
            oca_result, oca_status = on_oca_leg_filled(
                tiger_order_id=order_id,
                filled_price=avg_fill_price,
                filled_quantity=filled_quantity,
                realized_pnl=realized_pnl,
                commission=commission
            )
            if oca_result:
                closed_pos = None
                if oca_result.closed_position_id:
                    closed_pos = ClosedPosition.query.get(oca_result.closed_position_id)
                
                oca_position_side = oca_group.side or ('long' if is_sell else 'short')
                oca_exit_method = ExitMethod.TAKE_PROFIT if order_id == oca_group.take_profit_order_id else ExitMethod.STOP_LOSS
                
                _update_completed_trades_on_close(
                    symbol=symbol,
                    account_type=account_type,
                    position_side=oca_position_side,
                    exit_price=avg_fill_price,
                    exit_quantity=filled_quantity,
                    exit_method=oca_exit_method,
                    realized_pnl=realized_pnl,
                    trailing_stop_id=oca_group.trailing_stop_id
                )
                
                logger.info(f"📊 OCA leg handled: {oca_status}, ClosedPosition #{oca_result.closed_position_id}")
                return closed_pos
            elif oca_status.startswith("error"):
                logger.error(f"❌ OCA leg fill error: {oca_status}")
                return None
        
        # Determine which side of position this close order corresponds to
        # SELL closes a LONG position, BUY closes a SHORT position
        if is_sell:
            position_side = 'long'
        elif is_buy:
            position_side = 'short'
        else:
            logger.warning(f"⚠️ Unknown action for order {order_id}, cannot determine position side")
            return None
        
        # Try to find entry Trade by parent_order_id (for attached stop/take profit orders)
        entry_trade = None
        if parent_order_id:
            entry_trade = Trade.query.filter_by(tiger_order_id=parent_order_id).first()
            if entry_trade:
                logger.info(f"📊 Found entry Trade #{entry_trade.id} by parent_order_id {parent_order_id}")
        
        # Find matching active TrailingStopPosition (try active first, then inactive)
        active_position = TrailingStopPosition.query.filter_by(
            symbol=symbol,
            account_type=account_type,
            side=position_side,
            is_active=True
        ).first()
        
        if not active_position:
            from datetime import timedelta
            five_min_ago = datetime.utcnow() - timedelta(minutes=5)
            active_position = TrailingStopPosition.query.filter(
                TrailingStopPosition.symbol == symbol,
                TrailingStopPosition.account_type == account_type,
                TrailingStopPosition.side == position_side,
                TrailingStopPosition.is_active == False,
                TrailingStopPosition.triggered_at >= five_min_ago
            ).order_by(TrailingStopPosition.triggered_at.desc()).first()
            
            if active_position:
                logger.info(f"📊 Found recently triggered TrailingStopPosition #{active_position.id} for {symbol}")
        
        if active_position:
            logger.info(f"📊 Matched external close order to TrailingStopPosition #{active_position.id}")
        else:
            # Still create ClosedPosition even without TrailingStopPosition
            logger.info(f"📊 No TrailingStopPosition found for {symbol}, creating ClosedPosition anyway")
        
        # Determine exit method: STOP_LOSS or TAKE_PROFIT
        if active_position:
            exit_method = _determine_exit_method(active_position, avg_fill_price)
            entry_price = active_position.entry_price
            trailing_stop_id = active_position.id
        else:
            # No TrailingStopPosition - default to STOP_LOSS (most common for auto-triggered orders)
            exit_method = ExitMethod.STOP_LOSS
            entry_price = None
            trailing_stop_id = None
        
        # Create ClosedPosition using unified service with parent_order_id for precise matching
        from closed_position_service import create_closed_position as create_closed_position_service
        
        closed_pos, status = create_closed_position_service(
            symbol=symbol,
            account_type=account_type,
            side=position_side,
            exit_price=avg_fill_price,
            exit_quantity=filled_quantity,
            exit_time=datetime.utcnow(),
            exit_method=exit_method,
            exit_order_id=order_id,
            parent_order_id=parent_order_id,
            realized_pnl=realized_pnl,
            commission=commission,
            avg_entry_price=entry_price,
            trailing_stop_id=trailing_stop_id,
            exit_signal_content=f"Tiger auto-triggered {exit_method.value if exit_method else 'close'}"
        )
        
        if status == "already_exists":
            logger.info(f"📊 ClosedPosition already exists for order {order_id}")
        elif not closed_pos:
            logger.error(f"❌ Failed to create ClosedPosition: {status}")
        
        if active_position and active_position.is_active:
            active_position.is_active = False
            active_position.is_triggered = True
            active_position.triggered_at = datetime.utcnow()
            active_position.triggered_price = avg_fill_price
            active_position.trigger_reason = f"Position closed via {exit_method.value if exit_method else 'external order'}"
        
        _update_completed_trades_on_close(
            symbol=symbol,
            account_type=account_type,
            position_side=position_side,
            exit_price=avg_fill_price,
            exit_quantity=filled_quantity,
            exit_method=exit_method,
            realized_pnl=realized_pnl,
            trailing_stop_id=active_position.id if active_position else None,
            entry_trade=entry_trade,
            active_position=active_position
        )
        
        db.session.commit()
        
        pnl_str = f"${realized_pnl:.2f}" if realized_pnl else "N/A"
        logger.info(f"📊 Created ClosedPosition #{closed_pos.id} from external order, "
                   f"exit_method={exit_method}, linked {len(unlinked_entries)} entries, "
                   f"P&L={pnl_str}")
        return closed_pos
        
    except Exception as e:
        logger.error(f"❌ Failed to handle external close order: {str(e)}")
        db.session.rollback()
        return None


def _determine_exit_method(position: TrailingStopPosition, exit_price: float) -> ExitMethod:
    """
    Determine if exit was triggered by stop loss or take profit
    by comparing exit price with position's stop/take profit levels
    """
    try:
        is_long = position.side == 'long'
        
        # Check if exit price is closer to stop loss or take profit
        stop_price = position.fixed_stop_loss or position.current_trailing_stop
        tp_price = position.take_profit_price
        
        if stop_price and tp_price:
            stop_distance = abs(exit_price - stop_price)
            tp_distance = abs(exit_price - tp_price)
            
            if stop_distance < tp_distance:
                return ExitMethod.STOP_LOSS
            else:
                return ExitMethod.TAKE_PROFIT
        elif stop_price:
            # Only stop loss is set
            if is_long:
                if exit_price <= stop_price * 1.005:  # Within 0.5% of stop
                    return ExitMethod.STOP_LOSS
            else:
                if exit_price >= stop_price * 0.995:
                    return ExitMethod.STOP_LOSS
        elif tp_price:
            # Only take profit is set
            if is_long:
                if exit_price >= tp_price * 0.995:
                    return ExitMethod.TAKE_PROFIT
            else:
                if exit_price <= tp_price * 1.005:
                    return ExitMethod.TAKE_PROFIT
        
        # Default: can't determine, assume trailing stop
        return ExitMethod.TRAILING_STOP
        
    except Exception as e:
        logger.error(f"Error determining exit method: {str(e)}")
        return ExitMethod.TRAILING_STOP


def handle_position_change(position_data: Any) -> None:
    """
    Handle position change event from WebSocket
    Detects when positions are closed externally - serves as FALLBACK
    Creates ClosedPosition if Order Fill event didn't catch it
    """
    try:
        symbol = getattr(position_data, 'symbol', None) or getattr(position_data, 'contract', {}).get('symbol')
        
        # CRITICAL FIX: Safely extract quantity - don't default to 0 if attribute is missing
        # This prevents false deactivation when WebSocket pushes incomplete data
        raw_quantity = getattr(position_data, 'quantity', None)
        raw_position = getattr(position_data, 'position', None)
        raw_position_qty = getattr(position_data, 'positionQty', None)
        
        # Use the first non-None value, or None if all are missing
        quantity = raw_quantity if raw_quantity is not None else (raw_position if raw_position is not None else raw_position_qty)
        
        market_value = getattr(position_data, 'market_value', 0) or getattr(position_data, 'marketValue', 0)
        avg_cost = getattr(position_data, 'average_cost', 0) or getattr(position_data, 'averageCost', 0)
        realized_pnl = getattr(position_data, 'realized_pnl', 0) or getattr(position_data, 'realizedPnl', 0)
        account = str(getattr(position_data, 'account', ''))
        
        logger.info(f"📋 Position change: {symbol} qty={quantity} value=${market_value} realized_pnl=${realized_pnl}")
        
        account_type = 'paper' if '2165530' in account else 'real'
        
        # CRITICAL: Only deactivate if quantity is EXPLICITLY 0, not if it's missing (None)
        if quantity is not None and quantity == 0:
            active_trailing = TrailingStopPosition.query.filter_by(
                symbol=symbol,
                account_type=account_type,
                is_active=True
            ).first()
            
            if active_trailing:
                # Check if ClosedPosition already created by Order Fill event
                recent_closed = ClosedPosition.query.filter_by(
                    symbol=symbol,
                    account_type=account_type,
                    trailing_stop_id=active_trailing.id
                ).first()
                
                if not recent_closed:
                    # Fallback: create ClosedPosition from position change using unified service
                    logger.info(f"📊 Fallback: Creating ClosedPosition from position change for {symbol}")
                    
                    from closed_position_service import create_closed_position as create_closed_position_service
                    
                    closed_pos, status = create_closed_position_service(
                        symbol=symbol,
                        account_type=account_type,
                        side=active_trailing.side,
                        exit_price=None,  # Unknown from position change
                        exit_quantity=active_trailing.quantity,
                        exit_time=datetime.utcnow(),
                        exit_method=ExitMethod.TRAILING_STOP,
                        trailing_stop_id=active_trailing.id,
                        realized_pnl=realized_pnl if realized_pnl else None,
                        avg_entry_price=active_trailing.entry_price,
                        exit_signal_content="Position closed (detected via position change fallback)"
                    )
                    
                    if closed_pos:
                        logger.info(f"📊 Created ClosedPosition #{closed_pos.id} via fallback")
                else:
                    logger.info(f"📊 ClosedPosition already exists for {symbol}, skipping fallback creation")
                
                active_trailing.is_active = False
                active_trailing.is_triggered = True
                active_trailing.triggered_at = datetime.utcnow()
                if not active_trailing.trigger_reason:
                    active_trailing.trigger_reason = "Position closed (WebSocket position change)"
                
                db.session.commit()
        
    except Exception as e:
        logger.error(f"❌ Error handling position change: {str(e)}")
        db.session.rollback()


def handle_quote_update(symbol: str, quote_data: Dict) -> None:
    """
    Handle quote update for trailing stop monitoring
    This is called for each quote pushed via WebSocket
    """
    pass
