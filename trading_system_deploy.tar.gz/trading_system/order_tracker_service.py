"""
Order Tracker Service - Unified order monitoring for all exit scenarios

This service tracks all orders placed through our system and monitors their fill status
via Tiger API polling (since WebSocket doesn't push order updates reliably).

Four exit scenarios handled:
1. WEBHOOK_SIGNAL - TradingView sends close signal
2. TRAILING_STOP - System trailing stop triggers close
3. STOP_LOSS - Tiger attached stop loss order fills
4. TAKE_PROFIT - Tiger attached take profit order fills
"""

import logging
from datetime import datetime
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def register_order(
    tiger_order_id: str,
    symbol: str,
    account_type: str,
    role: str,
    side: Optional[str] = None,
    quantity: Optional[float] = None,
    order_type: Optional[str] = None,
    limit_price: Optional[float] = None,
    stop_price: Optional[float] = None,
    parent_order_id: Optional[str] = None,
    trade_id: Optional[int] = None,
    trailing_stop_id: Optional[int] = None
) -> Tuple[Optional[object], str]:
    """Register an order for tracking.
    
    Args:
        tiger_order_id: Tiger order ID
        symbol: Stock symbol
        account_type: 'real' or 'paper'
        role: One of 'entry', 'exit_signal', 'exit_trailing', 'stop_loss', 'take_profit'
        side: BUY or SELL
        quantity: Order quantity
        order_type: MARKET/LIMIT/STOP/STP_LMT
        limit_price: Limit price if applicable
        stop_price: Stop price if applicable
        parent_order_id: Parent order ID for attached orders
        trade_id: Related Trade record ID
        trailing_stop_id: Related TrailingStopPosition ID
        
    Returns:
        Tuple of (OrderTracker, status) where status is 'created' or 'already_exists'
    """
    from app import db
    from models import OrderTracker, OrderRole
    
    try:
        existing = OrderTracker.query.filter_by(tiger_order_id=tiger_order_id).first()
        if existing:
            logger.debug(f"OrderTracker already exists for {tiger_order_id}")
            return existing, "already_exists"
        
        role_enum = OrderRole(role)
        
        tracker = OrderTracker(
            tiger_order_id=tiger_order_id,
            symbol=symbol,
            account_type=account_type,
            role=role_enum,
            side=side,
            quantity=quantity,
            order_type=order_type,
            limit_price=limit_price,
            stop_price=stop_price,
            parent_order_id=parent_order_id,
            trade_id=trade_id,
            trailing_stop_id=trailing_stop_id,
            status='PENDING'
        )
        
        db.session.add(tracker)
        db.session.commit()
        
        logger.info(f"📋 Registered order {tiger_order_id}: {symbol} {role} ({account_type})")
        return tracker, "created"
        
    except Exception as e:
        logger.error(f"Error registering order {tiger_order_id}: {e}")
        db.session.rollback()
        return None, f"error: {str(e)}"


def update_order_fill(
    tiger_order_id: str,
    filled_quantity: float,
    avg_fill_price: float,
    realized_pnl: Optional[float] = None,
    commission: Optional[float] = None,
    fill_time: Optional[datetime] = None
) -> Tuple[Optional[object], str]:
    """Update an order's fill information.
    
    Args:
        tiger_order_id: Tiger order ID
        filled_quantity: Filled quantity
        avg_fill_price: Average fill price
        realized_pnl: Realized P&L from Tiger
        commission: Commission from Tiger
        fill_time: Fill timestamp
        
    Returns:
        Tuple of (OrderTracker, status)
    """
    from app import db
    from models import OrderTracker
    
    try:
        tracker = OrderTracker.query.filter_by(tiger_order_id=tiger_order_id).first()
        if not tracker:
            logger.debug(f"No OrderTracker found for {tiger_order_id}")
            return None, "not_found"
        
        if tracker.status == 'FILLED':
            logger.debug(f"Order {tiger_order_id} already marked as FILLED")
            return tracker, "already_filled"
        
        tracker.status = 'FILLED'
        tracker.filled_quantity = filled_quantity
        tracker.avg_fill_price = avg_fill_price
        tracker.realized_pnl = realized_pnl
        tracker.commission = commission
        tracker.fill_time = fill_time or datetime.utcnow()
        
        db.session.commit()
        
        logger.info(f"📋 Updated order fill {tiger_order_id}: "
                   f"qty={filled_quantity} price=${avg_fill_price:.2f} "
                   f"pnl=${realized_pnl:.2f if realized_pnl else 0} "
                   f"comm=${commission:.4f if commission else 0}")
        
        return tracker, "updated"
        
    except Exception as e:
        logger.error(f"Error updating order fill {tiger_order_id}: {e}")
        db.session.rollback()
        return None, f"error: {str(e)}"


def get_role_to_exit_method(role: str) -> str:
    """Map OrderRole to ExitMethod.
    
    Args:
        role: OrderRole value string
        
    Returns:
        ExitMethod value string
    """
    mapping = {
        'exit_signal': 'webhook_signal',
        'exit_trailing': 'trailing_stop',
        'stop_loss': 'stop_loss',
        'take_profit': 'take_profit'
    }
    return mapping.get(role, 'external')


def poll_pending_orders(app):
    """Poll Tiger API for pending order status updates.
    
    This function:
    1. Gets all PENDING orders from OrderTracker
    2. Queries Tiger API for their current status via get_order_status
    3. Updates fill information for FILLED orders
    4. Marks EXPIRED/CANCELLED orders accordingly
    5. Creates ClosedPosition records for exit orders
    """
    try:
        with app.app_context():
            from app import db
            from models import OrderTracker, OrderRole, ExitMethod, TrailingStopPosition
            from tiger_client import TigerClient, TigerPaperClient
            from closed_position_service import create_closed_position
            
            pending_orders = OrderTracker.query.filter_by(status='PENDING').all()
            
            if not pending_orders:
                return
            
            logger.debug(f"📋 Polling {len(pending_orders)} pending orders")
            
            real_orders = [o for o in pending_orders if o.account_type == 'real']
            paper_orders = [o for o in pending_orders if o.account_type == 'paper']
            
            for account_type, orders, client_class in [
                ('real', real_orders, TigerClient),
                ('paper', paper_orders, TigerPaperClient)
            ]:
                if not orders:
                    continue
                    
                try:
                    client = client_class()
                    
                    for tracker in orders:
                        try:
                            result = client.get_order_status(tracker.tiger_order_id)
                            
                            if not result.get('success'):
                                logger.debug(f"Failed to get status for order {tracker.tiger_order_id}: {result.get('error')}")
                                continue
                            
                            status = result.get('status', '').lower()
                            
                            if status == 'filled':
                                tracker.status = 'FILLED'
                                tracker.filled_quantity = result.get('filled_quantity', 0)
                                tracker.avg_fill_price = result.get('filled_price', 0)
                                tracker.realized_pnl = result.get('realized_pnl', 0)
                                tracker.commission = result.get('commission', 0)
                                tracker.fill_time = datetime.utcnow()
                                
                                db.session.commit()
                                
                                logger.info(f"📋 Order {tracker.tiger_order_id} FILLED: "
                                           f"{tracker.symbol} {tracker.role.value} "
                                           f"qty={tracker.filled_quantity} "
                                           f"price=${tracker.avg_fill_price:.2f} "
                                           f"pnl=${tracker.realized_pnl or 0:.2f}")
                                
                                if tracker.role in [OrderRole.EXIT_SIGNAL, OrderRole.EXIT_TRAILING, 
                                                   OrderRole.STOP_LOSS, OrderRole.TAKE_PROFIT]:
                                    process_exit_order_fill(tracker)
                                    
                            elif status in ['invalid', 'cancelled', 'expired']:
                                tracker.status = 'CANCELLED'
                                reason = result.get('reason', '')
                                logger.warning(f"📋 Order {tracker.tiger_order_id} {status.upper()}: "
                                              f"{tracker.symbol} {tracker.role.value} - {reason}")
                                db.session.commit()
                                
                            elif status == 'pending':
                                pass
                                
                        except Exception as e:
                            logger.error(f"Error checking order {tracker.tiger_order_id}: {e}")
                                
                except Exception as e:
                    logger.error(f"Error polling {account_type} orders: {e}")
                    
    except Exception as e:
        logger.error(f"Error in poll_pending_orders: {e}")


def process_exit_order_fill(tracker):
    """Process a filled exit order and create ClosedPosition.
    
    Args:
        tracker: OrderTracker record for the filled exit order
    """
    from app import db
    from models import OrderRole, ExitMethod, Trade, TrailingStopPosition
    from closed_position_service import create_closed_position
    
    try:
        exit_method_map = {
            OrderRole.EXIT_SIGNAL: ExitMethod.WEBHOOK_SIGNAL,
            OrderRole.EXIT_TRAILING: ExitMethod.TRAILING_STOP,
            OrderRole.STOP_LOSS: ExitMethod.STOP_LOSS,
            OrderRole.TAKE_PROFIT: ExitMethod.TAKE_PROFIT
        }
        
        exit_method = exit_method_map.get(tracker.role, ExitMethod.EXTERNAL)
        
        trailing_pos = None
        entry_price = None
        side = 'long'
        
        if tracker.trailing_stop_id:
            trailing_pos = TrailingStopPosition.query.get(tracker.trailing_stop_id)
            if trailing_pos:
                entry_price = trailing_pos.entry_price
                side = trailing_pos.side
        
        if not entry_price and tracker.trade_id:
            trade = Trade.query.get(tracker.trade_id)
            if trade:
                entry_price = trade.filled_price or trade.price or trade.reference_price
                side = 'long' if trade.side.value == 'buy' else 'short'
        
        closed_pos, status = create_closed_position(
            symbol=tracker.symbol,
            account_type=tracker.account_type,
            side=side,
            exit_price=tracker.avg_fill_price,
            exit_quantity=tracker.filled_quantity,
            exit_time=tracker.fill_time,
            exit_method=exit_method,
            exit_order_id=tracker.tiger_order_id,
            realized_pnl=tracker.realized_pnl,
            commission=tracker.commission,
            avg_entry_price=entry_price,
            trailing_stop_id=tracker.trailing_stop_id,
            exit_signal_content=f"Order filled via Tiger API ({tracker.role.value})"
        )
        
        if status == "created":
            tracker.closed_position_id = closed_pos.id
            
            if trailing_pos and trailing_pos.is_active:
                trailing_pos.is_active = False
                trailing_pos.is_triggered = True
                trailing_pos.triggered_at = datetime.utcnow()
                trailing_pos.trigger_reason = f"Exit order filled ({tracker.role.value})"
            
            db.session.commit()
            
            logger.info(f"📊 Created ClosedPosition #{closed_pos.id} from OrderTracker: "
                       f"{tracker.symbol} {exit_method.value} "
                       f"P&L=${tracker.realized_pnl or 0:.2f}")
        else:
            logger.debug(f"ClosedPosition not created: {status}")
            
    except Exception as e:
        logger.error(f"Error processing exit order fill for {tracker.tiger_order_id}: {e}")
        db.session.rollback()
