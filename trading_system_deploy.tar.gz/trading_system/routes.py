import json
import logging
from datetime import datetime, timedelta
from flask import render_template, request, jsonify, flash, redirect, url_for
from app import app, db
from models import Trade, TradingConfig, SignalLog, OrderStatus, OrderType, Side, CompletedTrade, ExitMethod, EntrySignalRecord, ClosedPosition
from tiger_client import TigerClient, TigerPaperClient
from signal_parser import SignalParser
from signal_analyzer import parse_signal_grades
from config import get_config, set_config
from discord_notifier import discord_notifier
from position_cost_manager import update_position_cost_on_fill, get_avg_cost_for_symbol, record_entry_cost_on_trade

logger = logging.getLogger(__name__)


def create_entry_signal_record(
    symbol: str,
    account_type: str,
    side: str,
    entry_price: float,
    quantity: float,
    raw_json: str,
    signal_log_id: int = None,
    is_scaling: bool = False,
    signal_grades: dict = None,
    stop_loss: float = None,
    take_profit: float = None,
    entry_order_id: str = None
) -> EntrySignalRecord:
    """Create an EntrySignalRecord for tracking open signals (including scaling)"""
    try:
        signal_grades = signal_grades or {}
        record = EntrySignalRecord(
            symbol=symbol,
            account_type=account_type,
            side=side,
            entry_time=datetime.utcnow(),
            entry_price=entry_price,
            quantity=quantity,
            is_scaling=is_scaling,
            signal_log_id=signal_log_id,
            raw_json=raw_json,
            entry_order_id=entry_order_id,
            indicator_trigger=signal_grades.get('signal_indicator'),
            signal_grade=signal_grades.get('signal_grade'),
            signal_score=signal_grades.get('signal_score'),
            htf_grade=signal_grades.get('htf_grade'),
            htf_score=signal_grades.get('htf_score'),
            timeframe=signal_grades.get('signal_timeframe'),
            signal_stop_loss=stop_loss,
            signal_take_profit=take_profit
        )
        db.session.add(record)
        db.session.commit()
        logger.info(f"📝 Created EntrySignalRecord #{record.id} for {symbol} ({'scaling' if is_scaling else 'new position'})")
        return record
    except Exception as e:
        db.session.rollback()
        logger.error(f"❌ Failed to create EntrySignalRecord: {str(e)}")
        return None


def create_closed_position(
    symbol: str,
    account_type: str,
    side: str,
    exit_order_id: str,
    exit_time: datetime,
    exit_price: float,
    exit_quantity: float,
    exit_method: ExitMethod,
    exit_signal_content: str = None,
    avg_entry_price: float = None,
    trailing_stop_id: int = None,
    realized_pnl: float = None,
    commission: float = None,
    exit_indicator: str = None,
    parent_order_id: str = None
) -> ClosedPosition:
    """Create a ClosedPosition record using unified service.
    
    This is a wrapper that calls the centralized closed_position_service
    and also updates CompletedTrade for Trade Analytics compatibility.
    
    Args:
        realized_pnl: Tiger API returned realized P&L (preferred over calculation)
        commission: Tiger API returned commission/fees
        exit_indicator: Signal indicator name from extras.indicator
        parent_order_id: Parent order ID for precise entry matching
    """
    try:
        from closed_position_service import create_closed_position as create_closed_position_service
        
        # Call unified service
        closed_pos, status = create_closed_position_service(
            symbol=symbol,
            account_type=account_type,
            side=side,
            exit_price=exit_price,
            exit_quantity=exit_quantity,
            exit_time=exit_time,
            exit_method=exit_method,
            exit_order_id=exit_order_id,
            parent_order_id=parent_order_id,
            realized_pnl=realized_pnl,
            commission=commission,
            avg_entry_price=avg_entry_price,
            trailing_stop_id=trailing_stop_id,
            exit_signal_content=exit_signal_content,
            exit_indicator=exit_indicator
        )
        
        if not closed_pos:
            logger.error(f"❌ Failed to create ClosedPosition: {status}")
            return None
        
        # Also update CompletedTrade for Trade Analytics page compatibility
        _update_completed_trade_on_close(
            symbol=symbol,
            account_type=account_type,
            side=side,
            exit_time=exit_time,
            exit_price=exit_price,
            exit_quantity=exit_quantity,
            exit_method=exit_method,
            realized_pnl=realized_pnl
        )
        
        return closed_pos
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"❌ Failed to create ClosedPosition: {str(e)}")
        return None


def _update_completed_trade_on_close(
    symbol: str,
    account_type: str,
    side: str,
    exit_time: datetime,
    exit_price: float,
    exit_quantity: float,
    exit_method: ExitMethod,
    realized_pnl: float = None
) -> None:
    """Update CompletedTrade when position is closed (for Trade Analytics page)"""
    try:
        completed_trade = CompletedTrade.query.filter_by(
            symbol=symbol,
            account_type=account_type,
            side=side,
            is_open=True
        ).order_by(CompletedTrade.created_at.desc()).first()
        
        if completed_trade:
            completed_trade.is_open = False
            completed_trade.exit_time = exit_time
            completed_trade.exit_price = exit_price
            completed_trade.exit_quantity = exit_quantity
            completed_trade.exit_method = exit_method
            
            if completed_trade.entry_price:
                if side == 'long':
                    completed_trade.pnl_amount = (exit_price - completed_trade.entry_price) * (completed_trade.entry_quantity or exit_quantity)
                    completed_trade.pnl_percent = ((exit_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                else:
                    completed_trade.pnl_amount = (completed_trade.entry_price - exit_price) * (completed_trade.entry_quantity or exit_quantity)
                    completed_trade.pnl_percent = ((completed_trade.entry_price - exit_price) / completed_trade.entry_price) * 100
            
            if realized_pnl:
                completed_trade.pnl_amount = realized_pnl
            
            db.session.commit()
            logger.info(f"📊 Updated CompletedTrade #{completed_trade.id} as closed")
        else:
            logger.debug(f"📊 No open CompletedTrade found for {symbol} ({account_type})")
    except Exception as e:
        logger.error(f"❌ Failed to update CompletedTrade: {str(e)}")


@app.route('/')
def index():
    """Main dashboard page"""
    recent_trades = Trade.query.order_by(Trade.created_at.desc()).limit(10).all()
    total_trades = Trade.query.count()
    successful_trades = Trade.query.filter_by(status=OrderStatus.FILLED).count()
    pending_trades = Trade.query.filter_by(status=OrderStatus.PENDING).count()
    
    return render_template('index.html', 
                         recent_trades=recent_trades,
                         total_trades=total_trades,
                         successful_trades=successful_trades,
                         pending_trades=pending_trades)

@app.route('/webhook', methods=['POST'])
def webhook():
    """Receive TradingView webhook signals"""
    try:
        # Get client IP
        client_ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)
        
        # Get raw data
        raw_data = request.get_data(as_text=True)
        logger.info(f"Received webhook from {client_ip}: {raw_data}")
        
        # Log the signal
        signal_log = SignalLog()
        signal_log.raw_signal = raw_data
        signal_log.ip_address = client_ip
        signal_log.endpoint = '/webhook'
        signal_log.account_type = 'real'
        
        try:
            # Parse JSON
            signal_data = request.get_json()
            if not signal_data:
                raise ValueError("No JSON data received")
            
            # Parse the signal
            parser = SignalParser()
            parsed_signal = parser.parse(signal_data)
            
            # Validate required fields
            if not all(key in parsed_signal for key in ['symbol', 'side', 'quantity']):
                raise ValueError("Missing required fields: symbol, side, quantity")
            
            # Initialize trade variable
            trade = None
            
            # Check if this is a close/flat signal
            if parsed_signal.get('is_close_signal', False):
                logger.info(f"Processing close signal for {parsed_signal['symbol']}, side={parsed_signal.get('side')}")
                
                # Execute close position
                tiger_client = TigerClient()
                
                # Get current position average cost BEFORE closing
                pre_close_avg_cost = None
                try:
                    pos_result = tiger_client.get_positions(symbol=parsed_signal['symbol'])
                    if pos_result.get('success') and pos_result.get('positions'):
                        pre_close_avg_cost = pos_result['positions'][0].get('average_cost', 0)
                        logger.info(f"Pre-close avg cost for {parsed_signal['symbol']}: ${pre_close_avg_cost:.2f}")
                except Exception as e:
                    logger.error(f"Failed to get pre-close avg cost: {str(e)}")
                
                trading_session = parsed_signal.get('trading_session', 'regular')
                reference_price = parsed_signal.get('reference_price')  # Get reference price for extended hours
                signal_side = parsed_signal.get('side')
                result = tiger_client.close_position_with_sandbox_fallback(
                    parsed_signal['symbol'], 
                    trading_session,
                    reference_price=reference_price,
                    signal_side=signal_side
                )
                
                # Handle no_action case (signal direction doesn't match position direction)
                if result.get('no_action'):
                    logger.info(f"{result.get('message')}")
                    signal_log.parsed_successfully = True
                    signal_log.error_message = result.get('message')
                    db.session.add(signal_log)
                    db.session.commit()
                    return jsonify({
                        'success': True,
                        'no_action': True,
                        'message': result.get('message')
                    })
                
                # Create trade record for close position
                if result['success']:
                    trade = Trade()
                    trade.symbol = parsed_signal['symbol']
                    trade.side = Side(result['action'])  # Use the determined action from close_position
                    trade.quantity = result['quantity']
                    
                    # Set order type and price based on actual order placed
                    order_type_str = result.get('order_type', 'market')
                    if order_type_str == 'limit':
                        trade.order_type = OrderType.LIMIT
                        trade.price = result.get('order_price')  # Set limit price if available
                        logger.info(f"Close position using LIMIT order at ${trade.price:.2f}")
                    else:
                        trade.order_type = OrderType.MARKET
                        trade.price = None  # Market order price is determined at execution
                        logger.info("Close position using MARKET order")
                    
                    trade.signal_data = raw_data
                    trade.tiger_order_id = result['order_id']
                    trade.status = OrderStatus.PENDING
                    trade.trading_session = result.get('trading_session', trading_session)
                    trade.outside_rth = result.get('outside_rth', parsed_signal.get('outside_rth', trading_session != 'regular'))
                    trade.is_close_position = True  # Mark as close position
                    trade.account_type = 'real'  # Mark as real account trade
                    
                    # Store pre-close average cost
                    if pre_close_avg_cost:
                        trade.entry_avg_cost = pre_close_avg_cost
                        logger.info(f"Stored pre-close avg cost ${pre_close_avg_cost:.2f} for {trade.symbol}")
                    
                    # Store Tiger API response for close position
                    trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                    
                    db.session.add(trade)
                    db.session.flush()
                    
                    signal_log.parsed_successfully = True
                    signal_log.trade_id = trade.id
                    logger.info(f"Close position order placed: {result['order_id']}")
                    
                    # Get real-time order status from Tiger API for close position
                    try:
                        import time
                        time.sleep(1)  # Brief wait for order processing
                        
                        status_result = tiger_client.get_order_status(trade.tiger_order_id)
                        if status_result['success']:
                            # Update trade with real Tiger API data - map Tiger status to our enum
                            tiger_status = status_result['status']
                            if tiger_status == 'filled':
                                trade.status = OrderStatus.FILLED
                                # entry_avg_cost already set from pre_close_avg_cost
                                    
                            elif tiger_status == 'pending':
                                trade.status = OrderStatus.PENDING
                            elif tiger_status == 'cancelled':
                                trade.status = OrderStatus.CANCELLED
                            elif tiger_status == 'rejected':
                                trade.status = OrderStatus.REJECTED
                            else:
                                trade.status = OrderStatus.PENDING  # Default fallback
                            if status_result['filled_price'] > 0:
                                trade.price = status_result['filled_price']
                                trade.filled_price = status_result['filled_price']
                            trade.filled_quantity = status_result.get('filled_quantity', 0)
                            
                            # Send Discord notification with real Tiger data for close position
                            discord_status = status_result['status']
                            discord_notifier.send_order_notification(trade, discord_status, is_close=True)
                            
                            logger.info(f"Close position Discord notification sent with real Tiger data: {discord_status}, price: {status_result.get('filled_price', 0)}")
                            
                            # Create ClosedPosition record for forensics tracking
                            if tiger_status == 'filled':
                                try:
                                    exit_price = status_result.get('filled_price', 0)
                                    # Determine original position side (opposite of close action)
                                    orig_side = 'long' if result.get('action') == 'sell' else 'short'
                                    # Extract exit indicator from signal extras
                                    exit_indicator = None
                                    if isinstance(signal_data, dict):
                                        extras = signal_data.get('extras', {})
                                        if isinstance(extras, dict):
                                            exit_indicator = extras.get('indicator')
                                    create_closed_position(
                                        symbol=trade.symbol,
                                        account_type='real',
                                        side=orig_side,
                                        exit_order_id=trade.tiger_order_id,
                                        exit_time=datetime.utcnow(),
                                        exit_price=exit_price,
                                        exit_quantity=status_result.get('filled_quantity', trade.quantity),
                                        exit_method=ExitMethod.WEBHOOK_SIGNAL,
                                        exit_signal_content=raw_data,
                                        avg_entry_price=pre_close_avg_cost,
                                        realized_pnl=status_result.get('realized_pnl'),
                                        commission=status_result.get('commission'),
                                        exit_indicator=exit_indicator
                                    )
                                except Exception as cp_err:
                                    logger.error(f"❌ Failed to create ClosedPosition: {str(cp_err)}")
                        else:
                            # Fallback to pending status if can't get real-time data
                            discord_notifier.send_order_notification(trade, 'pending', is_close=True)
                    except Exception as e:
                        logger.error(f"Failed to get real-time status or send Discord notification for close position: {str(e)}")
                        # Fallback notification
                        try:
                            discord_notifier.send_order_notification(trade, 'pending', is_close=True)
                        except Exception as e2:
                            logger.error(f"Fallback Discord notification for close position also failed: {str(e2)}")
                else:
                    logger.error(f"Failed to close position: {result['error']}")
                    signal_log.error_message = result['error']
                    result['success'] = False
                    
                    # Send Discord notification for failed close position
                    if 'trade' in locals():
                        try:
                            discord_notifier.send_order_notification(trade, 'rejected', is_close=True)
                        except Exception as e:
                            logger.error(f"Failed to send Discord notification for failed close position: {str(e)}")
                
            else:
                # Regular trade signal processing
                
                # Check risk limits
                max_trade_amount = float(get_config('MAX_TRADE_AMOUNT', '1000000'))
                trade_amount = parsed_signal['quantity'] * parsed_signal.get('price', 100)  # Rough estimate for market orders
                
                if trade_amount > max_trade_amount:
                    raise ValueError(f"Trade amount ${trade_amount:.2f} exceeds maximum allowed ${max_trade_amount:.2f}")
                
                # Create trade record
                trade = Trade()
                trade.symbol = parsed_signal['symbol']
                trade.side = Side(parsed_signal['side'].lower())
                trade.quantity = parsed_signal['quantity']
                trade.price = parsed_signal.get('price')
                trade.order_type = OrderType(parsed_signal.get('order_type', 'market').lower())
                trade.signal_data = raw_data
                
                # Add stop loss and take profit
                trade.stop_loss_price = parsed_signal.get('stop_loss')
                trade.take_profit_price = parsed_signal.get('take_profit')
                
                # Add trading session settings
                trade.trading_session = parsed_signal.get('trading_session', 'regular')
                trade.outside_rth = parsed_signal.get('outside_rth', False)
                
                # Add reference price for market order conversion
                trade.reference_price = parsed_signal.get('reference_price')
                trade.account_type = 'real'  # Mark as real account trade
                
                db.session.add(trade)
                db.session.flush()  # Get the ID
                
                signal_log.parsed_successfully = True
                signal_log.trade_id = trade.id
                
                # Execute the trade
                tiger_client = TigerClient()
                result = tiger_client.place_order(trade)
            
            if result['success'] and trade is not None:
                # For regular trades, trade is already created
                # For close signals, trade is created only if close was successful
                if not hasattr(trade, 'tiger_order_id') or trade.tiger_order_id is None:
                    trade.tiger_order_id = result['order_id']
                if not hasattr(trade, 'status') or trade.status != OrderStatus.PENDING:
                    trade.status = OrderStatus.PENDING
                
                # Store Tiger API response
                trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                
                # Save attached order IDs if present
                if 'stop_loss_order_id' in result:
                    trade.stop_loss_order_id = result['stop_loss_order_id']
                    logger.info(f"Stop loss order created: {result['stop_loss_order_id']}")
                
                if 'take_profit_order_id' in result:
                    trade.take_profit_order_id = result['take_profit_order_id']
                    logger.info(f"Take profit order created: {result['take_profit_order_id']}")
                
                # Register orders to OrderTracker for unified monitoring
                from order_tracker_service import register_order
                is_close_signal = parsed_signal.get('is_close_signal', False)
                order_role = 'exit_signal' if is_close_signal else 'entry'
                register_order(
                    tiger_order_id=result['order_id'],
                    symbol=trade.symbol,
                    account_type='real',
                    role=order_role,
                    side=trade.side.value.upper(),
                    quantity=trade.quantity,
                    trade_id=trade.id
                )
                if 'stop_loss_order_id' in result:
                    register_order(
                        tiger_order_id=result['stop_loss_order_id'],
                        symbol=trade.symbol,
                        account_type='real',
                        role='stop_loss',
                        parent_order_id=result['order_id'],
                        stop_price=trade.stop_loss_price,
                        trade_id=trade.id
                    )
                if 'take_profit_order_id' in result:
                    register_order(
                        tiger_order_id=result['take_profit_order_id'],
                        symbol=trade.symbol,
                        account_type='real',
                        role='take_profit',
                        parent_order_id=result['order_id'],
                        limit_price=trade.take_profit_price,
                        trade_id=trade.id
                    )
                
                # Check if this order needs auto-protection (position increase case)
                needs_auto_protection = result.get('needs_auto_protection', False)
                protection_info = result.get('protection_info', {})
                auto_protection_symbol = result.get('symbol')
                
                if needs_auto_protection:
                    logger.info(f"Order requires auto-protection after execution: {auto_protection_symbol}")
                    # Store protection info for later processing
                    trade.needs_auto_protection = True
                    if protection_info:
                        trade.protection_info = json.dumps(protection_info)
                
                logger.info(f"Order placed successfully: {result['order_id']}")
                
                # Get real-time order status from Tiger API before sending Discord notification
                try:
                    import time
                    time.sleep(1)  # Brief wait for order processing
                    
                    status_result = tiger_client.get_order_status(trade.tiger_order_id)
                    if status_result['success']:
                        # Update trade with real Tiger API data - map Tiger status to our enum
                        tiger_status = status_result['status']
                        if tiger_status == 'filled':
                            trade.status = OrderStatus.FILLED
                            # Commit trade immediately so foreign keys work
                            db.session.commit()
                            
                            # Handle auto-protection for position increases
                            if hasattr(trade, 'needs_auto_protection') and trade.needs_auto_protection:
                                logger.info(f"Order {trade.tiger_order_id} filled, applying auto-protection for position increase")
                                try:
                                    protection_info = json.loads(trade.protection_info) if hasattr(trade, 'protection_info') else {}
                                    if protection_info.get('stop_loss_price') or protection_info.get('take_profit_price'):
                                        # Check if trailing stop has switched to dynamic mode
                                        from models import TrailingStopPosition
                                        existing_ts = TrailingStopPosition.query.filter_by(
                                            symbol=trade.symbol, account_type='real', is_active=True
                                        ).first()
                                        has_switched = existing_ts.has_switched_to_trailing if existing_ts else False
                                        
                                        # If switched to dynamic trailing, don't create take profit order
                                        take_profit_for_oca = None if has_switched else protection_info.get('take_profit_price')
                                        if has_switched:
                                            logger.info(f"🔄 {trade.symbol} 已切换到动态trailing，加仓时只创建止损订单")
                                        
                                        logger.info(f"Applying OCA protection for {trade.symbol}")
                                        position_result = tiger_client.get_positions(symbol=trade.symbol)
                                        if position_result['success'] and position_result['positions']:
                                            current_quantity = position_result['positions'][0]['quantity']
                                            protection_quantity = abs(current_quantity)
                                            
                                            protection_result = tiger_client.create_oca_orders_for_position(
                                                symbol=trade.symbol,
                                                quantity=protection_quantity,
                                                stop_loss_price=protection_info.get('stop_loss_price'),
                                                take_profit_price=take_profit_for_oca
                                            )
                                        else:
                                            logger.error(f"Could not get position for {trade.symbol} to apply OCA protection")
                                            protection_result = {'success': False, 'error': 'No position found'}
                                        if protection_result['success']:
                                            logger.info(f"Auto-protection applied successfully for {trade.symbol}")
                                            if 'stop_loss_order_id' in protection_result:
                                                trade.stop_loss_order_id = protection_result['stop_loss_order_id']
                                            if 'take_profit_order_id' in protection_result:
                                                trade.take_profit_order_id = protection_result['take_profit_order_id']
                                            
                                            # Update trailing stop position for position increase
                                            try:
                                                from trailing_stop_engine import update_trailing_stop_on_position_increase
                                                
                                                # Get current position info from Tiger
                                                avg_cost = position_result['positions'][0].get('average_cost', 0)
                                                
                                                ts_update = update_trailing_stop_on_position_increase(
                                                    symbol=trade.symbol,
                                                    account_type='real',
                                                    new_quantity=protection_quantity,
                                                    new_entry_price=avg_cost,
                                                    new_stop_loss_price=protection_info.get('stop_loss_price'),
                                                    new_take_profit_price=protection_info.get('take_profit_price'),
                                                    new_stop_loss_order_id=protection_result.get('stop_loss_order_id'),
                                                    new_take_profit_order_id=protection_result.get('take_profit_order_id')
                                                )
                                                if ts_update['success']:
                                                    logger.info(f"✅ 加仓后更新TrailingStop成功: {ts_update['message']}")
                                                    
                                                    # Create EntrySignalRecord for scaling (加仓)
                                                    try:
                                                        scaling_signal_grades = parse_signal_grades(signal_data) if 'signal_data' in dir() else {}
                                                        create_entry_signal_record(
                                                            symbol=trade.symbol,
                                                            account_type='real',
                                                            side='long' if trade.side.value == 'buy' else 'short',
                                                            entry_price=status_result.get('filled_price', 0),
                                                            quantity=trade.quantity,
                                                            raw_json=trade.signal_data or '',
                                                            signal_log_id=None,
                                                            is_scaling=True,
                                                            signal_grades=scaling_signal_grades,
                                                            stop_loss=protection_info.get('stop_loss_price'),
                                                            take_profit=protection_info.get('take_profit_price')
                                                        )
                                                    except Exception as esr_err:
                                                        logger.error(f"❌ 加仓EntrySignalRecord创建失败: {str(esr_err)}")
                                                    
                                                    # Immediately optimize stop loss based on current price and tier
                                                    try:
                                                        from trailing_stop_engine import calculate_optimal_stop_after_scaling
                                                        from tiger_client import get_tiger_quote_client
                                                        
                                                        # Get current price using smart price (支持盘前盘后)
                                                        quote_client = get_tiger_quote_client()
                                                        if quote_client is None:
                                                            logger.warning("Quote client not available for scaling optimization")
                                                            raise Exception("Quote client unavailable")
                                                        quote_result = quote_client.get_smart_price(trade.symbol)
                                                        if quote_result and quote_result.get('price'):
                                                            current_price = quote_result['price']
                                                            
                                                            opt_result = calculate_optimal_stop_after_scaling(
                                                                symbol=trade.symbol,
                                                                account_type='real',
                                                                current_price=current_price,
                                                                tiger_client=tiger_client
                                                            )
                                                            
                                                            if opt_result.get('stop_updated'):
                                                                logger.info(f"🎯 加仓止损优化: {opt_result['message']}")
                                                            else:
                                                                logger.info(f"📊 加仓止损检查: {opt_result.get('message', 'OK')}")
                                                    except Exception as opt_err:
                                                        logger.error(f"加仓止损优化异常: {str(opt_err)}")
                                                else:
                                                    logger.warning(f"⚠️ 加仓后更新TrailingStop: {ts_update['message']}")
                                            except Exception as ts_err:
                                                logger.error(f"❌ 加仓后更新TrailingStop异常: {str(ts_err)}")
                                        else:
                                            logger.error(f"Failed to apply auto-protection: {protection_result.get('error')}")
                                    
                                    # Clear protection flags
                                    trade.needs_auto_protection = False
                                    trade.protection_info = None
                                except Exception as e:
                                    logger.error(f"Error applying auto-protection: {str(e)}")
                            
                            # Update position cost tracking for regular orders
                            try:
                                filled_price = status_result.get('filled_price', 0)
                                filled_qty = status_result.get('filled_quantity', trade.quantity)
                                avg_cost = update_position_cost_on_fill(
                                    symbol=trade.symbol,
                                    side=trade.side.value,
                                    quantity=filled_qty,
                                    fill_price=filled_price,
                                    account_type='real'
                                )
                                # For sells, record the avg_cost at time of sale
                                if avg_cost and trade.side.value == 'sell':
                                    trade.entry_avg_cost = avg_cost
                                    logger.info(f"Recorded entry_avg_cost=${avg_cost:.2f} for {trade.symbol}")
                            except Exception as cost_err:
                                logger.error(f"Error updating position cost: {str(cost_err)}")
                            
                            # Auto-create trailing stop for non-close orders
                            if not getattr(trade, 'is_close_position', False):
                                # Define these outside try block so they're always available for EntrySignalRecord
                                ts_side = 'long' if trade.side.value == 'buy' else 'short'
                                entry_price = filled_price or parsed_signal.get('reference_price') or parsed_signal.get('price')
                                
                                # Create trailing stop if enabled
                                try:
                                    from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
                                    from models import TrailingStopMode
                                    
                                    ts_config = get_trailing_stop_config()
                                    if ts_config.is_enabled:
                                        timeframe = signal_data.get('extras', {}).get('timeframe', '15') if isinstance(signal_data, dict) else '15'
                                        
                                        trailing_position = create_trailing_stop_for_trade(
                                            trade_id=trade.id,
                                            symbol=trade.symbol,
                                            side=ts_side,
                                            entry_price=entry_price,
                                            quantity=trade.quantity,
                                            account_type='real',
                                            fixed_stop_loss=trade.stop_loss_price,
                                            fixed_take_profit=trade.take_profit_price,
                                            stop_loss_order_id=trade.stop_loss_order_id,
                                            take_profit_order_id=trade.take_profit_order_id,
                                            mode=TrailingStopMode.BALANCED,
                                            timeframe=str(timeframe)
                                        )
                                        logger.info(f"🎯 Auto-created trailing stop for {trade.symbol}, side={ts_side}, entry=${entry_price:.2f}")
                                except Exception as ts_err:
                                    logger.error(f"🎯 Failed to create trailing stop: {str(ts_err)}")
                                
                                # Always create EntrySignalRecord for forensics (regardless of trailing stop status)
                                try:
                                    signal_grades = parse_signal_grades(signal_data)
                                    create_entry_signal_record(
                                        symbol=trade.symbol,
                                        account_type='real',
                                        side=ts_side,
                                        entry_price=entry_price,
                                        quantity=trade.quantity,
                                        raw_json=raw_data,
                                        signal_log_id=signal_log.id if signal_log else None,
                                        is_scaling=False,
                                        signal_grades=signal_grades,
                                        stop_loss=trade.stop_loss_price,
                                        take_profit=trade.take_profit_price,
                                        entry_order_id=str(trade.tiger_order_id)
                                    )
                                except Exception as esr_err:
                                    logger.error(f"❌ EntrySignalRecord创建失败: {str(esr_err)}")
                                    
                        elif tiger_status == 'pending':
                            trade.status = OrderStatus.PENDING
                        elif tiger_status == 'cancelled':
                            trade.status = OrderStatus.CANCELLED
                        elif tiger_status == 'rejected':
                            trade.status = OrderStatus.REJECTED
                        else:
                            trade.status = OrderStatus.PENDING  # Default fallback
                        if status_result['filled_price'] > 0:
                            trade.price = status_result['filled_price']
                            trade.filled_price = status_result['filled_price']
                        trade.filled_quantity = status_result.get('filled_quantity', 0)
                        
                        # Send Discord notification with real Tiger data
                        discord_status = status_result['status']
                        discord_notifier.send_order_notification(trade, discord_status, is_close=getattr(trade, 'is_close_position', False))
                        
                        logger.info(f"Discord notification sent with real Tiger data: {discord_status}, price: {status_result.get('filled_price', 0)}")
                    else:
                        # Fallback to pending status if can't get real-time data
                        discord_notifier.send_order_notification(trade, 'pending', is_close=getattr(trade, 'is_close_position', False))
                except Exception as e:
                    logger.error(f"Failed to get real-time status or send Discord notification: {str(e)}")
                    # Fallback notification
                    try:
                        discord_notifier.send_order_notification(trade, 'pending', is_close=getattr(trade, 'is_close_position', False))
                    except Exception as e2:
                        logger.error(f"Fallback Discord notification also failed: {str(e2)}")
                
            elif trade is not None:
                trade.status = OrderStatus.REJECTED
                trade.error_message = result.get('error', 'Unknown error')
                
                # Store Tiger API response even for failed trades
                trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                
                logger.error(f"Order rejected: {result.get('error', 'Unknown error')}")
                
                # Send Discord notification for rejected order
                try:
                    discord_notifier.send_order_notification(trade, 'rejected', is_close=getattr(trade, 'is_close_position', False))
                except Exception as e:
                    logger.error(f"Failed to send Discord notification: {str(e)}")
            
            # Update signal log with Tiger API response
            if result.get('success'):
                signal_log.tiger_status = 'success'
                signal_log.tiger_order_id = str(result.get('order_id', ''))
            else:
                signal_log.tiger_status = 'error'
                signal_log.error_message = result.get('error', 'Unknown error')
            signal_log.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
            
            db.session.add(signal_log)
            db.session.commit()
            
            return jsonify({
                'success': result['success'],
                'trade_id': trade.id if trade else None,
                'order_id': result.get('order_id'),
                'message': result.get('error', 'Order placed successfully')
            })
            
        except Exception as e:
            logger.error(f"Error processing signal: {str(e)}")
            signal_log.error_message = str(e)
            db.session.add(signal_log)
            db.session.commit()
            
            return jsonify({
                'success': False,
                'error': str(e)
            }), 400
            
    except Exception as e:
        logger.error(f"Critical error in webhook: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500


@app.route('/webhook_paper', methods=['POST'])
def webhook_paper():
    """
    Receive TradingView webhook signals for Paper Trading (模拟账户)
    Uses the same tiger_id but connects to paper trading account
    """
    try:
        client_ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)
        raw_data = request.get_data(as_text=True)
        logger.info(f"📝 [PAPER] Received webhook from {client_ip}: {raw_data}")
        
        signal_log = SignalLog()
        signal_log.raw_signal = raw_data  # Clean signal data, account_type distinguishes paper
        signal_log.ip_address = client_ip
        signal_log.endpoint = '/webhook_paper'
        signal_log.account_type = 'paper'
        
        try:
            signal_data = request.get_json()
            if not signal_data:
                raise ValueError("No JSON data received")
            
            parser = SignalParser()
            parsed_signal = parser.parse(signal_data)
            
            if not all(key in parsed_signal for key in ['symbol', 'side', 'quantity']):
                raise ValueError("Missing required fields: symbol, side, quantity")
            
            trade = None
            tiger_paper_client = TigerPaperClient()
            
            if parsed_signal.get('is_close_signal', False):
                logger.info(f"📝 [PAPER] Processing close signal for {parsed_signal['symbol']}, side={parsed_signal.get('side')}")
                
                # Cancel any active OCA orders first to release locked shares
                try:
                    from oca_service import cancel_oca_for_manual_close
                    # OCAGroup uses clean symbol (e.g., "GOOG") not prefixed symbol
                    oca_symbol = parsed_signal['symbol']
                    cancelled_count, cancel_msg = cancel_oca_for_manual_close(oca_symbol, 'paper')
                    if cancelled_count > 0:
                        logger.info(f"📝 [PAPER] Cancelled {cancelled_count} OCA group(s) for {oca_symbol} before close: {cancel_msg}")
                except Exception as oca_err:
                    logger.warning(f"📝 [PAPER] Failed to cancel OCA before close: {str(oca_err)}")
                
                # Get current position average cost BEFORE closing
                pre_close_avg_cost = None
                try:
                    pos_result = tiger_paper_client.get_positions(symbol=parsed_signal['symbol'])
                    if pos_result.get('success') and pos_result.get('positions'):
                        pre_close_avg_cost = pos_result['positions'][0].get('average_cost', 0)
                        logger.info(f"📝 [PAPER] Pre-close avg cost for {parsed_signal['symbol']}: ${pre_close_avg_cost:.2f}")
                except Exception as e:
                    logger.error(f"📝 [PAPER] Failed to get pre-close avg cost: {str(e)}")
                
                trading_session = parsed_signal.get('trading_session', 'regular')
                reference_price = parsed_signal.get('reference_price')
                signal_side = parsed_signal.get('side')
                result = tiger_paper_client.close_position_with_sandbox_fallback(
                    parsed_signal['symbol'], 
                    trading_session,
                    reference_price=reference_price,
                    signal_side=signal_side
                )
                
                # Handle no_action case (signal direction doesn't match position direction)
                if result.get('no_action'):
                    logger.info(f"📝 [PAPER] {result.get('message')}")
                    signal_log.parsed_successfully = True
                    signal_log.error_message = result.get('message')
                    db.session.add(signal_log)
                    db.session.commit()
                    return jsonify({
                        'success': True,
                        'no_action': True,
                        'message': result.get('message'),
                        'account_type': 'paper'
                    })
                
                if result['success']:
                    trade = Trade()
                    trade.symbol = parsed_signal['symbol']  # Clean symbol, use account_type for distinction
                    trade.side = Side(result['action'])
                    trade.quantity = result['quantity']
                    
                    order_type_str = result.get('order_type', 'market')
                    if order_type_str == 'limit':
                        trade.order_type = OrderType.LIMIT
                        trade.price = result.get('order_price')
                    else:
                        trade.order_type = OrderType.MARKET
                        trade.price = None
                    
                    trade.signal_data = raw_data  # Clean signal data
                    trade.tiger_order_id = result['order_id']
                    trade.status = OrderStatus.PENDING
                    trade.trading_session = result.get('trading_session', trading_session)
                    trade.outside_rth = result.get('outside_rth', parsed_signal.get('outside_rth', trading_session != 'regular'))
                    trade.is_close_position = True
                    trade.account_type = 'paper'  # Mark as paper account trade
                    
                    # Store pre-close average cost
                    if pre_close_avg_cost:
                        trade.entry_avg_cost = pre_close_avg_cost
                        logger.info(f"📝 [PAPER] Stored pre-close avg cost ${pre_close_avg_cost:.2f} for {trade.symbol}")
                    
                    trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                    
                    db.session.add(trade)
                    db.session.flush()
                    
                    signal_log.parsed_successfully = True
                    signal_log.trade_id = trade.id
                    logger.info(f"📝 [PAPER] Close position order placed: {result['order_id']}")
                    
                    # Update CompletedTrade record for paper webhook exit
                    try:
                        # Search both with and without [PAPER] prefix for backward compatibility
                        from sqlalchemy import or_
                        completed_trade = CompletedTrade.query.filter(
                            or_(
                                CompletedTrade.symbol == parsed_signal['symbol'],
                                CompletedTrade.symbol == f"[PAPER]{parsed_signal['symbol']}"
                            ),
                            CompletedTrade.account_type == 'paper',
                            CompletedTrade.is_open == True
                        ).order_by(CompletedTrade.created_at.desc()).first()
                        
                        if completed_trade:
                            exit_price = result.get('order_price') or reference_price or parsed_signal.get('reference_price')
                            # Fallback: Get current market price from Tiger API if exit_price is not available
                            # 使用智能价格获取 - 盘前盘后时段使用timeline API
                            if not exit_price:
                                try:
                                    from tiger_client import get_tiger_quote_client
                                    quote_client = get_tiger_quote_client()
                                    if quote_client:
                                        trade_data = quote_client.get_smart_price(parsed_signal['symbol'])
                                        if trade_data and trade_data.get('price'):
                                            exit_price = trade_data['price']
                                            price_session = trade_data.get('session', 'regular')
                                            logger.info(f"📊 [PAPER] Using {price_session} price {exit_price} as exit price for {parsed_signal['symbol']}")
                                except Exception as price_err:
                                    logger.warning(f"📊 [PAPER] Failed to get market price for exit: {str(price_err)}")
                            
                            # 如果订单已成交，等待后从Tiger API获取实际成交价
                            if not exit_price and result.get('success') and result.get('order_id'):
                                try:
                                    import time
                                    time.sleep(1)
                                    order_status = tiger_paper_client.get_order_status(result['order_id'])
                                    if order_status.get('success') and order_status.get('filled_price'):
                                        exit_price = order_status['filled_price']
                                        logger.info(f"📊 [PAPER] Using Tiger filled price {exit_price} as exit price")
                                except Exception as status_err:
                                    logger.warning(f"📊 [PAPER] Failed to get order status for exit price: {str(status_err)}")
                            
                            completed_trade.exit_method = ExitMethod.WEBHOOK_SIGNAL
                            completed_trade.exit_signal_content = raw_data
                            completed_trade.exit_time = datetime.utcnow()
                            completed_trade.exit_price = exit_price
                            completed_trade.exit_quantity = result['quantity']
                            completed_trade.is_open = False
                            
                            if completed_trade.entry_price and exit_price:
                                if completed_trade.side == 'long':
                                    completed_trade.pnl_percent = ((exit_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                                    completed_trade.pnl_amount = (exit_price - completed_trade.entry_price) * completed_trade.entry_quantity
                                else:
                                    completed_trade.pnl_percent = ((completed_trade.entry_price - exit_price) / completed_trade.entry_price) * 100
                                    completed_trade.pnl_amount = (completed_trade.entry_price - exit_price) * completed_trade.entry_quantity
                            
                            db.session.commit()
                            pnl_str = f"{completed_trade.pnl_percent:.2f}%" if completed_trade.pnl_percent else "N/A"
                            logger.info(f"📊 [PAPER] Updated CompletedTrade #{completed_trade.id} with webhook exit, exit_price: {exit_price}, P&L: {pnl_str}")
                        else:
                            logger.warning(f"📊 [PAPER] No open CompletedTrade found for {symbol_to_find}")
                    except Exception as ct_error:
                        logger.error(f"📊 [PAPER] Failed to update CompletedTrade on exit: {str(ct_error)}")
                    
                    # Create ClosedPosition record for forensics tracking (Paper)
                    try:
                        import time
                        time.sleep(1)  # Brief wait for order processing
                        
                        status_result = tiger_paper_client.get_order_status(trade.tiger_order_id)
                        if status_result.get('success'):
                            tiger_status = status_result.get('status', '')
                            if tiger_status == 'filled':
                                exit_price_cp = status_result.get('filled_price', 0)
                                orig_side = 'long' if result.get('action') == 'sell' else 'short'
                                # Extract exit indicator from signal extras
                                exit_indicator_paper = None
                                if isinstance(signal_data, dict):
                                    extras_paper = signal_data.get('extras', {})
                                    if isinstance(extras_paper, dict):
                                        exit_indicator_paper = extras_paper.get('indicator')
                                create_closed_position(
                                    symbol=parsed_signal['symbol'],  # Clean symbol
                                    account_type='paper',
                                    side=orig_side,
                                    exit_order_id=trade.tiger_order_id,
                                    exit_time=datetime.utcnow(),
                                    exit_price=exit_price_cp,
                                    exit_quantity=status_result.get('filled_quantity', trade.quantity),
                                    exit_method=ExitMethod.WEBHOOK_SIGNAL,
                                    exit_signal_content=raw_data,
                                    avg_entry_price=pre_close_avg_cost,
                                    realized_pnl=status_result.get('realized_pnl'),
                                    commission=status_result.get('commission'),
                                    exit_indicator=exit_indicator_paper
                                )
                                # Update trade status
                                trade.status = OrderStatus.FILLED
                                if status_result.get('filled_price') and status_result['filled_price'] > 0:
                                    trade.price = status_result['filled_price']
                                    trade.filled_price = status_result['filled_price']
                                trade.filled_quantity = status_result.get('filled_quantity', 0)
                                db.session.commit()
                    except Exception as cp_err:
                        logger.error(f"❌ [PAPER] Failed to create ClosedPosition: {str(cp_err)}")
                else:
                    logger.error(f"📝 [PAPER] Failed to close position: {result['error']}")
                    signal_log.error_message = result['error']
                    result['success'] = False
            else:
                max_trade_amount = float(get_config('MAX_TRADE_AMOUNT', '1000000'))
                trade_amount = parsed_signal['quantity'] * parsed_signal.get('price', 100)
                
                if trade_amount > max_trade_amount:
                    raise ValueError(f"Trade amount ${trade_amount:.2f} exceeds maximum allowed ${max_trade_amount:.2f}")
                
                trade = Trade()
                trade.symbol = parsed_signal['symbol']
                trade.side = Side(parsed_signal['side'].lower())
                trade.quantity = parsed_signal['quantity']
                trade.price = parsed_signal.get('price')
                trade.order_type = OrderType(parsed_signal.get('order_type', 'market').lower())
                trade.signal_data = raw_data  # Clean signal data
                trade.stop_loss_price = parsed_signal.get('stop_loss')
                trade.take_profit_price = parsed_signal.get('take_profit')
                trade.trading_session = parsed_signal.get('trading_session', 'regular')
                trade.outside_rth = parsed_signal.get('outside_rth', False)
                trade.reference_price = parsed_signal.get('reference_price')
                trade.account_type = 'paper'  # Mark as paper account trade
                
                db.session.add(trade)
                db.session.flush()
                
                signal_log.parsed_successfully = True
                signal_log.trade_id = trade.id
                
                result = tiger_paper_client.place_order(trade)
                
                # Keep clean symbol, account_type distinguishes paper vs real
            
            if result['success'] and trade is not None:
                if not hasattr(trade, 'tiger_order_id') or trade.tiger_order_id is None:
                    trade.tiger_order_id = result['order_id']
                if not hasattr(trade, 'status') or trade.status != OrderStatus.PENDING:
                    trade.status = OrderStatus.PENDING
                
                trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                
                if 'stop_loss_order_id' in result:
                    trade.stop_loss_order_id = result['stop_loss_order_id']
                if 'take_profit_order_id' in result:
                    trade.take_profit_order_id = result['take_profit_order_id']
                
                # Register orders to OrderTracker for unified monitoring (Paper)
                from order_tracker_service import register_order
                clean_symbol = parsed_signal['symbol']  # Use clean symbol without [PAPER] prefix
                is_close_signal = parsed_signal.get('is_close_signal', False)
                order_role = 'exit_signal' if is_close_signal else 'entry'
                register_order(
                    tiger_order_id=result['order_id'],
                    symbol=clean_symbol,
                    account_type='paper',
                    role=order_role,
                    side=trade.side.value.upper(),
                    quantity=trade.quantity,
                    trade_id=trade.id
                )
                if 'stop_loss_order_id' in result:
                    register_order(
                        tiger_order_id=result['stop_loss_order_id'],
                        symbol=clean_symbol,
                        account_type='paper',
                        role='stop_loss',
                        parent_order_id=result['order_id'],
                        stop_price=trade.stop_loss_price,
                        trade_id=trade.id
                    )
                if 'take_profit_order_id' in result:
                    register_order(
                        tiger_order_id=result['take_profit_order_id'],
                        symbol=clean_symbol,
                        account_type='paper',
                        role='take_profit',
                        parent_order_id=result['order_id'],
                        limit_price=trade.take_profit_price,
                        trade_id=trade.id
                    )
                
                needs_auto_protection = result.get('needs_auto_protection', False)
                protection_info = result.get('protection_info', {})
                if needs_auto_protection:
                    trade.needs_auto_protection = True
                    trade.protection_info = json.dumps(protection_info)
                
                try:
                    import time
                    time.sleep(1)
                    
                    status_result = tiger_paper_client.get_order_status(trade.tiger_order_id)
                    if status_result['success']:
                        tiger_status = status_result['status']
                        if tiger_status == 'filled':
                            trade.status = OrderStatus.FILLED
                            # Commit trade immediately so foreign keys work
                            db.session.commit()
                            
                            if hasattr(trade, 'needs_auto_protection') and trade.needs_auto_protection:
                                logger.info(f"📝 [PAPER] Order {trade.tiger_order_id} filled, applying auto-protection")
                                try:
                                    protection_info = json.loads(trade.protection_info) if hasattr(trade, 'protection_info') else {}
                                    if protection_info.get('stop_loss_price') or protection_info.get('take_profit_price'):
                                        # Check if trailing stop has switched to dynamic mode
                                        from models import TrailingStopPosition
                                        existing_ts = TrailingStopPosition.query.filter_by(
                                            symbol=parsed_signal['symbol'], account_type='paper', is_active=True
                                        ).first()
                                        has_switched = existing_ts.has_switched_to_trailing if existing_ts else False
                                        
                                        # If switched to dynamic trailing, don't create take profit order
                                        take_profit_for_oca = None if has_switched else protection_info.get('take_profit_price')
                                        if has_switched:
                                            logger.info(f"📝 [PAPER] 🔄 {parsed_signal['symbol']} 已切换到动态trailing，加仓时只创建止损订单")
                                        
                                        position_result = tiger_paper_client.get_positions(symbol=parsed_signal['symbol'])
                                        if position_result['success'] and position_result['positions']:
                                            current_quantity = position_result['positions'][0]['quantity']
                                            protection_quantity = abs(current_quantity)
                                            
                                            protection_result = tiger_paper_client.create_oca_orders_for_position(
                                                symbol=parsed_signal['symbol'],
                                                quantity=protection_quantity,
                                                stop_loss_price=protection_info.get('stop_loss_price'),
                                                take_profit_price=take_profit_for_oca
                                            )
                                            
                                            if protection_result['success']:
                                                logger.info(f"📝 [PAPER] Auto-protection applied successfully for {parsed_signal['symbol']}")
                                                trade.needs_auto_protection = False
                                                
                                                # Update trailing stop position for position increase (paper)
                                                try:
                                                    from trailing_stop_engine import update_trailing_stop_on_position_increase
                                                    
                                                    avg_cost = position_result['positions'][0].get('average_cost', 0)
                                                    
                                                    ts_update = update_trailing_stop_on_position_increase(
                                                        symbol=parsed_signal['symbol'],
                                                        account_type='paper',
                                                        new_quantity=protection_quantity,
                                                        new_entry_price=avg_cost,
                                                        new_stop_loss_price=protection_info.get('stop_loss_price'),
                                                        new_take_profit_price=protection_info.get('take_profit_price'),
                                                        new_stop_loss_order_id=protection_result.get('stop_loss_order_id'),
                                                        new_take_profit_order_id=protection_result.get('take_profit_order_id')
                                                    )
                                                    if ts_update['success']:
                                                        logger.info(f"📝 [PAPER] 加仓后更新TrailingStop成功: {ts_update['message']}")
                                                        
                                                        # Create EntrySignalRecord for scaling (Paper加仓)
                                                        try:
                                                            scaling_signal_grades = parse_signal_grades(signal_data) if 'signal_data' in dir() else {}
                                                            create_entry_signal_record(
                                                                symbol=trade.symbol,
                                                                account_type='paper',
                                                                side='long' if trade.side.value == 'buy' else 'short',
                                                                entry_price=status_result.get('filled_price', 0),
                                                                quantity=trade.quantity,
                                                                raw_json=trade.signal_data or '',
                                                                signal_log_id=None,
                                                                is_scaling=True,
                                                                signal_grades=scaling_signal_grades,
                                                                stop_loss=protection_info.get('stop_loss_price'),
                                                                take_profit=protection_info.get('take_profit_price')
                                                            )
                                                        except Exception as esr_err:
                                                            logger.error(f"❌ [PAPER] 加仓EntrySignalRecord创建失败: {str(esr_err)}")
                                                        
                                                        # Immediately optimize stop loss based on current price and tier
                                                        try:
                                                            from trailing_stop_engine import calculate_optimal_stop_after_scaling
                                                            from tiger_client import get_tiger_quote_client
                                                            
                                                            # Get current price using smart price (支持盘前盘后)
                                                            quote_client = get_tiger_quote_client()
                                                            if quote_client is None:
                                                                logger.warning("[PAPER] Quote client not available for scaling optimization")
                                                                raise Exception("Quote client unavailable")
                                                            quote_result = quote_client.get_smart_price(parsed_signal['symbol'])
                                                            if quote_result and quote_result.get('price'):
                                                                current_price = quote_result['price']
                                                                
                                                                opt_result = calculate_optimal_stop_after_scaling(
                                                                    symbol=parsed_signal['symbol'],
                                                                    account_type='paper',
                                                                    current_price=current_price,
                                                                    tiger_client=tiger_paper_client
                                                                )
                                                                
                                                                if opt_result.get('stop_updated'):
                                                                    logger.info(f"📝 [PAPER] 🎯 加仓止损优化: {opt_result['message']}")
                                                                else:
                                                                    logger.info(f"📝 [PAPER] 📊 加仓止损检查: {opt_result.get('message', 'OK')}")
                                                        except Exception as opt_err:
                                                            logger.error(f"📝 [PAPER] 加仓止损优化异常: {str(opt_err)}")
                                                    else:
                                                        logger.warning(f"📝 [PAPER] 加仓后更新TrailingStop: {ts_update['message']}")
                                                except Exception as ts_err:
                                                    logger.error(f"📝 [PAPER] 加仓后更新TrailingStop异常: {str(ts_err)}")
                                except Exception as e:
                                    logger.error(f"📝 [PAPER] Failed to apply auto-protection: {str(e)}")
                            
                            # Update position cost tracking for paper account
                            try:
                                filled_price = status_result.get('filled_price', 0)
                                filled_qty = status_result.get('filled_quantity', trade.quantity)
                                avg_cost = update_position_cost_on_fill(
                                    symbol=parsed_signal['symbol'],
                                    side=trade.side.value,
                                    quantity=filled_qty,
                                    fill_price=filled_price,
                                    account_type='paper'
                                )
                                if avg_cost and trade.side.value == 'sell':
                                    trade.entry_avg_cost = avg_cost
                                    logger.info(f"📝 [PAPER] Recorded entry_avg_cost=${avg_cost:.2f} for {trade.symbol}")
                            except Exception as cost_err:
                                logger.error(f"📝 [PAPER] Error updating position cost: {str(cost_err)}")
                            
                            # Auto-create trailing stop for non-close orders (paper account)
                            if not getattr(trade, 'is_close_position', False):
                                # Define these outside try block so they're always available for CompletedTrade and EntrySignalRecord
                                ts_side = 'long' if trade.side.value == 'buy' else 'short'
                                entry_price = filled_price or parsed_signal.get('reference_price') or parsed_signal.get('price')
                                trailing_position = None
                                
                                # Create trailing stop if enabled
                                try:
                                    from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
                                    from models import TrailingStopMode
                                    
                                    ts_config = get_trailing_stop_config()
                                    if ts_config.is_enabled:
                                        timeframe = signal_data.get('extras', {}).get('timeframe', '15') if isinstance(signal_data, dict) else '15'
                                        
                                        trailing_position = create_trailing_stop_for_trade(
                                            trade_id=trade.id,
                                            symbol=trade.symbol,
                                            side=ts_side,
                                            entry_price=entry_price,
                                            quantity=trade.quantity,
                                            account_type='paper',
                                            fixed_stop_loss=trade.stop_loss_price,
                                            fixed_take_profit=trade.take_profit_price,
                                            stop_loss_order_id=trade.stop_loss_order_id,
                                            take_profit_order_id=trade.take_profit_order_id,
                                            mode=TrailingStopMode.BALANCED,
                                            timeframe=str(timeframe)
                                        )
                                        logger.info(f"🎯 [PAPER] Auto-created trailing stop for {trade.symbol}, side={ts_side}, entry=${entry_price:.2f}")
                                        
                                        # CRITICAL: Paper extended hours - create OCA after TrailingStop
                                        # WebSocket doesn't work in extended hours, so OCA must be created via API
                                        if trailing_position and trade.stop_loss_price and trade.take_profit_price:
                                            if not trade.stop_loss_order_id and not trade.take_profit_order_id:
                                                try:
                                                    from oca_service import create_oca_protection
                                                    logger.info(f"🎯 [PAPER] Creating OCA protection for {trade.symbol} (extended hours fallback)")
                                                    oca_result, oca_status = create_oca_protection(
                                                        trailing_stop_id=trailing_position.id,
                                                        symbol=trade.symbol,
                                                        side=ts_side,
                                                        quantity=int(trade.quantity),
                                                        stop_price=trade.stop_loss_price,
                                                        take_profit_price=trade.take_profit_price,
                                                        account_type='paper'
                                                    )
                                                    if oca_result:
                                                        logger.info(f"✅ [PAPER] OCA protection created: {oca_status}")
                                                        trailing_position.stop_loss_order_id = oca_result.stop_order_id
                                                        trailing_position.take_profit_order_id = oca_result.take_profit_order_id
                                                        db.session.commit()
                                                    else:
                                                        logger.warning(f"⚠️ [PAPER] OCA creation failed: {oca_status}")
                                                except Exception as oca_err:
                                                    logger.error(f"❌ [PAPER] OCA creation error: {str(oca_err)}")
                                except Exception as ts_err:
                                    logger.error(f"🎯 [PAPER] Failed to create trailing stop: {str(ts_err)}")
                                
                                # Create CompletedTrade record for analytics (paper account) - always create regardless of trailing stop
                                try:
                                    signal_grades = parse_signal_grades(signal_data)
                                    completed_trade = CompletedTrade(
                                        symbol=trade.symbol,
                                        account_type='paper',
                                        entry_signal_content=raw_data,
                                        entry_time=datetime.utcnow(),
                                        entry_price=entry_price,
                                        entry_quantity=trade.quantity,
                                        side=ts_side,
                                        original_stop_loss=trade.stop_loss_price,
                                        original_take_profit=trade.take_profit_price,
                                        trade_id=trade.id,
                                        trailing_stop_id=trailing_position.id if trailing_position else None,
                                        signal_indicator=signal_grades.get('signal_indicator'),
                                        signal_type=signal_grades.get('signal_type'),
                                        signal_grade=signal_grades.get('signal_grade'),
                                        signal_score=signal_grades.get('signal_score'),
                                        htf_grade=signal_grades.get('htf_grade'),
                                        htf_score=signal_grades.get('htf_score'),
                                        htf_pass_status=signal_grades.get('htf_pass_status'),
                                        trend_strength=signal_grades.get('trend_strength'),
                                        signal_timeframe=signal_grades.get('signal_timeframe'),
                                        is_open=True,
                                        remaining_quantity=trade.quantity,
                                        exited_quantity=0
                                    )
                                    db.session.add(completed_trade)
                                    db.session.commit()
                                    logger.info(f"📊 [PAPER] Created CompletedTrade record #{completed_trade.id} for {trade.symbol}")
                                    
                                    # Create EntrySignalRecord for initial entry (forensics)
                                    try:
                                        create_entry_signal_record(
                                            symbol=trade.symbol,
                                            account_type='paper',
                                            side=ts_side,
                                            entry_price=entry_price,
                                            quantity=trade.quantity,
                                            raw_json=raw_data,
                                            signal_log_id=signal_log.id if signal_log else None,
                                            is_scaling=False,
                                            signal_grades=signal_grades,
                                            stop_loss=trade.stop_loss_price,
                                            take_profit=trade.take_profit_price,
                                            entry_order_id=str(trade.tiger_order_id)
                                        )
                                    except Exception as esr_err:
                                        logger.error(f"❌ [PAPER] EntrySignalRecord创建失败: {str(esr_err)}")
                                except Exception as ct_error:
                                    db.session.rollback()
                                    logger.error(f"📊 [PAPER] Failed to create CompletedTrade: {str(ct_error)}")
                                    
                        elif tiger_status == 'pending':
                            trade.status = OrderStatus.PENDING
                        elif tiger_status == 'cancelled':
                            trade.status = OrderStatus.CANCELLED
                        elif tiger_status == 'rejected':
                            trade.status = OrderStatus.REJECTED
                        else:
                            trade.status = OrderStatus.PENDING
                        if status_result['filled_price'] > 0:
                            trade.price = status_result['filled_price']
                            trade.filled_price = status_result['filled_price']
                        trade.filled_quantity = status_result.get('filled_quantity', 0)
                        
                        discord_status = status_result['status']
                        discord_notifier.send_order_notification(trade, f"[PAPER] {discord_status}", is_close=getattr(trade, 'is_close_position', False))
                        logger.info(f"📝 [PAPER] Discord notification sent: {discord_status}")
                    else:
                        discord_notifier.send_order_notification(trade, '[PAPER] pending', is_close=getattr(trade, 'is_close_position', False))
                except Exception as e:
                    logger.error(f"📝 [PAPER] Failed to get real-time status: {str(e)}")
                    try:
                        discord_notifier.send_order_notification(trade, '[PAPER] pending', is_close=getattr(trade, 'is_close_position', False))
                    except Exception as e2:
                        logger.error(f"📝 [PAPER] Fallback Discord notification failed: {str(e2)}")
                
            elif trade is not None:
                trade.status = OrderStatus.REJECTED
                trade.error_message = result.get('error', 'Unknown error')
                
                trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                logger.error(f"📝 [PAPER] Order rejected: {result.get('error', 'Unknown error')}")
                
                try:
                    discord_notifier.send_order_notification(trade, '[PAPER] rejected', is_close=getattr(trade, 'is_close_position', False))
                except Exception as e:
                    logger.error(f"📝 [PAPER] Failed to send Discord notification: {str(e)}")
            
            # Update signal log with Tiger API response
            if result.get('success'):
                signal_log.tiger_status = 'success'
                signal_log.tiger_order_id = str(result.get('order_id', ''))
            else:
                signal_log.tiger_status = 'error'
            signal_log.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
            
            db.session.add(signal_log)
            db.session.commit()
            
            return jsonify({
                'success': result['success'],
                'trade_id': trade.id if trade else None,
                'order_id': result.get('order_id'),
                'account_type': 'paper',
                'message': result.get('error', '[PAPER] Order placed successfully')
            })
            
        except Exception as e:
            logger.error(f"📝 [PAPER] Error processing signal: {str(e)}")
            signal_log.error_message = str(e)
            db.session.add(signal_log)
            db.session.commit()
            
            return jsonify({
                'success': False,
                'account_type': 'paper',
                'error': str(e)
            }), 400
            
    except Exception as e:
        logger.error(f"📝 [PAPER] Critical error in webhook: {str(e)}")
        return jsonify({
            'success': False,
            'account_type': 'paper',
            'error': 'Internal server error'
        }), 500


def process_signal_for_account(raw_data: str, signal_data: dict, client_ip: str, account_type: str) -> dict:
    """
    Internal function to process a trading signal for a specific account type.
    Returns a result dict with success status and details.
    """
    try:
        parser = SignalParser()
        parsed_signal = parser.parse(signal_data)
        
        if not all(key in parsed_signal for key in ['symbol', 'side', 'quantity']):
            raise ValueError("Missing required fields: symbol, side, quantity")
        
        # Select the appropriate Tiger client
        if account_type == 'paper':
            tiger_client = TigerPaperClient()
            prefix = "[PAPER]"
        else:
            tiger_client = TigerClient()
            prefix = ""
        
        trade = None
        
        if parsed_signal.get('is_close_signal', False):
            logger.info(f"🔄 [{account_type.upper()}] Processing close signal for {parsed_signal['symbol']}")
            
            # Get current position average cost BEFORE closing
            pre_close_avg_cost = None
            try:
                pos_result = tiger_client.get_positions(symbol=parsed_signal['symbol'])
                if pos_result.get('success') and pos_result.get('positions'):
                    pre_close_avg_cost = pos_result['positions'][0].get('average_cost', 0)
                    logger.info(f"🔄 [{account_type.upper()}] Pre-close avg cost for {parsed_signal['symbol']}: ${pre_close_avg_cost:.2f}")
            except Exception as e:
                logger.error(f"🔄 [{account_type.upper()}] Failed to get pre-close avg cost: {str(e)}")
            
            trading_session = parsed_signal.get('trading_session', 'regular')
            reference_price = parsed_signal.get('reference_price')
            signal_side = parsed_signal.get('side')
            result = tiger_client.close_position_with_sandbox_fallback(
                parsed_signal['symbol'], 
                trading_session,
                reference_price=reference_price,
                signal_side=signal_side
            )
            
            if result.get('no_action'):
                return {'success': True, 'no_action': True, 'message': result.get('message'), 'account_type': account_type}
            
            if result['success']:
                trade = Trade()
                trade.symbol = parsed_signal['symbol']  # Clean symbol, use account_type for distinction
                trade.side = Side(result['action'])
                trade.quantity = result['quantity']
                
                order_type_str = result.get('order_type', 'market')
                if order_type_str == 'limit':
                    trade.order_type = OrderType.LIMIT
                    trade.price = result.get('order_price')
                else:
                    trade.order_type = OrderType.MARKET
                    trade.price = None
                
                trade.signal_data = raw_data  # Clean signal data
                trade.tiger_order_id = result['order_id']
                trade.status = OrderStatus.PENDING
                trade.trading_session = result.get('trading_session', trading_session)
                trade.outside_rth = result.get('outside_rth', False)
                trade.is_close_position = True
                trade.account_type = account_type
                
                # Store pre-close average cost
                if pre_close_avg_cost:
                    trade.entry_avg_cost = pre_close_avg_cost
                    logger.info(f"🔄 [{account_type.upper()}] Stored pre-close avg cost ${pre_close_avg_cost:.2f} for {trade.symbol}")
                
                trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                
                db.session.add(trade)
                db.session.commit()
                
                # Update CompletedTrade record for webhook exit
                try:
                    # Search both clean symbol and legacy [PAPER] prefix for backward compatibility
                    from sqlalchemy import or_
                    symbol_variants = [parsed_signal['symbol']]
                    if account_type == 'paper':
                        symbol_variants.append(f"[PAPER]{parsed_signal['symbol']}")
                    completed_trade = CompletedTrade.query.filter(
                        or_(*[CompletedTrade.symbol == s for s in symbol_variants]),
                        CompletedTrade.account_type == account_type,
                        CompletedTrade.is_open == True
                    ).order_by(CompletedTrade.created_at.desc()).first()
                    
                    if completed_trade:
                        exit_price = result.get('order_price') or reference_price or parsed_signal.get('reference_price')
                        # Fallback: Get current market price from Tiger API if exit_price is not available
                        # 使用智能价格获取 - 盘前盘后时段使用timeline API
                        if not exit_price:
                            try:
                                from tiger_client import get_tiger_quote_client
                                quote_client = get_tiger_quote_client()
                                if quote_client:
                                    trade_data = quote_client.get_smart_price(parsed_signal['symbol'])
                                    if trade_data and trade_data.get('price'):
                                        exit_price = trade_data['price']
                                        price_session = trade_data.get('session', 'regular')
                                        logger.info(f"📊 Using {price_session} price {exit_price} as exit price for {parsed_signal['symbol']}")
                            except Exception as price_err:
                                logger.warning(f"📊 Failed to get market price for exit: {str(price_err)}")
                        
                        # 如果订单已成交，等待后从Tiger API获取实际成交价
                        if not exit_price and result.get('success') and result.get('order_id'):
                            try:
                                import time
                                time.sleep(1)  # 等待订单处理
                                order_status = tiger_client.get_order_status(result['order_id'])
                                if order_status.get('success') and order_status.get('filled_price'):
                                    exit_price = order_status['filled_price']
                                    logger.info(f"📊 Using Tiger filled price {exit_price} as exit price")
                            except Exception as status_err:
                                logger.warning(f"📊 Failed to get order status for exit price: {str(status_err)}")
                        
                        completed_trade.exit_method = ExitMethod.WEBHOOK_SIGNAL
                        completed_trade.exit_signal_content = raw_data
                        completed_trade.exit_time = datetime.utcnow()
                        completed_trade.exit_price = exit_price
                        completed_trade.exit_quantity = result['quantity']
                        completed_trade.is_open = False
                        
                        # Calculate P&L
                        if completed_trade.entry_price and exit_price:
                            if completed_trade.side == 'long':
                                completed_trade.pnl_amount = (exit_price - completed_trade.entry_price) * completed_trade.entry_quantity
                                completed_trade.pnl_percent = ((exit_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                            else:  # short
                                completed_trade.pnl_amount = (completed_trade.entry_price - exit_price) * completed_trade.entry_quantity
                                completed_trade.pnl_percent = ((completed_trade.entry_price - exit_price) / completed_trade.entry_price) * 100
                        
                        # Calculate hold duration
                        if completed_trade.entry_time:
                            hold_duration = datetime.utcnow() - completed_trade.entry_time
                            completed_trade.hold_duration_seconds = int(hold_duration.total_seconds())
                        
                        db.session.commit()
                        logger.info(f"📊 [{account_type.upper()}] Updated CompletedTrade #{completed_trade.id} with webhook exit, P&L: {completed_trade.pnl_percent:.2f}%")
                    else:
                        logger.warning(f"📊 [{account_type.upper()}] No open CompletedTrade found for {symbol_to_find}")
                except Exception as ct_error:
                    logger.error(f"📊 [{account_type.upper()}] Failed to update CompletedTrade on exit: {str(ct_error)}")
        else:
            max_trade_amount = float(get_config('MAX_TRADE_AMOUNT', '1000000'))
            trade_amount = parsed_signal['quantity'] * parsed_signal.get('price', 100)
            
            if trade_amount > max_trade_amount:
                raise ValueError(f"Trade amount ${trade_amount:.2f} exceeds maximum allowed ${max_trade_amount:.2f}")
            
            trade = Trade()
            # Use original symbol for Tiger API call
            trade.symbol = parsed_signal['symbol']
            trade.side = Side(parsed_signal['side'].lower())
            trade.quantity = parsed_signal['quantity']
            trade.price = parsed_signal.get('price')
            trade.order_type = OrderType(parsed_signal.get('order_type', 'market').lower())
            trade.signal_data = raw_data  # Clean signal data
            trade.stop_loss_price = parsed_signal.get('stop_loss')
            trade.take_profit_price = parsed_signal.get('take_profit')
            trade.trading_session = parsed_signal.get('trading_session', 'regular')
            trade.outside_rth = parsed_signal.get('outside_rth', False)
            trade.reference_price = parsed_signal.get('reference_price')
            trade.account_type = account_type
            
            db.session.add(trade)
            db.session.flush()
            
            result = tiger_client.place_order(trade)
            
            if result['success']:
                trade.tiger_order_id = result['order_id']
                trade.status = OrderStatus.PENDING
                # Keep clean symbol, account_type distinguishes paper vs real
                
                trade.tiger_response = json.dumps(result, ensure_ascii=False, indent=2)
                
                if 'stop_loss_order_id' in result:
                    trade.stop_loss_order_id = result['stop_loss_order_id']
                if 'take_profit_order_id' in result:
                    trade.take_profit_order_id = result['take_profit_order_id']
                
                db.session.commit()
                
                # Prepare common data for trailing stop and analytics
                signal_side = parsed_signal['side'].lower()
                ts_side = 'long' if signal_side == 'buy' else 'short'
                filled_price = result.get('avg_fill_price') or result.get('filled_price')
                entry_price = filled_price or parsed_signal.get('reference_price') or parsed_signal.get('price') or 0
                timeframe = '15'  # default
                if 'extras' in signal_data and signal_data['extras']:
                    timeframe = signal_data['extras'].get('timeframe', '15')
                ts_symbol = trade.symbol
                
                trailing_position = None
                
                # Auto-create trailing stop for new positions
                try:
                    from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
                    from models import TrailingStopMode
                    
                    ts_config = get_trailing_stop_config()
                    if ts_config.is_enabled:
                        trailing_position = create_trailing_stop_for_trade(
                            trade_id=trade.id,
                            symbol=ts_symbol,
                            side=ts_side,
                            entry_price=entry_price,
                            quantity=parsed_signal['quantity'],
                            account_type=account_type,
                            fixed_stop_loss=parsed_signal.get('stop_loss'),
                            fixed_take_profit=parsed_signal.get('take_profit'),
                            stop_loss_order_id=result.get('stop_loss_order_id'),
                            take_profit_order_id=result.get('take_profit_order_id'),
                            mode=TrailingStopMode.BALANCED,
                            timeframe=str(timeframe)
                        )
                        logger.info(f"🎯 [{account_type.upper()}] Auto-created trailing stop for {ts_symbol}, side={ts_side}, entry=${entry_price:.2f}")
                except Exception as e:
                    logger.error(f"🎯 [{account_type.upper()}] Failed to create trailing stop: {str(e)}")
                
                # Create CompletedTrade record for analytics (independent of trailing stop)
                try:
                    signal_grades = parse_signal_grades(signal_data)
                    completed_trade = CompletedTrade(
                        symbol=ts_symbol,
                        account_type=account_type,
                        entry_signal_content=raw_data,
                        entry_time=datetime.utcnow(),
                        entry_price=entry_price,
                        entry_quantity=parsed_signal['quantity'],
                        side=ts_side,
                        original_stop_loss=parsed_signal.get('stop_loss'),
                        original_take_profit=parsed_signal.get('take_profit'),
                        trade_id=trade.id,
                        trailing_stop_id=trailing_position.id if trailing_position else None,
                        signal_indicator=signal_grades.get('signal_indicator'),
                        signal_type=signal_grades.get('signal_type'),
                        signal_grade=signal_grades.get('signal_grade'),
                        signal_score=signal_grades.get('signal_score'),
                        htf_grade=signal_grades.get('htf_grade'),
                        htf_score=signal_grades.get('htf_score'),
                        htf_pass_status=signal_grades.get('htf_pass_status'),
                        trend_strength=signal_grades.get('trend_strength'),
                        signal_timeframe=signal_grades.get('signal_timeframe'),
                        is_open=True,
                        remaining_quantity=parsed_signal['quantity'],
                        exited_quantity=0
                    )
                    db.session.add(completed_trade)
                    db.session.commit()
                    logger.info(f"📊 [{account_type.upper()}] Created CompletedTrade record #{completed_trade.id} for {ts_symbol}")
                    
                    # Also create EntrySignalRecord for forensics tracking
                    try:
                        create_entry_signal_record(
                            symbol=ts_symbol,
                            account_type=account_type,
                            side=ts_side,
                            entry_price=entry_price,
                            quantity=parsed_signal['quantity'],
                            raw_json=raw_data,
                            signal_log_id=signal_log.id if signal_log else None,
                            is_scaling=False,
                            signal_grades=signal_grades,
                            stop_loss=parsed_signal.get('stop_loss'),
                            take_profit=parsed_signal.get('take_profit')
                        )
                    except Exception as esr_error:
                        logger.error(f"📝 [{account_type.upper()}] Failed to create EntrySignalRecord: {str(esr_error)}")
                except Exception as ct_error:
                    db.session.rollback()
                    logger.error(f"📊 [{account_type.upper()}] Failed to create CompletedTrade: {str(ct_error)}")
        
        return {
            'success': result.get('success', False) if 'result' in dir() else False,
            'trade_id': trade.id if trade else None,
            'order_id': result.get('order_id') if 'result' in dir() else None,
            'account_type': account_type,
            'message': f'{account_type.upper()} order placed successfully'
        }
        
    except Exception as e:
        logger.error(f"🔄 [{account_type.upper()}] Error processing signal: {str(e)}")
        db.session.rollback()
        return {'success': False, 'error': str(e), 'account_type': account_type}


@app.route('/webhook_both', methods=['POST'])
def webhook_both():
    """
    Receive TradingView webhook signals and execute on BOTH real and paper accounts
    This allows testing with paper account while also executing real trades
    """
    try:
        client_ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)
        raw_data = request.get_data(as_text=True)
        logger.info(f"🔄 [BOTH] Received webhook from {client_ip}: {raw_data}")
        
        # Log the signal for webhook_both
        signal_log = SignalLog()
        signal_log.raw_signal = raw_data
        signal_log.ip_address = client_ip
        signal_log.endpoint = '/webhook_both'
        signal_log.account_type = 'both'
        
        signal_data = request.get_json()
        if not signal_data:
            signal_log.tiger_status = 'error'
            signal_log.error_message = 'No JSON data received'
            db.session.add(signal_log)
            db.session.commit()
            return jsonify({'success': False, 'error': 'No JSON data received'}), 400
        
        results = {}
        
        # Process for real account
        logger.info("🔄 [BOTH] Processing for REAL account...")
        results['real'] = process_signal_for_account(raw_data, signal_data, client_ip, 'real')
        
        # Process for paper account
        logger.info("🔄 [BOTH] Processing for PAPER account...")
        results['paper'] = process_signal_for_account(raw_data, signal_data, client_ip, 'paper')
        
        # Determine overall success
        overall_success = results['real'].get('success', False) or results['paper'].get('success', False)
        
        # Update signal log with results
        signal_log.parsed_successfully = True
        if results['real'].get('success') and results['paper'].get('success'):
            signal_log.tiger_status = 'success'
        elif results['real'].get('success') or results['paper'].get('success'):
            signal_log.tiger_status = 'partial'
        else:
            signal_log.tiger_status = 'error'
        
        # Collect order IDs
        order_ids = []
        if results['real'].get('order_id'):
            order_ids.append(f"Real:{results['real']['order_id']}")
        if results['paper'].get('order_id'):
            order_ids.append(f"Paper:{results['paper']['order_id']}")
        signal_log.tiger_order_id = ', '.join(order_ids) if order_ids else None
        signal_log.tiger_response = json.dumps(results, ensure_ascii=False, indent=2)
        
        db.session.add(signal_log)
        db.session.commit()
        
        # Send Discord notification for both
        try:
            discord_notifier.send_both_accounts_notification(results)
        except Exception as e:
            logger.error(f"🔄 [BOTH] Failed to send Discord notification: {str(e)}")
        
        return jsonify({
            'success': overall_success,
            'message': 'Signal processed for both accounts',
            'results': results
        })
        
    except Exception as e:
        logger.error(f"🔄 [BOTH] Critical error in webhook_both: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500


@app.route('/trades')
def trades():
    """View all trades with real-time status from Tiger API"""
    page = request.args.get('page', 1, type=int)
    per_page = 20
    account_type = request.args.get('account_type', 'all')  # all, real, paper
    
    trades_query = Trade.query
    
    # Filter by account type
    if account_type == 'real':
        trades_query = trades_query.filter(
            db.or_(Trade.account_type == 'real', Trade.account_type == None)
        )
    elif account_type == 'paper':
        trades_query = trades_query.filter(Trade.account_type == 'paper')
    
    trades_query = trades_query.order_by(Trade.created_at.desc())
    trades_pagination = trades_query.paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    # Get real-time status for each trade with Tiger order ID
    # Use appropriate client based on trade's account_type
    tiger_real_client = None
    tiger_paper_client = None
    
    for trade in trades_pagination.items:
        if trade.tiger_order_id:
            try:
                # Select appropriate client based on trade's account type
                if trade.account_type == 'paper':
                    if tiger_paper_client is None:
                        tiger_paper_client = TigerPaperClient()
                    tiger_client = tiger_paper_client
                else:
                    if tiger_real_client is None:
                        tiger_real_client = TigerClient()
                    tiger_client = tiger_real_client
                
                status_update = tiger_client.get_order_status(trade.tiger_order_id)
                if status_update['success']:
                    # Update real-time status and price data
                    trade.real_time_status = status_update['status']
                    trade.real_time_filled_price = status_update.get('filled_price', 0)
                    trade.real_time_filled_quantity = status_update.get('filled_quantity', 0)
                    trade.tiger_status_info = status_update.get('tiger_status', '')
                else:
                    trade.real_time_status = trade.status.value
                    trade.real_time_filled_price = trade.filled_price
                    trade.real_time_filled_quantity = trade.filled_quantity
                    trade.tiger_status_info = 'Error fetching'
            except Exception as e:
                logger.error(f"Error getting real-time status for trade {trade.id}: {str(e)}")
                trade.real_time_status = trade.status.value
                trade.real_time_filled_price = trade.filled_price
                trade.real_time_filled_quantity = trade.filled_quantity
                trade.tiger_status_info = 'Error'
        else:
            # No Tiger order ID, use database values
            trade.real_time_status = trade.status.value
            trade.real_time_filled_price = trade.filled_price
            trade.real_time_filled_quantity = trade.filled_quantity
            trade.tiger_status_info = 'No Tiger Order ID'
    
    return render_template('trades.html', 
                         trades=trades_pagination.items,
                         pagination=trades_pagination,
                         account_type=account_type)

@app.route('/config', methods=['GET', 'POST'])
def config():
    """Configuration management"""
    if request.method == 'POST':
        try:
            # Update configurations
            for key in ['TIGER_API_KEY', 'TIGER_SECRET_KEY', 'TIGER_ACCOUNT', 
                       'MAX_TRADE_AMOUNT', 'TRADING_ENABLED', 'DISCORD_WEBHOOK_URL', 
                       'DISCORD_TTS_WEBHOOK_URL']:
                value = request.form.get(key, '')
                if value:
                    set_config(key, value)
            
            flash('Configuration updated successfully!', 'success')
            return redirect(url_for('config'))
            
        except Exception as e:
            flash(f'Error updating configuration: {str(e)}', 'error')
    
    # Get current configurations
    configs = {
        'TIGER_API_KEY': get_config('TIGER_API_KEY', ''),
        'TIGER_SECRET_KEY': get_config('TIGER_SECRET_KEY', ''),
        'TIGER_ACCOUNT': get_config('TIGER_ACCOUNT', ''),
        'MAX_TRADE_AMOUNT': get_config('MAX_TRADE_AMOUNT', '1000000'),
        'TRADING_ENABLED': get_config('TRADING_ENABLED', 'true'),
        'DISCORD_WEBHOOK_URL': get_config('DISCORD_WEBHOOK_URL', ''),
        'DISCORD_TTS_WEBHOOK_URL': get_config('DISCORD_TTS_WEBHOOK_URL', '')
    }
    
    return render_template('config.html', configs=configs)

@app.route('/trade/<int:trade_id>')
def trade_detail(trade_id):
    """View detailed information for a specific trade"""
    trade = Trade.query.get_or_404(trade_id)
    
    # Parse JSON data for display
    signal_json = None
    tiger_response_json = None
    
    try:
        if trade.signal_data:
            signal_json = json.loads(trade.signal_data)
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"Error parsing signal data for trade {trade_id}: {e}")
        signal_json = {"error": "Invalid JSON data"}
    
    try:
        if trade.tiger_response:
            tiger_response_json = json.loads(trade.tiger_response)
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"Error parsing tiger response for trade {trade_id}: {e}")
        tiger_response_json = {"error": "Invalid JSON data"}
    
    return render_template('trade_detail.html', 
                         trade=trade,
                         signal_json=signal_json,
                         tiger_response_json=tiger_response_json)

@app.route('/set_position_protection', methods=['POST'])
def set_position_protection():
    """Set stop loss and take profit for existing position"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        symbol = data.get('symbol', '').upper().strip()
        quantity = data.get('quantity', 0)
        stop_loss = data.get('stop_loss')
        take_profit = data.get('take_profit')
        
        # Validation
        if not symbol:
            return jsonify({
                'success': False,
                'error': 'Symbol is required'
            }), 400
        
        if quantity <= 0:
            return jsonify({
                'success': False,
                'error': 'Quantity must be greater than 0'
            }), 400
            
        if not stop_loss and not take_profit:
            return jsonify({
                'success': False,
                'error': 'At least one of stop_loss or take_profit must be provided'
            }), 400
        
        # Convert to float if provided
        try:
            stop_loss_price = float(stop_loss) if stop_loss else None
            take_profit_price = float(take_profit) if take_profit else None
        except (ValueError, TypeError):
            return jsonify({
                'success': False,
                'error': 'Invalid price format'
            }), 400
        
        logger.info(f"Setting position protection for {symbol}: {quantity} shares, "
                   f"stop_loss: {stop_loss_price}, take_profit: {take_profit_price}")
        
        # Create OCA orders through Tiger client
        tiger_client = TigerClient()
        result = tiger_client.create_oca_orders_for_position(
            symbol=symbol,
            quantity=quantity,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price
        )
        
        if result['success']:
            # Create a new trade record for tracking
            trade = Trade()
            trade.symbol = symbol
            trade.side = Side.SELL  # These are protective orders
            trade.quantity = quantity
            trade.order_type = OrderType.LIMIT
            trade.price = 0.0  # No main order price for OCA
            trade.stop_loss_price = stop_loss_price
            trade.take_profit_price = take_profit_price
            trade.status = OrderStatus.PENDING
            trade.tiger_order_id = result.get('order_id')
            trade.stop_loss_order_id = result.get('stop_loss_order_id')
            trade.take_profit_order_id = result.get('take_profit_order_id')
            trade.trading_session = 'regular'
            trade.outside_rth = True
            trade.signal_data = json.dumps({
                'action': 'protect_position',
                'symbol': symbol,
                'quantity': quantity,
                'stop_loss': stop_loss_price,
                'take_profit': take_profit_price,
                'strategy': 'Position Protection OCA Orders'
            })
            trade.tiger_response = json.dumps(result)
            
            db.session.add(trade)
            db.session.commit()
            
            # Send Discord notification
            try:
                discord_notifier.send_order_notification(trade, 'pending')
            except Exception as e:
                logger.error(f"Failed to send Discord notification: {str(e)}")
            
            logger.info(f"Position protection set successfully for {symbol}")
            
            return jsonify({
                'success': True,
                'message': result.get('message'),
                'order_id': result.get('order_id'),
                'stop_loss_order_id': result.get('stop_loss_order_id'),
                'take_profit_order_id': result.get('take_profit_order_id'),
                'trade_id': trade.id
            })
        else:
            logger.error(f"Failed to set position protection: {result.get('error')}")
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"Error in set_position_protection: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/trade/<int:trade_id>/status')
def trade_status(trade_id):
    """Get trade status update"""
    trade = Trade.query.get_or_404(trade_id)
    
    # Update status from Tiger if order ID exists
    if trade.tiger_order_id:
        tiger_client = TigerClient()
        status_update = tiger_client.get_order_status(trade.tiger_order_id)
        
        if status_update['success']:
            old_status = trade.status.value
            new_status = status_update['status']
            
            logger.info(f"Trade {trade_id} status comparison: old='{old_status}', new='{new_status}', tiger_status='{status_update.get('tiger_status')}'")
            logger.info(f"Status update data: {status_update}")
            
            # Map status if it changed
            if old_status != new_status:
                try:
                    trade.status = OrderStatus(new_status)
                    trade.filled_price = status_update.get('filled_price')
                    trade.filled_quantity = status_update.get('filled_quantity') 
                    trade.updated_at = datetime.utcnow()
                    
                    db.session.commit()
                    logger.info(f"Trade {trade_id} status updated: {old_status} -> {new_status}")
                    
                    # Send Discord notification for significant status changes
                    if new_status in ['filled', 'partially_filled']:
                        # Use the is_close_position flag to determine if this is a close trade
                        is_close_trade = getattr(trade, 'is_close_position', False)
                        
                        discord_notifier.send_order_notification(trade, new_status, is_close=is_close_trade)
                    
                except ValueError as e:
                    logger.error(f"Unknown status from Tiger: {new_status}, error: {e}")
            else:
                # Still update prices even if status same
                trade.filled_price = status_update.get('filled_price')
                trade.filled_quantity = status_update.get('filled_quantity')
                if status_update.get('filled_price'):
                    db.session.commit()
                    logger.info(f"Trade {trade_id} price updated: {status_update.get('filled_price')}")
    
    # Return real-time status from Tiger API if available
    real_time_status = trade.status.value
    real_time_filled_price = trade.filled_price
    real_time_filled_quantity = trade.filled_quantity
    tiger_status_info = 'Database'
    
    if trade.tiger_order_id:
        try:
            tiger_client_fresh = TigerClient()
            status_update_fresh = tiger_client_fresh.get_order_status(trade.tiger_order_id)
            if status_update_fresh['success']:
                real_time_status = status_update_fresh['status']
                real_time_filled_price = status_update_fresh.get('filled_price', 0) or trade.filled_price
                real_time_filled_quantity = status_update_fresh.get('filled_quantity', 0) or trade.filled_quantity
                tiger_status_info = f"Live: {status_update_fresh.get('tiger_status', 'Unknown')}"
        except Exception as e:
            logger.error(f"Error getting fresh status for trade {trade_id}: {str(e)}")
    
    return jsonify({
        'id': trade.id,
        'status': real_time_status,
        'filled_price': real_time_filled_price,
        'filled_quantity': real_time_filled_quantity,
        'error_message': trade.error_message,
        'updated_at': trade.updated_at.isoformat(),
        'tiger_status_info': tiger_status_info,
        'is_live_data': trade.tiger_order_id is not None
    })

@app.route('/positions')
def positions():
    """View current positions"""
    try:
        tiger_client = TigerClient()
        result = tiger_client.get_positions()
        
        if result['success']:
            positions_data = result['positions']
            total_market_value = sum(pos['market_value'] for pos in positions_data if pos['market_value'])
            total_pnl = sum(pos['unrealized_pnl'] for pos in positions_data if pos['unrealized_pnl'])
        else:
            positions_data = []
            total_market_value = 0
            total_pnl = 0
            flash(f"Error fetching positions: {result['error']}", 'error')
        
        return render_template('positions.html', 
                             positions=positions_data,
                             total_market_value=total_market_value,
                             total_pnl=total_pnl)
    
    except Exception as e:
        logger.error(f"Error in positions route: {str(e)}")
        flash(f"Error: {str(e)}", 'error')
        return render_template('positions.html', 
                             positions=[],
                             total_market_value=0,
                             total_pnl=0)

@app.route('/closed-trades')
def closed_trades():
    """Display closed trades with realized P&L and forensic tracking (已平仓交易记录 + 溯源追踪)"""
    try:
        from pytz import timezone
        eastern = timezone('US/Eastern')
        
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        symbol = request.args.get('symbol')
        account_type = request.args.get('account_type', 'real')
        
        # Query ClosedPosition records with entry signals
        query = ClosedPosition.query.filter_by(account_type=account_type)
        
        if symbol:
            query = query.filter(ClosedPosition.symbol.ilike(f'%{symbol}%'))
        
        if start_date:
            try:
                start_dt = datetime.strptime(start_date, '%Y-%m-%d')
                query = query.filter(ClosedPosition.exit_time >= start_dt)
            except ValueError:
                pass
        
        if end_date:
            try:
                end_dt = datetime.strptime(end_date, '%Y-%m-%d')
                end_dt = end_dt.replace(hour=23, minute=59, second=59)
                query = query.filter(ClosedPosition.exit_time <= end_dt)
            except ValueError:
                pass
        
        closed_positions = query.order_by(ClosedPosition.exit_time.desc()).limit(100).all()
        
        # Format data for template
        trades_data = []
        for cp in closed_positions:
            # Convert exit time to Eastern
            exit_time_et = None
            exit_time_str = ''
            if cp.exit_time:
                exit_time_et = cp.exit_time.replace(tzinfo=timezone('UTC')).astimezone(eastern)
                exit_time_str = exit_time_et.strftime('%Y-%m-%d %H:%M:%S ET')
            
            # Get linked entry signals
            entry_signals = []
            for entry in cp.entry_signals:
                entry_time_str = ''
                if entry.entry_time:
                    entry_et = entry.entry_time.replace(tzinfo=timezone('UTC')).astimezone(eastern)
                    entry_time_str = entry_et.strftime('%Y-%m-%d %H:%M:%S ET')
                
                entry_signals.append({
                    'id': entry.id,
                    'entry_time': entry_time_str,
                    'entry_type': 'scaling' if entry.is_scaling else 'initial',
                    'quantity': entry.quantity,
                    'entry_price': entry.entry_price,
                    'entry_order_id': entry.entry_order_id,
                    'contribution_pnl': entry.contribution_pnl,
                    'contribution_pct': entry.contribution_pct,
                    'indicator_trigger': entry.indicator_trigger,
                    'original_signal': entry.raw_json
                })
            
            trades_data.append({
                'id': cp.id,
                'symbol': cp.symbol,
                'side': cp.side,
                'exit_time': exit_time_str,
                'exit_price': cp.exit_price,
                'exit_quantity': cp.exit_quantity,
                'exit_method': cp.exit_method.value if cp.exit_method else 'unknown',
                'exit_indicator': cp.exit_indicator,
                'total_pnl': cp.total_pnl or 0,
                'total_pnl_pct': cp.total_pnl_pct or 0,
                'avg_entry_price': cp.avg_entry_price,
                'entry_signals': entry_signals,
                'entry_count': len(entry_signals),
                'exit_signal_content': cp.exit_signal_content
            })
        
        # Calculate totals
        total_pnl = sum(t['total_pnl'] for t in trades_data)
        winning_trades = [t for t in trades_data if t['total_pnl'] > 0]
        losing_trades = [t for t in trades_data if t['total_pnl'] < 0]
        win_rate = (len(winning_trades) / len(trades_data) * 100) if trades_data else 0
        
        # Calculate Profit Factor = Total Wins / Total Losses
        total_wins = sum(t['total_pnl'] for t in winning_trades)
        total_losses = abs(sum(t['total_pnl'] for t in losing_trades))
        profit_factor = (total_wins / total_losses) if total_losses > 0 else (float('inf') if total_wins > 0 else 0)
        
        return render_template('closed_trades.html',
                             trades=trades_data,
                             total_pnl=total_pnl,
                             total_trades=len(trades_data),
                             winning_count=len(winning_trades),
                             losing_count=len(losing_trades),
                             win_rate=win_rate,
                             profit_factor=profit_factor,
                             start_date=start_date,
                             end_date=end_date,
                             symbol_filter=symbol,
                             account_type=account_type)
    
    except Exception as e:
        logger.error(f"Error in closed_trades route: {str(e)}")
        import traceback
        traceback.print_exc()
        flash(f"Error: {str(e)}", 'error')
        return render_template('closed_trades.html',
                             trades=[],
                             total_pnl=0,
                             total_trades=0,
                             winning_count=0,
                             losing_count=0,
                             win_rate=0,
                             profit_factor=0,
                             start_date=None,
                             end_date=None,
                             symbol_filter=None,
                             account_type='real')

@app.route('/signal-logs')
def signal_logs():
    """Display all webhook signals received and Tiger API response status"""
    try:
        import json as json_lib
        endpoint_filter = request.args.get('ep')
        symbol_filter = request.args.get('symbol', '').strip().upper()
        status_filter = request.args.get('status', '').strip().lower()
        
        query = SignalLog.query.order_by(SignalLog.created_at.desc())
        
        if endpoint_filter:
            query = query.filter(SignalLog.endpoint == f'/{endpoint_filter}')
        
        if symbol_filter:
            query = query.filter(SignalLog.raw_signal.ilike(f'%"{symbol_filter}"%'))
        
        if status_filter:
            query = query.filter(SignalLog.tiger_status == status_filter)
        
        signals = query.limit(200).all()
        
        def extract_symbol(raw_signal):
            """Extract symbol from raw signal with multiple format support"""
            if not raw_signal:
                return None
            try:
                data = json_lib.loads(raw_signal)
                sym = data.get('ticker') or data.get('symbol')
                if sym:
                    return sym.upper().strip()
            except:
                pass
            # Try to extract from text format (e.g., "AAPL buy 100")
            import re
            match = re.search(r'"(?:ticker|symbol)"\s*:\s*"([A-Z]+)"', raw_signal, re.IGNORECASE)
            if match:
                return match.group(1).upper()
            return None
        
        for signal in signals:
            signal.symbol = extract_symbol(signal.raw_signal)
        
        all_symbols = set()
        for signal in signals:
            if signal.symbol:
                all_symbols.add(signal.symbol)
        
        return render_template('signal_logs.html',
                             signals=signals,
                             endpoint_filter=endpoint_filter,
                             symbol_filter=symbol_filter,
                             status_filter=status_filter,
                             all_symbols=sorted(all_symbols))
    
    except Exception as e:
        logger.error(f"Error in signal_logs route: {str(e)}")
        flash(f"Error: {str(e)}", 'error')
        return render_template('signal_logs.html',
                             signals=[],
                             endpoint_filter=None,
                             symbol_filter='',
                             status_filter='',
                             all_symbols=[])

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'trading_enabled': get_config('TRADING_ENABLED', 'true') == 'true'
    })

@app.route('/api/debug/orders/<symbol>')
def debug_orders(symbol):
    """Debug route to check open orders for a symbol"""
    try:
        tiger_client = TigerClient()
        if not tiger_client:
            return jsonify({'error': 'Tiger client not available'}), 500
        
        result = tiger_client.get_open_orders_for_symbol(symbol)
        if not result['success']:
            return jsonify({'error': result['error']}), 500
            
        orders_info = []
        for order in result['orders']:
            order_info = {
                'id': getattr(order, 'id', 'unknown'),
                'action': getattr(order, 'action', 'unknown'), 
                'quantity': getattr(order, 'quantity', 'unknown'),
                'status': getattr(order, 'status', 'unknown'),
                'can_cancel': getattr(order, 'can_cancel', 'unknown'),
                'order_type': getattr(order, 'order_type', 'unknown'),
                'limit_price': getattr(order, 'limit_price', None),
                'aux_price': getattr(order, 'aux_price', None),
            }
            orders_info.append(order_info)
        
        return jsonify({
            'success': True,
            'symbol': symbol,
            'order_count': len(result['orders']),
            'orders': orders_info
        })
    
    except Exception as e:
        logger.error(f"Error debugging orders for {symbol}: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/cancel-orders/<symbol>', methods=['POST'])
def cancel_orders_for_symbol(symbol):
    """Cancel all open orders for a symbol"""
    try:
        tiger_client = TigerClient()
        if not tiger_client:
            return jsonify({'error': 'Tiger client not available'}), 500
        
        logger.info(f"Attempting to cancel all orders for {symbol}")
        result = tiger_client.force_cancel_all_orders_for_symbol(symbol)
        
        if result['success']:
            canceled_count = result.get('canceled_count', 0)
            total_orders = result.get('total_orders', 0)
            errors = result.get('errors', [])
            
            logger.info(f"Successfully canceled {canceled_count} out of {total_orders} orders for {symbol}")
            
            return jsonify({
                'success': True,
                'symbol': symbol,
                'canceled_count': canceled_count,
                'total_orders': total_orders,
                'errors': errors,
                'message': f"Canceled {canceled_count} out of {total_orders} orders for {symbol}"
            })
        else:
            logger.error(f"Failed to cancel orders for {symbol}: {result['error']}")
            return jsonify({'error': result['error']}), 500
    
    except Exception as e:
        logger.error(f"Error canceling orders for {symbol}: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/trailing-stop')
def trailing_stop():
    """Trailing stop management page"""
    try:
        from models import TrailingStopPosition, TrailingStopConfig
        from trailing_stop_engine import get_trailing_stop_config
        from tiger_client import TigerClient
        from datetime import datetime, timedelta
        
        config = get_trailing_stop_config()
        
        positions = TrailingStopPosition.query.filter_by(is_active=True).all()
        active_count = len(positions)
        switched_count = sum(1 for p in positions if p.has_switched_to_trailing)
        
        if positions:
            from trailing_stop_engine import get_cached_tiger_positions
            tiger_positions = get_cached_tiger_positions()
            
            for pos in positions:
                clean_symbol = pos.symbol.replace('[PAPER]', '').strip()
                account_positions = tiger_positions.get(pos.account_type, {})
                tiger_pos = account_positions.get(clean_symbol)
                
                if tiger_pos:
                    avg_cost = tiger_pos.get('average_cost', 0)
                    quantity = abs(tiger_pos.get('quantity', 0))
                    unrealized_pnl = tiger_pos.get('unrealized_pnl', 0)
                    
                    if avg_cost and quantity:
                        pos.display_profit_pct = (unrealized_pnl / (avg_cost * quantity)) * 100
                    else:
                        pos.display_profit_pct = None
                    
                    market_value = tiger_pos.get('market_value', 0)
                    if market_value and quantity:
                        pos.current_price = abs(market_value / quantity)
                    else:
                        pos.current_price = None
                else:
                    pos.current_price = None
                    pos.display_profit_pct = None
        
        today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        triggered_today = TrailingStopPosition.query.filter(
            TrailingStopPosition.is_triggered == True,
            TrailingStopPosition.triggered_at >= today_start
        ).count()
        
        recent_triggers = TrailingStopPosition.query.filter_by(
            is_triggered=True
        ).order_by(TrailingStopPosition.triggered_at.desc()).limit(10).all()
        
        return render_template('trailing_stop.html',
                             config=config,
                             positions=positions,
                             active_count=active_count,
                             switched_count=switched_count,
                             triggered_today=triggered_today,
                             recent_triggers=recent_triggers)
    
    except Exception as e:
        logger.error(f"Error in trailing_stop route: {str(e)}")
        flash(f"Error: {str(e)}", 'error')
        from trailing_stop_engine import get_trailing_stop_config
        return render_template('trailing_stop.html',
                             config=get_trailing_stop_config(),
                             positions=[],
                             active_count=0,
                             switched_count=0,
                             triggered_today=0,
                             recent_triggers=[])


@app.route('/trailing-stop/config', methods=['GET', 'POST'])
def trailing_stop_config():
    """Trailing stop configuration page"""
    try:
        from trailing_stop_engine import get_trailing_stop_config
        
        config = get_trailing_stop_config()
        
        if request.method == 'POST':
            config.atr_period = int(request.form.get('atr_period', 14))
            config.tier_0_threshold = float(request.form.get('tier_0_threshold', 0.01))
            config.tier_1_threshold = float(request.form.get('tier_1_threshold', 0.03))
            config.tier_0_multiplier = float(request.form.get('tier_0_multiplier', 2.5))
            config.tier_1_multiplier = float(request.form.get('tier_1_multiplier', 2.0))
            config.tier_2_multiplier = float(request.form.get('tier_2_multiplier', 1.5))
            config.low_volatility_threshold = float(request.form.get('low_volatility_threshold', 0.008))
            config.high_volatility_threshold = float(request.form.get('high_volatility_threshold', 0.015))
            config.low_volatility_factor = float(request.form.get('low_volatility_factor', 0.8))
            config.mid_volatility_factor = float(request.form.get('mid_volatility_factor', 1.0))
            config.high_volatility_factor = float(request.form.get('high_volatility_factor', 1.2))
            config.dynamic_pct_tier1_upper = float(request.form.get('dynamic_pct_tier1_upper', 0.02))
            config.dynamic_pct_tier2_upper = float(request.form.get('dynamic_pct_tier2_upper', 0.05))
            config.dynamic_pct_tier1_percent = float(request.form.get('dynamic_pct_tier1_percent', 0.002))
            config.dynamic_pct_tier2_percent = float(request.form.get('dynamic_pct_tier2_percent', 0.005))
            config.switch_profit_ratio = float(request.form.get('switch_profit_ratio', 0.90))
            config.switch_profit_ratio_strong = float(request.form.get('switch_profit_ratio_strong', 0.95))
            config.post_switch_multiplier = float(request.form.get('post_switch_multiplier', 1.2))
            config.post_switch_trail_pct = float(request.form.get('post_switch_trail_pct', 0.05))
            config.check_interval_seconds = int(request.form.get('check_interval_seconds', 30))
            config.max_percent_stop = float(request.form.get('max_percent_stop', 0.008))
            config.trend_strength_threshold = float(request.form.get('trend_strength_threshold', 60.0))
            config.momentum_lookback = int(request.form.get('momentum_lookback', 5))
            config.atr_convergence_weight = float(request.form.get('atr_convergence_weight', 0.3))
            config.momentum_weight = float(request.form.get('momentum_weight', 0.4))
            config.consecutive_weight = float(request.form.get('consecutive_weight', 0.3))
            config.progressive_stop_enabled = 'progressive_stop_enabled' in request.form
            config.prog_tier1_profit = float(request.form.get('prog_tier1_profit', 0.01))
            config.prog_tier1_stop_at = float(request.form.get('prog_tier1_stop_at', 0.0))
            config.prog_tier2_profit = float(request.form.get('prog_tier2_profit', 0.03))
            config.prog_tier2_stop_at = float(request.form.get('prog_tier2_stop_at', 0.01))
            config.prog_tier3_profit = float(request.form.get('prog_tier3_profit', 0.05))
            config.prog_tier3_stop_at = float(request.form.get('prog_tier3_stop_at', 0.03))
            config.prog_tier4_profit = float(request.form.get('prog_tier4_profit', 0.08))
            config.prog_tier4_stop_at = float(request.form.get('prog_tier4_stop_at', 0.05))
            config.is_enabled = 'is_enabled' in request.form
            
            db.session.commit()
            flash('配置已保存', 'success')
            return redirect(url_for('trailing_stop'))
        
        return render_template('trailing_stop_config.html', config=config)
    
    except Exception as e:
        logger.error(f"Error in trailing_stop_config route: {str(e)}")
        flash(f"Error: {str(e)}", 'error')
        return redirect(url_for('trailing_stop'))


@app.route('/api/trailing-stop/check', methods=['POST'])
def api_trailing_stop_check():
    """Manually trigger trailing stop check for all positions"""
    try:
        from trailing_stop_engine import process_all_active_positions
        
        results = process_all_active_positions()
        
        triggered_count = sum(1 for r in results if r.get('action') == 'trigger')
        switched_count = sum(1 for r in results if r.get('action') == 'switch')
        
        return jsonify({
            'success': True,
            'checked': len(results),
            'triggered': triggered_count,
            'switched': switched_count,
            'message': f'检查完成: {len(results)}个持仓, {triggered_count}个触发, {switched_count}个切换'
        })
    
    except Exception as e:
        logger.error(f"Error in trailing stop check: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/trailing-stop/deactivate/<int:position_id>', methods=['POST'])
def api_trailing_stop_deactivate(position_id):
    """Deactivate a trailing stop position"""
    try:
        from models import TrailingStopPosition
        
        position = TrailingStopPosition.query.get(position_id)
        if not position:
            return jsonify({'success': False, 'message': '未找到该持仓'}), 404
        
        position.is_active = False
        position.trigger_reason = "手动停用"
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{position.symbol} 追踪已停用'
        })
    
    except Exception as e:
        logger.error(f"Error deactivating trailing stop: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/trailing-stop/create', methods=['POST'])
def api_trailing_stop_create():
    """Create a new trailing stop position manually"""
    try:
        from trailing_stop_engine import create_trailing_stop_for_trade
        from models import TrailingStopMode
        
        data = request.get_json()
        
        symbol = data.get('symbol')
        side = data.get('side', 'long')
        entry_price = float(data.get('entry_price', 0))
        quantity = float(data.get('quantity', 0))
        account_type = data.get('account_type', 'real')
        fixed_stop_loss = float(data.get('fixed_stop_loss')) if data.get('fixed_stop_loss') else None
        fixed_take_profit = float(data.get('fixed_take_profit')) if data.get('fixed_take_profit') else None
        
        if not symbol or not entry_price or not quantity:
            return jsonify({'success': False, 'message': '缺少必要参数'}), 400
        
        position = create_trailing_stop_for_trade(
            trade_id=None,
            symbol=symbol,
            side=side,
            entry_price=entry_price,
            quantity=quantity,
            account_type=account_type,
            fixed_stop_loss=fixed_stop_loss,
            fixed_take_profit=fixed_take_profit
        )
        
        return jsonify({
            'success': True,
            'position_id': position.id,
            'message': f'{symbol} 追踪止损已创建'
        })
    
    except Exception as e:
        logger.error(f"Error creating trailing stop: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/trailing-stop/scheduler-status')
def api_trailing_stop_scheduler_status():
    """Get the status of the trailing stop scheduler"""
    try:
        from trailing_stop_scheduler import get_scheduler_status
        status = get_scheduler_status()
        return jsonify({
            'success': True,
            **status
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/tiger/open-orders')
def api_tiger_open_orders():
    """Query Tiger API for open orders (including stop loss / take profit)"""
    try:
        from tiger_client import TigerClient
        
        account_type = request.args.get('account', 'paper')
        symbol_filter = request.args.get('symbol', None)
        
        tiger = TigerClient()
        
        account = '21655301822151141' if account_type == 'paper' else '50904193'
        tiger.account = account
        
        open_orders = tiger.client.get_open_orders(account=account)
        
        result = []
        for order in open_orders:
            order_symbol = order.contract.symbol if hasattr(order, 'contract') else 'N/A'
            
            if symbol_filter and order_symbol != symbol_filter:
                continue
            
            result.append({
                'id': str(order.id) if hasattr(order, 'id') else None,
                'symbol': order_symbol,
                'action': order.action if hasattr(order, 'action') else None,
                'order_type': str(order.order_type) if hasattr(order, 'order_type') else None,
                'quantity': order.quantity if hasattr(order, 'quantity') else None,
                'limit_price': order.limit_price if hasattr(order, 'limit_price') else None,
                'aux_price': order.aux_price if hasattr(order, 'aux_price') else None,
                'status': str(order.status) if hasattr(order, 'status') else None,
                'parent_id': str(order.parent_id) if hasattr(order, 'parent_id') and order.parent_id else None,
                'time_in_force': str(order.time_in_force) if hasattr(order, 'time_in_force') else None,
                'outside_rth': order.outside_rth if hasattr(order, 'outside_rth') else None,
            })
        
        return jsonify({
            'success': True,
            'account': account_type,
            'count': len(result),
            'orders': result
        })
    except Exception as e:
        logger.error(f"Error fetching open orders: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/trailing-stop/sync', methods=['POST'])
def api_trailing_stop_sync():
    """Synchronize all active trailing stop positions with Tiger API order status"""
    try:
        from trailing_stop_engine import sync_all_active_positions
        from tiger_client import TigerClient
        
        # Get tiger client
        tiger = TigerClient()
        if not tiger:
            return jsonify({
                'success': False,
                'message': 'Tiger client not available'
            }), 500
        
        # Run sync
        results = sync_all_active_positions(tiger)
        
        # Count issues and fixes
        total_positions = len(results)
        total_issues = sum(len(r.get('issues_found', [])) for r in results)
        total_fixes = sum(len(r.get('fixes_applied', [])) for r in results)
        
        return jsonify({
            'success': True,
            'positions_checked': total_positions,
            'issues_found': total_issues,
            'fixes_applied': total_fixes,
            'details': results,
            'message': f'同步完成: 检查{total_positions}个仓位, 发现{total_issues}个问题, 修复{total_fixes}个'
        })
    
    except Exception as e:
        logger.error(f"Error syncing trailing stops: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/sync-completed-trades', methods=['POST'])
def api_sync_completed_trades():
    """Sync CompletedTrade records with ClosedPosition data to fix is_open status"""
    try:
        from models import CompletedTrade, ClosedPosition
        
        synced_count = 0
        
        # Find all open CompletedTrades
        open_trades = CompletedTrade.query.filter_by(is_open=True).all()
        
        for trade in open_trades:
            # Try to find matching ClosedPosition
            closed_pos = ClosedPosition.query.filter_by(
                symbol=trade.symbol,
                account_type=trade.account_type
            ).order_by(ClosedPosition.exit_time.desc()).first()
            
            if closed_pos and closed_pos.exit_time:
                # Check if closed_pos exit_time is after trade entry_time
                if trade.entry_time and closed_pos.exit_time > trade.entry_time:
                    trade.is_open = False
                    trade.exit_time = closed_pos.exit_time
                    trade.exit_price = closed_pos.exit_price
                    trade.exit_quantity = closed_pos.exit_quantity
                    trade.exit_method = closed_pos.exit_method
                    trade.pnl_amount = closed_pos.total_pnl
                    trade.pnl_percent = closed_pos.total_pnl_pct
                    trade.remaining_quantity = 0
                    
                    if trade.entry_time:
                        hold_seconds = int((closed_pos.exit_time - trade.entry_time).total_seconds())
                        trade.hold_duration_seconds = hold_seconds
                    
                    synced_count += 1
                    logger.info(f"Synced CompletedTrade #{trade.id} ({trade.symbol}) with ClosedPosition #{closed_pos.id}")
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'synced_count': synced_count,
            'message': f'同步完成: 更新了{synced_count}条CompletedTrade记录'
        })
        
    except Exception as e:
        logger.error(f"Error syncing completed trades: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/fix-historical-data', methods=['POST'])
def api_fix_historical_data():
    """
    One-time fix: Pull historical filled orders from Tiger API and update CompletedTrade status.
    This fixes is_open=True records that should be closed.
    
    POST body (optional):
    - days: Number of days to look back (default 7)
    - account_type: 'paper', 'real', or 'both' (default 'both')
    - dry_run: If true, only report what would be fixed (default false)
    """
    try:
        from models import CompletedTrade, ClosedPosition, Trade, ExitMethod
        from datetime import datetime, timedelta
        
        data = request.get_json() or {}
        days = data.get('days', 7)
        account_type_filter = data.get('account_type', 'both')
        dry_run = data.get('dry_run', False)
        
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        results = {
            'fixed_count': 0,
            'skipped_count': 0,
            'error_count': 0,
            'details': [],
            'dry_run': dry_run
        }
        
        account_types = []
        if account_type_filter in ['paper', 'both']:
            account_types.append(('paper', TigerPaperClient))
        if account_type_filter in ['real', 'both']:
            account_types.append(('real', TigerClient))
        
        for account_type, client_class in account_types:
            try:
                client = client_class()
                filled_result = client.get_filled_orders(start_date=start_date, end_date=end_date)
                
                if not filled_result.get('success'):
                    results['details'].append(f"{account_type}: Failed to get filled orders")
                    continue
                
                orders = filled_result.get('orders', [])
                results['details'].append(f"{account_type}: Found {len(orders)} filled orders")
                
                # Group by symbol to find exit orders
                for order in orders:
                    try:
                        order_id = str(order.get('order_id', ''))
                        symbol = order.get('symbol', '')
                        action = order.get('action', '').upper()
                        avg_fill_price = order.get('avg_fill_price', 0)
                        filled_qty = order.get('filled', 0)
                        fill_time = order.get('trade_time')
                        
                        # Check if this is a SELL order (exit for long position)
                        if action != 'SELL':
                            continue
                        
                        # Find open CompletedTrade for this symbol (search both clean and legacy [PAPER] prefix)
                        from sqlalchemy import or_
                        symbol_variants = [symbol]
                        if account_type == 'paper':
                            symbol_variants.append(f"[PAPER]{symbol}")
                        open_trade = CompletedTrade.query.filter(
                            or_(*[CompletedTrade.symbol == s for s in symbol_variants]),
                            CompletedTrade.account_type == account_type,
                            CompletedTrade.is_open == True
                        ).order_by(CompletedTrade.entry_time.asc()).first()
                        
                        if not open_trade:
                            continue
                        
                        # Parse fill time
                        exit_time = datetime.utcnow()
                        if fill_time:
                            try:
                                if isinstance(fill_time, (int, float)):
                                    exit_time = datetime.fromtimestamp(fill_time / 1000)
                                elif isinstance(fill_time, str):
                                    exit_time = datetime.fromisoformat(fill_time.replace('Z', '+00:00'))
                            except:
                                pass
                        
                        # Calculate P&L
                        entry_price = open_trade.entry_price or 0
                        pnl = None
                        pnl_pct = None
                        if entry_price and avg_fill_price and open_trade.entry_quantity:
                            pnl = (avg_fill_price - entry_price) * open_trade.entry_quantity
                            pnl_pct = (avg_fill_price - entry_price) / entry_price * 100
                        
                        # Determine exit method
                        exit_method = ExitMethod.WEBHOOK_SIGNAL
                        if open_trade.original_stop_loss and avg_fill_price <= open_trade.original_stop_loss * 1.01:
                            exit_method = ExitMethod.STOP_LOSS
                        elif open_trade.original_take_profit and avg_fill_price >= open_trade.original_take_profit * 0.99:
                            exit_method = ExitMethod.TAKE_PROFIT
                        
                        if dry_run:
                            pnl_str = f"{pnl:.2f}" if pnl else "0"
                            pnl_pct_str = f"{pnl_pct:.2f}" if pnl_pct else "0"
                            results['details'].append(
                                f"Would fix: {db_symbol} entry@${entry_price:.2f} -> exit@${avg_fill_price:.2f} "
                                f"P&L=${pnl_str} ({pnl_pct_str}%)"
                            )
                            results['fixed_count'] += 1
                        else:
                            # Update CompletedTrade
                            open_trade.is_open = False
                            open_trade.exit_time = exit_time
                            open_trade.exit_price = avg_fill_price
                            open_trade.exit_quantity = filled_qty
                            open_trade.exit_method = exit_method
                            open_trade.pnl_amount = pnl
                            open_trade.pnl_percent = pnl_pct
                            open_trade.remaining_quantity = 0
                            
                            if open_trade.entry_time:
                                hold_seconds = int((exit_time - open_trade.entry_time).total_seconds())
                                open_trade.hold_duration_seconds = hold_seconds
                            
                            db.session.commit()
                            
                            pnl_str = f"{pnl:.2f}" if pnl else "0"
                            pnl_pct_str = f"{pnl_pct:.2f}" if pnl_pct else "0"
                            results['details'].append(
                                f"Fixed: {db_symbol} #{open_trade.id} exit@${avg_fill_price:.2f} "
                                f"P&L=${pnl_str} ({pnl_pct_str}%)"
                            )
                            results['fixed_count'] += 1
                        
                    except Exception as order_err:
                        results['error_count'] += 1
                        results['details'].append(f"Error processing order: {str(order_err)}")
                        continue
                        
            except Exception as client_err:
                results['details'].append(f"{account_type}: Client error - {str(client_err)}")
                continue
        
        return jsonify({
            'success': True,
            'message': f'修复完成: 更新了{results["fixed_count"]}条记录' + (' (预览模式)' if dry_run else ''),
            **results
        })
        
    except Exception as e:
        logger.error(f"Error fixing historical data: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/close-orphan-trades', methods=['POST'])
def api_close_orphan_trades():
    """
    Close CompletedTrade records that are marked as open but position no longer exists in Tiger.
    Checks actual Tiger positions and marks non-existent ones as closed.
    Now also fetches historical filled orders to find actual exit price for P&L calculation.
    
    POST body (optional):
    - account_type: 'paper', 'real', or 'both' (default 'both')
    - dry_run: If true, only report what would be closed (default false)
    - days: Number of days to look back for historical orders (default 30)
    """
    try:
        from models import CompletedTrade, ExitMethod
        from datetime import datetime, timedelta
        
        data = request.get_json() or {}
        account_type_filter = data.get('account_type', 'both')
        dry_run = data.get('dry_run', False)
        days = data.get('days', 30)
        
        results = {
            'closed_count': 0,
            'still_open_count': 0,
            'error_count': 0,
            'details': [],
            'dry_run': dry_run
        }
        
        # Get current positions from Tiger
        tiger_positions = {'paper': set(), 'real': set()}
        
        # Get historical filled orders to find exit prices
        historical_exits = {'paper': {}, 'real': {}}  # symbol -> list of exit orders
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        if account_type_filter in ['paper', 'both']:
            try:
                paper_client = TigerPaperClient()
                paper_result = paper_client.get_positions()
                if paper_result.get('success'):
                    for pos in paper_result.get('positions', []):
                        tiger_positions['paper'].add(pos.get('symbol', ''))
                    results['details'].append(f"Paper持仓: {list(tiger_positions['paper'])}")
                
                # Get historical filled orders for exit price lookup
                filled_result = paper_client.get_filled_orders(start_date=start_date, end_date=end_date)
                if filled_result.get('success'):
                    for order in filled_result.get('orders', []):
                        if order.get('action', '').upper() == 'SELL':
                            symbol = order.get('symbol', '')
                            if symbol not in historical_exits['paper']:
                                historical_exits['paper'][symbol] = []
                            historical_exits['paper'][symbol].append({
                                'price': order.get('avg_fill_price', 0),
                                'quantity': order.get('filled', 0),
                                'time': order.get('trade_time')
                            })
                    results['details'].append(f"Paper历史卖出订单: {len(filled_result.get('orders', []))}条")
            except Exception as e:
                results['details'].append(f"Paper数据获取失败: {str(e)}")
        
        if account_type_filter in ['real', 'both']:
            try:
                real_client = TigerClient()
                real_result = real_client.get_positions()
                if real_result.get('success'):
                    for pos in real_result.get('positions', []):
                        tiger_positions['real'].add(pos.get('symbol', ''))
                    results['details'].append(f"Real持仓: {list(tiger_positions['real'])}")
                
                # Get historical filled orders for exit price lookup
                filled_result = real_client.get_filled_orders(start_date=start_date, end_date=end_date)
                if filled_result.get('success'):
                    for order in filled_result.get('orders', []):
                        if order.get('action', '').upper() == 'SELL':
                            symbol = order.get('symbol', '')
                            if symbol not in historical_exits['real']:
                                historical_exits['real'][symbol] = []
                            historical_exits['real'][symbol].append({
                                'price': order.get('avg_fill_price', 0),
                                'quantity': order.get('filled', 0),
                                'time': order.get('trade_time')
                            })
                    results['details'].append(f"Real历史卖出订单: {len(filled_result.get('orders', []))}条")
            except Exception as e:
                results['details'].append(f"Real数据获取失败: {str(e)}")
        
        # Find all open CompletedTrades
        open_trades = CompletedTrade.query.filter_by(is_open=True).all()
        results['details'].append(f"Open CompletedTrade总数: {len(open_trades)}")
        
        for trade in open_trades:
            try:
                # Skip if account type doesn't match filter
                if account_type_filter != 'both' and trade.account_type != account_type_filter:
                    continue
                
                # Clean symbol (remove [PAPER] prefix)
                clean_symbol = trade.symbol.replace('[PAPER]', '').strip()
                
                # Check if position exists in Tiger
                current_positions = tiger_positions.get(trade.account_type, set())
                
                if clean_symbol in current_positions:
                    # Position still exists, skip
                    results['still_open_count'] += 1
                    continue
                
                # Position doesn't exist in Tiger - mark as closed
                # Try to find exit price from historical orders
                exit_orders = historical_exits.get(trade.account_type, {}).get(clean_symbol, [])
                
                exit_price = None
                exit_time = datetime.utcnow()
                exit_method = ExitMethod.MANUAL
                
                # Find the most recent SELL order for this symbol after entry time
                if exit_orders and trade.entry_time:
                    for exit_order in sorted(exit_orders, key=lambda x: x.get('time') or 0, reverse=True):
                        order_time = exit_order.get('time')
                        if order_time:
                            try:
                                if isinstance(order_time, (int, float)):
                                    order_datetime = datetime.fromtimestamp(order_time / 1000)
                                else:
                                    order_datetime = datetime.fromisoformat(str(order_time).replace('Z', '+00:00'))
                                
                                if order_datetime > trade.entry_time:
                                    exit_price = exit_order.get('price')
                                    exit_time = order_datetime
                                    exit_method = ExitMethod.WEBHOOK_SIGNAL
                                    break
                            except:
                                pass
                
                # Fallback: use most recent exit order if no time match
                if not exit_price and exit_orders:
                    exit_price = exit_orders[0].get('price')
                    exit_method = ExitMethod.WEBHOOK_SIGNAL
                
                # Calculate P&L
                pnl = None
                pnl_pct = None
                entry_price = trade.entry_price or 0
                
                if exit_price and entry_price and trade.entry_quantity:
                    pnl = (exit_price - entry_price) * trade.entry_quantity
                    pnl_pct = (exit_price - entry_price) / entry_price * 100 if entry_price > 0 else 0
                
                if dry_run:
                    entry_str = f"{entry_price:.2f}" if entry_price else "0"
                    exit_str = f"{exit_price:.2f}" if exit_price else "未知"
                    pnl_str = f"{pnl:.2f}" if pnl else "0"
                    pnl_pct_str = f"{pnl_pct:.2f}" if pnl_pct else "0"
                    results['details'].append(
                        f"Would close: {trade.symbol} #{trade.id} entry@${entry_str} -> exit@${exit_str} P&L=${pnl_str} ({pnl_pct_str}%)"
                    )
                    results['closed_count'] += 1
                else:
                    trade.is_open = False
                    trade.exit_time = exit_time
                    trade.exit_method = exit_method
                    trade.remaining_quantity = 0
                    
                    if exit_price:
                        trade.exit_price = exit_price
                        trade.pnl_amount = pnl
                        trade.pnl_percent = pnl_pct
                    else:
                        # No exit price found, use entry price as placeholder
                        trade.exit_price = entry_price
                        trade.pnl_amount = 0
                        trade.pnl_percent = 0
                    
                    if trade.entry_time:
                        hold_seconds = int((exit_time - trade.entry_time).total_seconds())
                        trade.hold_duration_seconds = hold_seconds
                    
                    db.session.commit()
                    
                    exit_str = f"{exit_price:.2f}" if exit_price else "未知"
                    pnl_str = f"{pnl:.2f}" if pnl else "0"
                    results['details'].append(
                        f"Closed: {trade.symbol} #{trade.id} exit@${exit_str} P&L=${pnl_str}"
                    )
                    results['closed_count'] += 1
                    
            except Exception as trade_err:
                results['error_count'] += 1
                results['details'].append(f"Error: {trade.symbol} - {str(trade_err)}")
                db.session.rollback()
                continue
        
        return jsonify({
            'success': True,
            'message': f'完成: 关闭了{results["closed_count"]}条记录, {results["still_open_count"]}条仍持仓' + 
                      (' (预览模式)' if dry_run else ''),
            **results
        })
        
    except Exception as e:
        logger.error(f"Error closing orphan trades: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/test_close_order', methods=['POST'])
def test_close_order():
    """Test Tiger API close order functionality (dry run - does not actually place order)"""
    try:
        data = request.get_json() or {}
        account_type = data.get('account_type', 'paper')
        symbol = data.get('symbol', 'AAPL')
        
        if account_type == 'paper':
            tiger = TigerPaperClient()
            account_name = 'Paper'
        else:
            tiger = TigerClient()
            account_name = 'Real'
        
        result = {
            'account_type': account_type,
            'account_name': account_name,
            'symbol': symbol,
            'tiger_initialized': tiger is not None,
            'tiger_client_exists': getattr(tiger, 'client', None) is not None if tiger else False,
            'client_config_exists': getattr(tiger, 'client_config', None) is not None if tiger else False,
        }
        
        if tiger and tiger.client_config:
            result['account_id'] = tiger.client_config.account
            result['tiger_id'] = tiger.client_config.tiger_id
        
        if tiger and tiger.client:
            result['ready_to_place_order'] = True
            result['message'] = f'{account_name}账户 Tiger客户端初始化成功，可以执行平仓'
        else:
            result['ready_to_place_order'] = False
            result['message'] = f'{account_name}账户 Tiger客户端初始化失败，无法执行平仓'
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error testing close order: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/trade-analytics')
def trade_analytics():
    """Trade analytics page showing entry-based flow analysis using EntrySignalRecord.
    
    New design: Each row = one entry signal (including scaling).
    Links to ClosedPosition for exit info when available.
    Follows OrderTracker chain: Entry → OrderTracker → ClosedPosition → EntrySignalRecord
    """
    from models import EntrySignalRecord, ClosedPosition, ExitMethod
    from datetime import datetime, timedelta
    from tiger_client import get_tiger_quote_client
    import pytz
    import json
    
    # Get filter parameters
    account_type = request.args.get('account_type', 'paper')
    signal_grade = request.args.get('signal_grade', '')
    exit_method = request.args.get('exit_method', '')
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')
    symbol_search = request.args.get('symbol', '').strip().upper()
    status_filter = request.args.get('status', '')  # 'open', 'closed', or '' for all
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    # Build query from EntrySignalRecord
    query = EntrySignalRecord.query.filter_by(account_type=account_type)
    
    # Status filter: open = no closed_position_id, closed = has closed_position_id
    if status_filter == 'open':
        query = query.filter(EntrySignalRecord.closed_position_id == None)
    elif status_filter == 'closed':
        query = query.filter(EntrySignalRecord.closed_position_id != None)
    
    # Symbol search (handle both with and without [PAPER] prefix)
    if symbol_search:
        from sqlalchemy import or_
        query = query.filter(or_(
            EntrySignalRecord.symbol.ilike(f'%{symbol_search}%'),
            EntrySignalRecord.symbol.ilike(f'%[PAPER]{symbol_search}%')
        ))
    
    if signal_grade:
        query = query.filter(EntrySignalRecord.signal_grade == signal_grade)
    
    # Exit method filter requires join to ClosedPosition
    if exit_method:
        try:
            exit_method_enum = ExitMethod(exit_method)
            query = query.join(ClosedPosition, EntrySignalRecord.closed_position_id == ClosedPosition.id)
            query = query.filter(ClosedPosition.exit_method == exit_method_enum)
        except ValueError:
            pass
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(EntrySignalRecord.entry_time >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)
            query = query.filter(EntrySignalRecord.entry_time < end_dt)
        except ValueError:
            pass
    
    # Order by entry_time desc (most recent first)
    query = query.order_by(EntrySignalRecord.entry_time.desc())
    
    # Pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    entries = pagination.items
    
    # Prepare display data
    eastern = pytz.timezone('US/Eastern')
    price_cache = {}
    display_entries = []
    
    for entry in entries:
        # Check if closed (has linked ClosedPosition)
        is_open = entry.closed_position_id is None
        closed_pos = None
        if not is_open:
            closed_pos = ClosedPosition.query.get(entry.closed_position_id)
        
        # Clean symbol for display
        clean_symbol = entry.symbol.replace('[PAPER]', '').strip() if entry.symbol else ''
        
        # Convert times to Eastern
        entry_time_et = None
        if entry.entry_time:
            entry_time_et = entry.entry_time.replace(tzinfo=pytz.UTC).astimezone(eastern)
        
        exit_time_et = None
        if closed_pos and closed_pos.exit_time:
            exit_time_et = closed_pos.exit_time.replace(tzinfo=pytz.UTC).astimezone(eastern)
        
        # Extract display signal type from raw_json
        display_signal_type = _extract_signal_type(entry.raw_json, entry.indicator_trigger)
        
        # Get current price for open positions
        current_price = None
        unrealized_pnl = None
        unrealized_pnl_pct = None
        
        if is_open and entry.entry_price:
            if clean_symbol not in price_cache:
                try:
                    quote_client = get_tiger_quote_client()
                    if quote_client:
                        price_data = quote_client.get_smart_price(clean_symbol)
                        price_cache[clean_symbol] = price_data.get('price') if price_data else None
                    else:
                        price_cache[clean_symbol] = None
                except:
                    price_cache[clean_symbol] = None
            
            current_price = price_cache.get(clean_symbol)
            if current_price and entry.quantity:
                if entry.side == 'long':
                    unrealized_pnl = (current_price - entry.entry_price) * entry.quantity
                    unrealized_pnl_pct = ((current_price - entry.entry_price) / entry.entry_price) * 100
                else:
                    unrealized_pnl = (entry.entry_price - current_price) * entry.quantity
                    unrealized_pnl_pct = ((entry.entry_price - current_price) / entry.entry_price) * 100
        
        # Calculate hold duration
        hold_duration_seconds = None
        if not is_open and closed_pos and entry.entry_time and closed_pos.exit_time:
            hold_duration_seconds = (closed_pos.exit_time - entry.entry_time).total_seconds()
        
        # Build display record
        display_entry = {
            'id': entry.id,
            'symbol': clean_symbol,
            'side': entry.side,
            'quantity': entry.quantity,
            'is_scaling': entry.is_scaling,
            'is_open': is_open,
            'entry_price': entry.entry_price,
            'entry_time_et': entry_time_et,
            'entry_order_id': entry.entry_order_id,
            'signal_grade': entry.signal_grade,
            'signal_score': entry.signal_score,
            'htf_grade': entry.htf_grade,
            'htf_score': entry.htf_score,
            'timeframe': entry.timeframe,
            'display_signal_type': display_signal_type,
            'indicator_trigger': entry.indicator_trigger,
            'raw_json': entry.raw_json,
            'signal_stop_loss': entry.signal_stop_loss,
            'signal_take_profit': entry.signal_take_profit,
            'current_price': current_price,
            'unrealized_pnl': unrealized_pnl,
            'unrealized_pnl_pct': unrealized_pnl_pct,
            'exit_price': closed_pos.exit_price if closed_pos else None,
            'exit_time_et': exit_time_et,
            'exit_method': closed_pos.exit_method if closed_pos else None,
            'exit_order_id': closed_pos.exit_order_id if closed_pos else None,
            'pnl_amount': entry.contribution_pnl if entry.contribution_pnl else (closed_pos.total_pnl if closed_pos else None),
            'pnl_percent': entry.contribution_pct,
            'commission': closed_pos.commission if closed_pos else None,
            'hold_duration_seconds': hold_duration_seconds,
            'closed_position_id': entry.closed_position_id
        }
        display_entries.append(display_entry)
    
    # Calculate summary statistics (only for closed entries)
    closed_entries_query = EntrySignalRecord.query.filter_by(account_type=account_type)
    closed_entries_query = closed_entries_query.filter(EntrySignalRecord.closed_position_id != None)
    if symbol_search:
        from sqlalchemy import or_
        closed_entries_query = closed_entries_query.filter(or_(
            EntrySignalRecord.symbol.ilike(f'%{symbol_search}%'),
            EntrySignalRecord.symbol.ilike(f'%[PAPER]{symbol_search}%')
        ))
    closed_entries = closed_entries_query.all()
    
    # Calculate P&L from contribution_pnl or linked ClosedPosition
    total_pnl = 0
    winning_entries = []
    losing_entries = []
    
    for e in closed_entries:
        pnl = e.contribution_pnl
        if pnl is None and e.closed_position_id:
            cp = ClosedPosition.query.get(e.closed_position_id)
            if cp:
                pnl = cp.total_pnl
        if pnl is not None:
            total_pnl += pnl
            if pnl > 0:
                winning_entries.append(pnl)
            elif pnl < 0:
                losing_entries.append(pnl)
    
    total_closed = len(closed_entries)
    win_rate = (len(winning_entries) / total_closed * 100) if total_closed else 0
    avg_win = sum(winning_entries) / len(winning_entries) if winning_entries else 0
    avg_loss = abs(sum(losing_entries) / len(losing_entries)) if losing_entries else 0
    total_win = sum(winning_entries) if winning_entries else 0
    total_loss = abs(sum(losing_entries)) if losing_entries else 0
    profit_factor = total_win / total_loss if total_loss else 0
    
    # Group by signal grade
    grade_stats = {}
    for grade in ['A', 'B', 'C', None]:
        grade_entries = [e for e in closed_entries if e.signal_grade == grade]
        if grade_entries:
            grade_key = grade or 'Unknown'
            grade_pnl = 0
            grade_wins = 0
            for e in grade_entries:
                pnl = e.contribution_pnl
                if pnl is None and e.closed_position_id:
                    cp = ClosedPosition.query.get(e.closed_position_id)
                    pnl = cp.total_pnl if cp else 0
                pnl = pnl or 0
                grade_pnl += pnl
                if pnl > 0:
                    grade_wins += 1
            grade_stats[grade_key] = {
                'count': len(grade_entries),
                'pnl': grade_pnl,
                'win_rate': grade_wins / len(grade_entries) * 100
            }
    
    # Group by exit method
    exit_stats = {}
    for method in ExitMethod:
        method_entries = []
        for e in closed_entries:
            if e.closed_position_id:
                cp = ClosedPosition.query.get(e.closed_position_id)
                if cp and cp.exit_method == method:
                    method_entries.append((e, cp))
        if method_entries:
            method_pnl = 0
            method_wins = 0
            for e, cp in method_entries:
                pnl = e.contribution_pnl or cp.total_pnl or 0
                method_pnl += pnl
                if pnl > 0:
                    method_wins += 1
            exit_stats[method.value] = {
                'count': len(method_entries),
                'pnl': method_pnl,
                'win_rate': method_wins / len(method_entries) * 100
            }
    
    return render_template('trade_analytics.html',
        trades=display_entries,
        pagination=pagination,
        account_type=account_type,
        signal_grade=signal_grade,
        exit_method_filter=exit_method,
        start_date=start_date,
        end_date=end_date,
        symbol_search=symbol_search,
        status_filter=status_filter,
        total_pnl=total_pnl,
        total_trades=total_closed,
        win_rate=win_rate,
        avg_win=avg_win,
        avg_loss=avg_loss,
        profit_factor=profit_factor,
        grade_stats=grade_stats,
        exit_stats=exit_stats,
        ExitMethod=ExitMethod
    )


def _extract_signal_type(entry_signal_content, fallback_type):
    """Extract display-friendly signal type from entry signal content (extras.indicator)"""
    import json
    
    if not entry_signal_content:
        return fallback_type or 'Unknown'
    
    # Try to parse as JSON to get extras.indicator
    try:
        data = json.loads(entry_signal_content)
        if isinstance(data, dict):
            # Look for extras.indicator first (TradingView signal format)
            extras = data.get('extras', {})
            if isinstance(extras, dict) and extras.get('indicator'):
                indicator = extras['indicator']
                # If it's a long string with grade info, keep it
                if len(indicator) > 50:
                    return indicator[:50] + '...'
                return indicator
            
            # Fallback to other fields
            if data.get('indicator'):
                indicator = data['indicator']
                if len(indicator) > 50:
                    return indicator[:50] + '...'
                return indicator
            if data.get('signal'):
                return data['signal']
        return fallback_type or 'Unknown'
    except:
        pass
    
    # If it's short text, use as is
    if len(entry_signal_content) < 30:
        return entry_signal_content
    
    # Truncate long text
    return entry_signal_content[:30] + '...'


@app.route('/fix-completed-trade-pnl', methods=['POST'])
def fix_completed_trade_pnl():
    """修复CompletedTrade中缺失的exit_price和P&L数据"""
    from models import CompletedTrade
    from tiger_client import get_tiger_quote_client
    
    try:
        # 找到所有exit_price为空的已关闭交易
        trades_to_fix = CompletedTrade.query.filter(
            CompletedTrade.is_open == False,
            CompletedTrade.exit_price == None
        ).all()
        
        fixed_count = 0
        errors = []
        
        quote_client = get_tiger_quote_client()
        
        for trade in trades_to_fix:
            try:
                # 从symbol中提取纯symbol（去掉[PAPER]前缀）
                clean_symbol = trade.symbol.replace('[PAPER]', '').strip()
                
                # 尝试获取当前价格作为exit_price的近似值
                if quote_client:
                    quote_result = quote_client.get_smart_price(clean_symbol)
                    if quote_result and quote_result.get('price'):
                        exit_price = quote_result['price']
                        trade.exit_price = exit_price
                        
                        # 计算P&L
                        if trade.entry_price and exit_price:
                            if trade.side == 'long':
                                trade.pnl_amount = (exit_price - trade.entry_price) * (trade.entry_quantity or 0)
                                trade.pnl_percent = ((exit_price - trade.entry_price) / trade.entry_price) * 100
                            else:
                                trade.pnl_amount = (trade.entry_price - exit_price) * (trade.entry_quantity or 0)
                                trade.pnl_percent = ((trade.entry_price - exit_price) / trade.entry_price) * 100
                            
                            fixed_count += 1
                            logger.info(f"Fixed P&L for {trade.symbol}: exit_price={exit_price}, pnl={trade.pnl_amount:.2f}")
            except Exception as e:
                errors.append(f"{trade.symbol}: {str(e)}")
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'fixed_count': fixed_count,
            'total_needing_fix': len(trades_to_fix),
            'errors': errors if errors else None,
            'message': f"Fixed {fixed_count} of {len(trades_to_fix)} trades"
        })
        
    except Exception as e:
        logger.error(f"Error fixing P&L: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/test-quote/<symbol>')
def test_quote(symbol):
    """Test quote API for debugging - returns all available price sources"""
    import numpy as np
    
    def convert_numpy(obj):
        """Convert numpy types to Python native types"""
        if isinstance(obj, dict):
            return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [convert_numpy(v) for v in obj]
        elif isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif hasattr(obj, 'isoformat'):
            return obj.isoformat()
        return obj
    
    try:
        from tiger_client import get_tiger_quote_client
        
        client = get_tiger_quote_client()
        if not client:
            return jsonify({'error': 'Quote client not available'}), 500
        
        results = {
            'symbol': symbol,
            'market_session': client.get_market_session(),
            'timestamp': datetime.now().isoformat()
        }
        
        # Test smart_price
        try:
            smart = client.get_smart_price(symbol)
            results['smart_price'] = convert_numpy(smart)
        except Exception as e:
            results['smart_price_error'] = str(e)
        
        # Test extended hours
        try:
            extended = client.get_extended_hours_price(symbol)
            results['extended_hours'] = convert_numpy(extended)
        except Exception as e:
            results['extended_hours_error'] = str(e)
        
        # Test latest trade (briefs)
        try:
            latest = client.get_latest_trade(symbol)
            results['latest_trade'] = convert_numpy(latest)
        except Exception as e:
            results['latest_trade_error'] = str(e)
        
        # Test overnight ticks
        try:
            overnight = client.get_overnight_price(symbol)
            results['overnight'] = convert_numpy(overnight)
        except Exception as e:
            results['overnight_error'] = str(e)
        
        # Test session ticks (get last 5 overnight ticks)
        try:
            ticks = client.get_session_ticks(symbol, session='overnight', limit=5)
            results['overnight_ticks'] = convert_numpy(ticks)
        except Exception as e:
            results['overnight_ticks_error'] = str(e)
        
        # Test WebSocket cached price
        try:
            from tiger_push_client import get_push_manager
            push_manager = get_push_manager()
            if push_manager:
                cached = push_manager.get_cached_quote(symbol)
                results['websocket_cache'] = convert_numpy(cached)
            else:
                results['websocket_cache'] = None
        except Exception as e:
            results['websocket_cache_error'] = str(e)
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/websocket-status')
def websocket_status():
    """Show WebSocket subscription status and all cached prices"""
    import numpy as np
    
    def convert_numpy(obj):
        if isinstance(obj, dict):
            return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [convert_numpy(v) for v in obj]
        elif isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64)):
            return float(obj)
        elif hasattr(obj, 'isoformat'):
            return obj.isoformat()
        return obj
    
    try:
        from tiger_push_client import get_push_manager
        push_manager = get_push_manager()
        
        if not push_manager:
            return jsonify({'error': 'Push manager not initialized'}), 500
        
        subscribed = push_manager.subscribed_symbols
        
        cached_quotes = {}
        for symbol in subscribed:
            quote = push_manager.get_cached_quote(symbol)
            if quote:
                cached_quotes[symbol] = convert_numpy(quote)
        
        return jsonify({
            'connected': push_manager.is_connected,
            'subscribed_symbols': subscribed,
            'subscribed_count': len(subscribed),
            'cached_quotes': cached_quotes,
            'cached_count': len(cached_quotes)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/tiger-closed-history')
def tiger_closed_history():
    """Display closed trades history from Tiger API directly (Tiger API 历史成交记录)"""
    try:
        from tiger_client import TigerClient, TigerPaperClient
        from pytz import timezone
        eastern = timezone('US/Eastern')
        
        account_type = request.args.get('account_type', 'real')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        symbol_filter = request.args.get('symbol', '').strip().upper() or None
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        if account_type == 'paper':
            tiger_client = TigerPaperClient()
        else:
            tiger_client = TigerClient()
        
        result = tiger_client.get_filled_orders(
            start_date=start_date,
            end_date=end_date,
            symbol=symbol_filter,
            limit=500
        )
        
        orders = []
        total_pnl = 0
        total_commission = 0
        buy_count = 0
        sell_count = 0
        
        if result.get('success'):
            for order in result.get('orders', []):
                trade_time = order.get('trade_time')
                if trade_time:
                    from datetime import datetime
                    if isinstance(trade_time, (int, float)):
                        trade_dt = datetime.fromtimestamp(trade_time / 1000, tz=eastern)
                    else:
                        trade_dt = trade_time
                        if hasattr(trade_dt, 'astimezone'):
                            trade_dt = trade_dt.astimezone(eastern)
                    order['trade_time_str'] = trade_dt.strftime('%Y-%m-%d %H:%M:%S ET')
                else:
                    order['trade_time_str'] = 'N/A'
                
                order['avg_cost'] = order.get('avg_fill_price', 0)
                
                realized_pnl = order.get('realized_pnl', 0) or 0
                commission = order.get('commission', 0) or 0
                total_pnl += realized_pnl
                total_commission += commission
                
                action = order.get('action', '')
                if 'BUY' in action.upper():
                    buy_count += 1
                else:
                    sell_count += 1
                
                orders.append(order)
        
        total_orders = len(orders)
        total_pages = (total_orders + per_page - 1) // per_page if total_orders > 0 else 1
        page = max(1, min(page, total_pages))
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_orders = orders[start_idx:end_idx]
        
        return render_template('tiger_closed_history.html',
                             orders=paginated_orders,
                             account_type=account_type,
                             start_date=start_date,
                             end_date=end_date,
                             symbol_filter=symbol_filter,
                             total_pnl=total_pnl,
                             total_commission=total_commission,
                             buy_count=buy_count,
                             sell_count=sell_count,
                             page=page,
                             per_page=per_page,
                             total_pages=total_pages,
                             total_orders=total_orders,
                             error=result.get('error') if not result.get('success') else None)
    
    except Exception as e:
        logger.error(f"Error in tiger_closed_history: {str(e)}")
        import traceback
        traceback.print_exc()
        return render_template('tiger_closed_history.html',
                             orders=[],
                             account_type='real',
                             start_date=None,
                             end_date=None,
                             symbol_filter=None,
                             total_pnl=0,
                             total_commission=0,
                             buy_count=0,
                             sell_count=0,
                             page=1,
                             per_page=50,
                             total_pages=1,
                             total_orders=0,
                             error=str(e))


@app.route('/api/reconcile-orders', methods=['POST'])
def api_reconcile_orders():
    """API endpoint to reconcile Tiger orders with ClosedPosition records"""
    try:
        from flask import current_app
        from trailing_stop_scheduler import reconcile_tiger_orders
        
        data = request.get_json() or {}
        account_type = data.get('account_type', 'paper')
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        
        if account_type not in ['paper', 'real']:
            return jsonify({'success': False, 'error': 'Invalid account_type. Must be "paper" or "real"'}), 400
        
        if start_date:
            try:
                from datetime import datetime
                datetime.strptime(start_date, '%Y-%m-%d')
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid start_date format. Use YYYY-MM-DD'}), 400
        
        if end_date:
            try:
                from datetime import datetime
                datetime.strptime(end_date, '%Y-%m-%d')
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid end_date format. Use YYYY-MM-DD'}), 400
        
        result = reconcile_tiger_orders(
            app=current_app._get_current_object(),
            account_type=account_type,
            start_date=start_date,
            end_date=end_date
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error in reconcile orders API: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/cleanup-data', methods=['GET', 'POST'])
def admin_cleanup_data():
    """Admin endpoint to cleanup historical trading data.
    GET: Show confirmation page
    POST with confirm=YES: Execute cleanup
    """
    from models import (
        ClosedPosition, EntrySignalRecord, OrderTracker,
        TrailingStopPosition, TrailingStopLog, CompletedTrade,
        PositionCost, SignalLog, Trade
    )
    
    if request.method == 'GET':
        counts = {
            'closed_position': db.session.query(ClosedPosition).count(),
            'entry_signal_record': db.session.query(EntrySignalRecord).count(),
            'order_tracker': db.session.query(OrderTracker).count(),
            'trailing_stop_position': db.session.query(TrailingStopPosition).count(),
            'trailing_stop_log': db.session.query(TrailingStopLog).count(),
            'completed_trade': db.session.query(CompletedTrade).count(),
            'position_cost': db.session.query(PositionCost).count(),
            'signal_log': db.session.query(SignalLog).count(),
            'trade': db.session.query(Trade).count(),
        }
        total = sum(counts.values())
        
        html = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Admin - Cleanup Data</title>
            <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        </head>
        <body class="bg-dark text-light p-5">
            <div class="container">
                <h1 class="mb-4">🗑️ Production Data Cleanup</h1>
                <div class="alert alert-warning">
                    <strong>⚠️ Warning:</strong> This will permanently delete all trading history data!
                </div>
                <table class="table table-dark table-striped">
                    <thead><tr><th>Table</th><th>Records</th></tr></thead>
                    <tbody>
                        <tr><td>ClosedPosition (已平仓记录)</td><td>{counts['closed_position']}</td></tr>
                        <tr><td>EntrySignalRecord (入场信号记录)</td><td>{counts['entry_signal_record']}</td></tr>
                        <tr><td>OrderTracker (订单跟踪)</td><td>{counts['order_tracker']}</td></tr>
                        <tr><td>TrailingStopPosition (跟踪止损仓位)</td><td>{counts['trailing_stop_position']}</td></tr>
                        <tr><td>TrailingStopLog (跟踪止损日志)</td><td>{counts['trailing_stop_log']}</td></tr>
                        <tr><td>CompletedTrade (已完成交易)</td><td>{counts['completed_trade']}</td></tr>
                        <tr><td>PositionCost (仓位成本)</td><td>{counts['position_cost']}</td></tr>
                        <tr><td>SignalLog (信号日志)</td><td>{counts['signal_log']}</td></tr>
                        <tr><td>Trade (交易记录)</td><td>{counts['trade']}</td></tr>
                        <tr class="table-info"><td><strong>Total</strong></td><td><strong>{total}</strong></td></tr>
                    </tbody>
                </table>
                <form method="POST" class="mt-4">
                    <div class="mb-3">
                        <label class="form-label">Type <code>YES</code> to confirm deletion:</label>
                        <input type="text" name="confirm" class="form-control" style="max-width:200px" autocomplete="off">
                    </div>
                    <button type="submit" class="btn btn-danger btn-lg">🗑️ Delete All Data</button>
                    <a href="/" class="btn btn-secondary btn-lg ms-2">Cancel</a>
                </form>
            </div>
        </body>
        </html>
        '''
        return html
    
    confirm = request.form.get('confirm', '')
    if confirm != 'YES':
        flash('Cleanup cancelled - confirmation not provided', 'warning')
        return redirect(url_for('admin_cleanup_data'))
    
    try:
        from sqlalchemy import text
        
        tables_to_truncate = [
            'trailing_stop_log',
            'trailing_stop_position', 
            'closed_position',
            'order_tracker',
            'entry_signal_record',
            'completed_trade',
            'position_cost',
            'signal_log',
            'trade'
        ]
        
        deleted_counts = {}
        for table in tables_to_truncate:
            count_result = db.session.execute(text(f"SELECT COUNT(*) FROM {table}"))
            count = count_result.scalar()
            deleted_counts[table] = count
            db.session.execute(text(f"TRUNCATE TABLE {table} CASCADE"))
        
        db.session.commit()
        
        total = sum(deleted_counts.values())
        logger.info(f"Admin cleanup: truncated {total} records from {len(tables_to_truncate)} tables")
        
        flash(f'Successfully deleted {total} records!', 'success')
        return redirect('/')
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Cleanup error: {str(e)}")
        import traceback
        traceback.print_exc()
        flash(f'Error during cleanup: {str(e)}', 'danger')
        return redirect(url_for('admin_cleanup_data'))


@app.route('/admin/fix-entry-matching', methods=['GET', 'POST'])
def admin_fix_entry_matching():
    """Admin endpoint to fix unlinked EntrySignalRecord by re-running FIFO matching."""
    from models import ClosedPosition, EntrySignalRecord
    from sqlalchemy import or_
    
    if request.method == 'GET':
        unlinked_entries = EntrySignalRecord.query.filter(
            EntrySignalRecord.closed_position_id == None
        ).count()
        
        closed_positions = ClosedPosition.query.all()
        
        html = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Admin - Fix Entry Matching</title>
            <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        </head>
        <body class="bg-dark text-light p-5">
            <div class="container">
                <h1 class="mb-4">🔧 Fix Entry Signal Matching</h1>
                <div class="alert alert-info">
                    <strong>ℹ️ Info:</strong> This will re-run FIFO matching for all ClosedPosition records
                    to link unmatched EntrySignalRecord entries.
                </div>
                <p>Unlinked Entry Records: <strong>{unlinked_entries}</strong></p>
                <p>Total ClosedPosition Records: <strong>{len(closed_positions)}</strong></p>
                <form method="POST">
                    <button type="submit" class="btn btn-primary">Run Fix</button>
                    <a href="/" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </body>
        </html>
        '''
        return html
    
    try:
        fixed_count = 0
        closed_positions = ClosedPosition.query.all()
        
        for cp in closed_positions:
            linked_entries = EntrySignalRecord.query.filter(
                EntrySignalRecord.closed_position_id == cp.id
            ).count()
            
            if linked_entries > 0:
                continue
            
            symbol_variants = [cp.symbol]
            if cp.account_type == 'paper' and not cp.symbol.startswith('[PAPER]'):
                symbol_variants.append(f'[PAPER]{cp.symbol}')
            elif cp.symbol.startswith('[PAPER]'):
                symbol_variants.append(cp.symbol.replace('[PAPER]', '').strip())
            
            unlinked_entries = EntrySignalRecord.query.filter(
                or_(*[EntrySignalRecord.symbol == s for s in symbol_variants]),
                EntrySignalRecord.account_type == cp.account_type,
                EntrySignalRecord.side == cp.side,
                EntrySignalRecord.closed_position_id == None
            ).order_by(EntrySignalRecord.entry_time.asc()).all()
            
            if not unlinked_entries:
                continue
            
            exit_qty = abs(cp.exit_quantity) if cp.exit_quantity else 0
            remaining_qty = exit_qty
            
            for entry in unlinked_entries:
                if remaining_qty <= 0:
                    break
                
                entry_qty = abs(entry.quantity) if entry.quantity else 0
                matched_qty = min(entry_qty, remaining_qty)
                
                if matched_qty > 0:
                    entry.closed_position_id = cp.id
                    if cp.exit_price and entry.entry_price:
                        if entry.side == 'long':
                            entry.contribution_pnl = (cp.exit_price - entry.entry_price) * entry_qty
                        else:
                            entry.contribution_pnl = (entry.entry_price - cp.exit_price) * entry_qty
                        if entry.entry_price > 0:
                            entry.contribution_pct = entry.contribution_pnl / (entry.entry_price * entry_qty) * 100
                    
                    remaining_qty -= matched_qty
                    fixed_count += 1
                    logger.info(f"🔧 Fixed: Entry #{entry.id} -> ClosedPosition #{cp.id}")
            
            if cp.exit_quantity and cp.exit_quantity < 0:
                cp.exit_quantity = abs(cp.exit_quantity)
                if cp.side == 'short' and cp.exit_price and cp.avg_entry_price:
                    cp.total_pnl = (cp.avg_entry_price - cp.exit_price) * cp.exit_quantity
                    if cp.avg_entry_price > 0:
                        cp.total_pnl_pct = cp.total_pnl / (cp.avg_entry_price * cp.exit_quantity) * 100
        
        db.session.commit()
        
        flash(f'Successfully fixed {fixed_count} entry-exit linkages', 'success')
        return redirect(url_for('admin_fix_entry_matching'))
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Fix matching error: {str(e)}")
        import traceback
        traceback.print_exc()
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin_fix_entry_matching'))


@app.route('/admin/reconciliation', methods=['GET', 'POST'])
def admin_reconciliation():
    """Reconciliation dashboard - view Tiger raw orders and trigger reconciliation."""
    from models import TigerFilledOrder, ReconciliationRun
    from reconciliation_service import fetch_and_store_filled_orders, reconcile_today
    from datetime import date, timedelta
    
    message = None
    message_type = 'info'
    
    if request.method == 'POST':
        action = request.form.get('action', '')
        account_type = request.form.get('account_type', 'real')
        target_date_str = request.form.get('target_date', '')
        
        target_date = None
        if target_date_str:
            try:
                target_date = datetime.strptime(target_date_str, '%Y-%m-%d').date()
            except ValueError:
                target_date = date.today()
        
        if action == 'fetch':
            start_date = target_date_str or date.today().strftime('%Y-%m-%d')
            end_date = start_date
            total, new = fetch_and_store_filled_orders(
                account_type=account_type,
                start_date=start_date,
                end_date=end_date
            )
            message = f'Fetched {total} orders for {account_type}, {new} new stored'
            message_type = 'success' if total > 0 else 'warning'
            
        elif action == 'reconcile':
            run = reconcile_today(
                account_type=account_type,
                run_type='manual',
                target_date=target_date
            )
            if run.status == 'completed':
                message = (f'Reconciliation completed: {run.positions_matched} matched, '
                          f'{run.records_corrected} corrected, {run.records_created} created')
                message_type = 'success'
            else:
                message = f'Reconciliation failed: {run.error_message}'
                message_type = 'danger'
        
        elif action == 'fetch_range':
            days_back = int(request.form.get('days_back', 7))
            start = (date.today() - timedelta(days=days_back)).strftime('%Y-%m-%d')
            end = date.today().strftime('%Y-%m-%d')
            total, new = fetch_and_store_filled_orders(
                account_type=account_type,
                start_date=start,
                end_date=end
            )
            message = f'Fetched {total} orders ({days_back} days) for {account_type}, {new} new stored'
            message_type = 'success'
    
    recent_runs = ReconciliationRun.query.order_by(
        ReconciliationRun.started_at.desc()
    ).limit(20).all()
    
    today_str = date.today().strftime('%Y-%m-%d')
    
    real_orders_today = TigerFilledOrder.query.filter_by(account_type='real').count()
    paper_orders_today = TigerFilledOrder.query.filter_by(account_type='paper').count()
    
    real_unreconciled = TigerFilledOrder.query.filter_by(
        account_type='real', is_open=False, reconciled=False
    ).count()
    paper_unreconciled = TigerFilledOrder.query.filter_by(
        account_type='paper', is_open=False, reconciled=False
    ).count()
    
    recent_orders = TigerFilledOrder.query.order_by(
        TigerFilledOrder.trade_time.desc()
    ).limit(50).all()
    
    html = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Reconciliation Dashboard</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    </head>
    <body class="bg-dark text-light">
        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1><i class="fas fa-balance-scale"></i> 智能对账系统</h1>
                <a href="/" class="btn btn-outline-secondary"><i class="fas fa-home"></i> Dashboard</a>
            </div>
            
            {"<div class='alert alert-" + message_type + " alert-dismissible'>" + message + "</div>" if message else ""}
            
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-secondary">
                        <div class="card-body text-center">
                            <h5>Real 总订单</h5>
                            <h2>{real_orders_today}</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-secondary">
                        <div class="card-body text-center">
                            <h5>Paper 总订单</h5>
                            <h2>{paper_orders_today}</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-dark">
                        <div class="card-body text-center">
                            <h5>Real 待对账</h5>
                            <h2>{real_unreconciled}</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-dark">
                        <div class="card-body text-center">
                            <h5>Paper 待对账</h5>
                            <h2>{paper_unreconciled}</h2>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card bg-dark border-info">
                        <div class="card-header bg-info text-dark"><strong><i class="fas fa-download"></i> 拉取Tiger成交数据</strong></div>
                        <div class="card-body">
                            <form method="POST" class="mb-3">
                                <input type="hidden" name="action" value="fetch">
                                <div class="row g-2 align-items-end">
                                    <div class="col-md-4">
                                        <label class="form-label">账户</label>
                                        <select name="account_type" class="form-select form-select-sm">
                                            <option value="real">Real</option>
                                            <option value="paper">Paper</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">日期</label>
                                        <input type="date" name="target_date" class="form-control form-control-sm" value="{today_str}">
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-info btn-sm w-100">拉取当日</button>
                                    </div>
                                </div>
                            </form>
                            <form method="POST">
                                <input type="hidden" name="action" value="fetch_range">
                                <div class="row g-2 align-items-end">
                                    <div class="col-md-4">
                                        <select name="account_type" class="form-select form-select-sm">
                                            <option value="real">Real</option>
                                            <option value="paper">Paper</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <select name="days_back" class="form-select form-select-sm">
                                            <option value="7">最近7天</option>
                                            <option value="14">最近14天</option>
                                            <option value="30">最近30天</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-outline-info btn-sm w-100">批量拉取</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-dark border-success">
                        <div class="card-header bg-success text-dark"><strong><i class="fas fa-check-double"></i> 执行对账</strong></div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="action" value="reconcile">
                                <div class="row g-2 align-items-end">
                                    <div class="col-md-4">
                                        <label class="form-label">账户</label>
                                        <select name="account_type" class="form-select form-select-sm">
                                            <option value="real">Real</option>
                                            <option value="paper">Paper</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">日期</label>
                                        <input type="date" name="target_date" class="form-control form-control-sm" value="{today_str}">
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-success btn-sm w-100">立即对账</button>
                                    </div>
                                </div>
                            </form>
                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle"></i> 
                                    对账前请先拉取当日数据。对账会自动匹配开仓/平仓订单并更正分析数据。
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card bg-dark border-secondary mb-4">
                <div class="card-header"><strong><i class="fas fa-history"></i> 对账历史</strong></div>
                <div class="card-body p-0">
                    <table class="table table-dark table-striped table-sm mb-0">
                        <thead>
                            <tr>
                                <th>时间</th>
                                <th>日期</th>
                                <th>账户</th>
                                <th>类型</th>
                                <th>状态</th>
                                <th>拉取</th>
                                <th>新增</th>
                                <th>匹配</th>
                                <th>更正</th>
                                <th>新建</th>
                            </tr>
                        </thead>
                        <tbody>'''
    
    for run in recent_runs:
        status_badge = 'success' if run.status == 'completed' else ('danger' if run.status == 'failed' else 'warning')
        html += f'''
                            <tr>
                                <td>{run.started_at.strftime('%m-%d %H:%M') if run.started_at else '-'}</td>
                                <td>{run.run_date}</td>
                                <td>{run.account_type}</td>
                                <td>{run.run_type}</td>
                                <td><span class="badge bg-{status_badge}">{run.status}</span></td>
                                <td>{run.total_orders_fetched or 0}</td>
                                <td>{run.new_orders_stored or 0}</td>
                                <td>{run.positions_matched or 0}</td>
                                <td>{run.records_corrected or 0}</td>
                                <td>{run.records_created or 0}</td>
                            </tr>'''
    
    if not recent_runs:
        html += '<tr><td colspan="10" class="text-center text-muted">暂无对账记录</td></tr>'
    
    html += '''
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="card bg-dark border-secondary">
                <div class="card-header"><strong><i class="fas fa-list"></i> Tiger原始成交记录 (最近50条)</strong></div>
                <div class="card-body p-0">
                    <table class="table table-dark table-striped table-sm mb-0">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>账户</th>
                                <th>股票</th>
                                <th>方向</th>
                                <th>开/平</th>
                                <th>数量</th>
                                <th>成交价</th>
                                <th>盈亏</th>
                                <th>手续费</th>
                                <th>成交时间</th>
                                <th>已对账</th>
                            </tr>
                        </thead>
                        <tbody>'''
    
    for order in recent_orders:
        is_open_badge = '<span class="badge bg-primary">开仓</span>' if order.is_open else '<span class="badge bg-danger">平仓</span>'
        recon_badge = '<span class="badge bg-success">✓</span>' if order.reconciled else '<span class="badge bg-secondary">—</span>'
        pnl_color = 'text-success' if (order.realized_pnl or 0) > 0 else ('text-danger' if (order.realized_pnl or 0) < 0 else '')
        html += f'''
                            <tr>
                                <td><small>{order.order_id}</small></td>
                                <td>{order.account_type}</td>
                                <td><strong>{order.symbol}</strong></td>
                                <td>{order.action}</td>
                                <td>{is_open_badge}</td>
                                <td>{order.filled or order.quantity or 0}</td>
                                <td>${order.avg_fill_price or 0:.2f}</td>
                                <td class="{pnl_color}">${order.realized_pnl or 0:.2f}</td>
                                <td>${order.commission or 0:.2f}</td>
                                <td><small>{order.trade_time_str or '-'}</small></td>
                                <td>{recon_badge}</td>
                            </tr>'''
    
    if not recent_orders:
        html += '<tr><td colspan="11" class="text-center text-muted">暂无数据，请先拉取</td></tr>'
    
    html += '''
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
    </html>'''
    
    return html
