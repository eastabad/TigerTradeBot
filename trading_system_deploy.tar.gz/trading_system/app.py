import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///trading.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

def run_migrations():
    """Run database migrations to add missing columns"""
    from sqlalchemy import text, inspect
    
    migrations = [
        # TrailingStopPosition: first_entry_price
        ("trailing_stop_position", "first_entry_price", "ALTER TABLE trailing_stop_position ADD COLUMN first_entry_price FLOAT"),
        # TrailingStopPosition: signal_stop_loss (original signal stop, never changes)
        ("trailing_stop_position", "signal_stop_loss", "ALTER TABLE trailing_stop_position ADD COLUMN signal_stop_loss FLOAT"),
        # TrailingStopConfig: tightening settings
        ("trailing_stop_config", "tighten_threshold", "ALTER TABLE trailing_stop_config ADD COLUMN tighten_threshold FLOAT DEFAULT 0.02"),
        ("trailing_stop_config", "tighten_atr_multiplier", "ALTER TABLE trailing_stop_config ADD COLUMN tighten_atr_multiplier FLOAT DEFAULT 0.6"),
        ("trailing_stop_config", "tighten_trail_pct", "ALTER TABLE trailing_stop_config ADD COLUMN tighten_trail_pct FLOAT DEFAULT 0.005"),
        # CompletedTrade: FIFO tracking fields
        ("completed_trade", "remaining_quantity", "ALTER TABLE completed_trade ADD COLUMN remaining_quantity FLOAT"),
        ("completed_trade", "exited_quantity", "ALTER TABLE completed_trade ADD COLUMN exited_quantity FLOAT DEFAULT 0"),
        ("completed_trade", "avg_exit_price", "ALTER TABLE completed_trade ADD COLUMN avg_exit_price FLOAT"),
        # TrailingStopPosition: trigger retry count for safe close
        ("trailing_stop_position", "trigger_retry_count", "ALTER TABLE trailing_stop_position ADD COLUMN trigger_retry_count INTEGER DEFAULT 0"),
    ]
    
    inspector = inspect(db.engine)
    
    for table_name, column_name, sql in migrations:
        try:
            if table_name in inspector.get_table_names():
                columns = [col['name'] for col in inspector.get_columns(table_name)]
                if column_name not in columns:
                    db.session.execute(text(sql))
                    db.session.commit()
                    logging.info(f"✅ Migration: Added {column_name} to {table_name}")
        except Exception as e:
            db.session.rollback()
            logging.warning(f"Migration skipped for {table_name}.{column_name}: {e}")
    
    # Update existing config values (data migration)
    try:
        # Update switch_profit_ratio from 0.90 to 0.85 and switch_profit_ratio_strong from 0.95 to 0.90
        db.session.execute(text("""
            UPDATE trailing_stop_config 
            SET switch_profit_ratio = 0.85, switch_profit_ratio_strong = 0.90 
            WHERE switch_profit_ratio = 0.90 AND switch_profit_ratio_strong = 0.95
        """))
        db.session.commit()
        logging.info("✅ Updated switch_profit_ratio to 0.85 and switch_profit_ratio_strong to 0.90")
    except Exception as e:
        db.session.rollback()
        logging.warning(f"Data migration skipped: {e}")
    
    # Initialize signal_stop_loss from fixed_stop_loss for existing active positions
    try:
        result = db.session.execute(text("""
            UPDATE trailing_stop_position 
            SET signal_stop_loss = fixed_stop_loss 
            WHERE signal_stop_loss IS NULL AND is_active = true
        """))
        db.session.commit()
        if result.rowcount > 0:
            logging.info(f"✅ Initialized signal_stop_loss for {result.rowcount} active positions")
    except Exception as e:
        db.session.rollback()
        logging.warning(f"signal_stop_loss initialization skipped: {e}")
    
    # Initialize remaining_quantity for open CompletedTrade records
    try:
        result = db.session.execute(text("""
            UPDATE completed_trade 
            SET remaining_quantity = entry_quantity, exited_quantity = 0 
            WHERE remaining_quantity IS NULL AND is_open = true
        """))
        db.session.commit()
        if result.rowcount > 0:
            logging.info(f"✅ Initialized remaining_quantity for {result.rowcount} open trades")
    except Exception as e:
        db.session.rollback()
        logging.warning(f"remaining_quantity initialization skipped: {e}")
    
    # Backfill exit_indicator from exit_signal_content JSON for historical records
    try:
        result = db.session.execute(text("""
            UPDATE closed_position 
            SET exit_indicator = (exit_signal_content::json->'extras'->>'indicator')
            WHERE exit_indicator IS NULL 
            AND exit_signal_content IS NOT NULL 
            AND exit_signal_content LIKE '%"indicator"%'
        """))
        db.session.commit()
        if result.rowcount > 0:
            logging.info(f"✅ Backfilled exit_indicator for {result.rowcount} closed positions")
    except Exception as e:
        db.session.rollback()
        logging.warning(f"exit_indicator backfill skipped: {e}")

with app.app_context():
    # Import models to ensure tables are created
    import models
    db.create_all()
    
    # Run migrations to add any missing columns
    run_migrations()

# Import routes
from routes import *

# Start trailing stop scheduler (only in main process)
def start_trailing_stop_scheduler():
    try:
        from trailing_stop_scheduler import start_scheduler
        start_scheduler(app, interval_seconds=5)
        logging.info("📊 Trailing stop auto-scheduler initialized")
    except Exception as e:
        logging.error(f"Failed to start trailing stop scheduler: {str(e)}")

# Initialize Tiger WebSocket push client for real-time data
# Only initialize in a single process to avoid duplicate connections
_push_client_initialized = False

def start_push_client():
    global _push_client_initialized
    if _push_client_initialized:
        return
    
    try:
        from tiger_push_client import initialize_push_client
        if initialize_push_client(register_handlers=True):
            logging.info("📊 Tiger WebSocket push client initialized")
            _push_client_initialized = True
        else:
            logging.warning("⚠️ Tiger WebSocket push client failed to connect, using polling fallback")
    except Exception as e:
        logging.error(f"Failed to initialize push client: {str(e)}")

# Start reconciliation scheduler (hourly fetch) - uses lock to prevent duplicate runs
_reconciliation_scheduler_started = False

def start_reconciliation_scheduler():
    global _reconciliation_scheduler_started
    if _reconciliation_scheduler_started:
        return
    _reconciliation_scheduler_started = True
    
    try:
        from reconciliation_service import scheduled_fetch_filled_orders, scheduled_reconciliation
        import threading
        
        def _reconciliation_loop():
            import time as time_module
            time_module.sleep(60)
            while True:
                try:
                    scheduled_fetch_filled_orders(app)
                    scheduled_reconciliation(app)
                except Exception as e:
                    logging.error(f"Reconciliation scheduler error: {str(e)}")
                time_module.sleep(3600)
        
        t = threading.Thread(target=_reconciliation_loop, daemon=True)
        t.start()
        logging.info("📊 Reconciliation scheduler initialized (hourly fetch)")
    except Exception as e:
        logging.error(f"Failed to start reconciliation scheduler: {str(e)}")

# Start scheduler when app initializes
start_trailing_stop_scheduler()

# Start WebSocket push client
start_push_client()

# Start reconciliation scheduler
start_reconciliation_scheduler()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
