#!/bin/bash

# Trading System Startup Script
# Usage: ./start.sh [dev|prod]

MODE=${1:-dev}
PORT=${PORT:-5000}
WORKERS=${WORKERS:-2}

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Activate virtual environment if exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

echo "Starting Trading System in $MODE mode..."

if [ "$MODE" = "prod" ]; then
    # Production mode
    gunicorn --bind 0.0.0.0:$PORT \
             --workers $WORKERS \
             --access-logfile - \
             --error-logfile - \
             main:app
else
    # Development mode with auto-reload
    gunicorn --bind 0.0.0.0:$PORT \
             --workers 1 \
             --reload \
             main:app
fi
