# 自动交易系统 VPS 部署指南

## 系统要求

- Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- Python 3.11+
- PostgreSQL 14+
- 至少 1GB RAM

## 快速部署

### 1. 安装依赖

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install python3.11 python3.11-venv python3-pip postgresql postgresql-contrib

# 或者使用 CentOS
sudo dnf install python3.11 postgresql-server postgresql-contrib
```

### 2. 创建数据库

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE trading_system;
CREATE USER trading_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE trading_system TO trading_user;
\q
```

### 3. 部署应用

```bash
# 解压项目
unzip trading_system.zip -d /opt/trading
cd /opt/trading

# 创建虚拟环境
python3.11 -m venv venv
source venv/bin/activate

# 安装依赖
pip install -r deploy/requirements.txt
```

### 4. 配置环境变量

创建 `.env` 文件：

```bash
cat > .env << 'EOF'
# 数据库配置
DATABASE_URL=postgresql://trading_user:your_secure_password@localhost:5432/trading_system

# Flask 密钥
SESSION_SECRET=your_random_secret_key_here

# Tiger API 配置
TIGER_API_KEY=your_tiger_api_key
TIGER_SECRET_KEY=your_tiger_secret_key
TIGER_ACCOUNT=your_account_id

# Discord 通知 (可选)
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/xxx
DISCORD_TTS_WEBHOOK_URL=https://discord.com/api/webhooks/xxx
EOF
```

### 5. 初始化数据库

```bash
source venv/bin/activate
python -c "from app import app, db; app.app_context().push(); db.create_all()"
```

### 6. 启动服务

**开发测试：**
```bash
source venv/bin/activate
gunicorn --bind 0.0.0.0:5000 --workers 2 --reload main:app
```

**生产环境（使用 systemd）：**

创建服务文件 `/etc/systemd/system/trading.service`：

```ini
[Unit]
Description=Trading System
After=network.target postgresql.service

[Service]
Type=simple
User=trading
Group=trading
WorkingDirectory=/opt/trading
Environment="PATH=/opt/trading/venv/bin"
EnvironmentFile=/opt/trading/.env
ExecStart=/opt/trading/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 2 main:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

启动服务：
```bash
sudo systemctl daemon-reload
sudo systemctl enable trading
sudo systemctl start trading
```

### 7. 配置 Nginx 反向代理（推荐）

```nginx
server {
    listen 80;
    server_name your_domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 8. 配置 SSL（推荐）

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your_domain.com
```

## Webhook 端点

部署完成后，配置 TradingView webhook 地址：

- **真实账户**: `https://your_domain.com/webhook`
- **模拟账户**: `https://your_domain.com/webhook_paper`

## 日志查看

```bash
# 查看服务状态
sudo systemctl status trading

# 查看实时日志
sudo journalctl -u trading -f

# 查看最近日志
sudo journalctl -u trading --since "1 hour ago"
```

## 常见问题

### 数据库连接失败
检查 PostgreSQL 服务状态和连接字符串是否正确。

### Tiger API 连接失败
确保 Tiger API 密钥正确，并且服务器可以访问 Tiger API 服务器。

### 后台调度器不工作
检查日志中是否有 APScheduler 启动信息，确保没有重复启动。
