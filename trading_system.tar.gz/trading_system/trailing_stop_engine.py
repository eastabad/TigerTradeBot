import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from app import db
from models import TrailingStopPosition, TrailingStopConfig, TrailingStopLog, TrailingStopMode, CompletedTrade, ExitMethod

logger = logging.getLogger(__name__)


def get_actual_stop_order_id(tiger_client, symbol: str, stored_order_id: str) -> str:
    """
    查询该股票当前的open orders，找到实际的止损订单ID
    加仓后止损订单会产生新的order_id，所以需要查询当前挂单
    
    Args:
        tiger_client: Tiger API client instance
        symbol: Stock symbol (without [PAPER] prefix)
        stored_order_id: The order_id stored in database
    
    Returns:
        The actual stop order ID (may differ from stored_order_id after scaling)
    """
    try:
        clean_symbol = symbol.replace('[PAPER]', '').strip()
        open_orders_result = tiger_client.get_open_orders_for_symbol(clean_symbol)
        
        if open_orders_result.get('success'):
            for order in open_orders_result.get('orders', []):
                order_type = getattr(order, 'order_type', '')
                order_type_str = str(order_type).upper()
                # Stop orders have type 'STP' or 'STOP' or similar
                if 'STP' in order_type_str or 'STOP' in order_type_str:
                    actual_id = str(order.id)
                    if actual_id != stored_order_id:
                        logger.info(f"📋 {symbol} 止损订单ID已更新: {stored_order_id} -> {actual_id}")
                    return actual_id
        
        # Fallback to stored order_id
        return stored_order_id
        
    except Exception as e:
        logger.warning(f"查询{symbol}当前止损订单失败: {e}, 使用存储的ID")
        return stored_order_id


def get_actual_take_profit_order_id(tiger_client, symbol: str, stored_order_id: str) -> str:
    """
    查询该股票当前的open orders，找到实际的止盈订单ID
    加仓后止盈订单会产生新的order_id，所以需要查询当前挂单
    
    Args:
        tiger_client: Tiger API client instance
        symbol: Stock symbol (without [PAPER] prefix)
        stored_order_id: The order_id stored in database
    
    Returns:
        The actual take profit order ID (may differ from stored_order_id after scaling)
    """
    try:
        clean_symbol = symbol.replace('[PAPER]', '').strip()
        open_orders_result = tiger_client.get_open_orders_for_symbol(clean_symbol)
        
        if open_orders_result.get('success'):
            for order in open_orders_result.get('orders', []):
                order_type = getattr(order, 'order_type', '')
                order_type_str = str(order_type).upper()
                # Limit orders (take profit) have type 'LMT' or 'LIMIT'
                if 'LMT' in order_type_str or 'LIMIT' in order_type_str:
                    actual_id = str(order.id)
                    if actual_id != stored_order_id:
                        logger.info(f"📋 {symbol} 止盈订单ID已更新: {stored_order_id} -> {actual_id}")
                    return actual_id
        
        # Fallback to stored order_id
        return stored_order_id
        
    except Exception as e:
        logger.warning(f"查询{symbol}当前止盈订单失败: {e}, 使用存储的ID")
        return stored_order_id


def get_trailing_stop_config() -> TrailingStopConfig:
    config = TrailingStopConfig.query.first()
    if not config:
        config = TrailingStopConfig()
        db.session.add(config)
        db.session.commit()
    return config


def calculate_atr(bars: List[Dict], period: int = 14) -> float:
    """
    计算ATR (Average True Range) 使用RMA平滑方法
    与TradingView官方ATR计算方法一致
    
    RMA公式: RMA = (previous_RMA * (period - 1) + current_value) / period
    """
    if len(bars) < period + 1:
        logger.warning(f"Not enough bars for ATR calculation: {len(bars)} < {period + 1}")
        return 0.0
    
    true_ranges = []
    for i in range(1, len(bars)):
        high = bars[i]['high']
        low = bars[i]['low']
        prev_close = bars[i-1]['close']
        
        tr = max(
            high - low,
            abs(high - prev_close),
            abs(low - prev_close)
        )
        true_ranges.append(tr)
    
    if len(true_ranges) < period:
        return sum(true_ranges) / len(true_ranges) if true_ranges else 0.0
    
    rma = sum(true_ranges[:period]) / period
    
    for i in range(period, len(true_ranges)):
        rma = (rma * (period - 1) + true_ranges[i]) / period
    
    return rma


def calculate_volatility_pct(atr: float, close_price: float) -> float:
    if close_price <= 0:
        return 0.0
    return atr / close_price


def get_profit_tier(profit_pct: float, config: TrailingStopConfig) -> int:
    if profit_pct < config.tier_0_threshold:
        return 0
    elif profit_pct < config.tier_1_threshold:
        return 1
    else:
        return 2


def get_base_multiplier(tier: int, config: TrailingStopConfig) -> float:
    if tier == 0:
        return config.tier_0_multiplier
    elif tier == 1:
        return config.tier_1_multiplier
    else:
        return config.tier_2_multiplier


def get_volatility_factor(volatility_pct: float, config: TrailingStopConfig) -> float:
    if volatility_pct > config.high_volatility_threshold:
        return config.high_volatility_factor
    elif volatility_pct > config.low_volatility_threshold:
        return config.mid_volatility_factor
    else:
        return config.low_volatility_factor


def calculate_dynamic_percent(profit_pct: float, config: TrailingStopConfig, is_switched: bool = False) -> float:
    """
    动态百分比止损计算 - 分段线性公式
    
    切换后使用更宽松的百分比表（给趋势更多空间）:
    - 浮盈 0% ~ 3%:   追踪距离 0.5% ~ 0.6%
    - 浮盈 3% ~ 5%:   追踪距离 0.6% ~ 0.8%
    - 浮盈 5% ~ 8%:   追踪距离 0.8% ~ 1.0%
    - 浮盈 8% ~ 10%:  追踪距离 1.0% ~ 1.2%
    - 浮盈 10% ~ 15%: 追踪距离 1.2% ~ 1.6%
    - 浮盈 > 15%:     追踪距离 2.0% (固定)
    
    切换前使用原有的较紧百分比（阶梯止损阶段备用）
    """
    if is_switched:
        if profit_pct < 0.03:
            percent = 0.005 + (profit_pct / 0.03) * 0.001
        elif profit_pct < 0.05:
            percent = 0.006 + ((profit_pct - 0.03) / 0.02) * 0.002
        elif profit_pct < 0.08:
            percent = 0.008 + ((profit_pct - 0.05) / 0.03) * 0.002
        elif profit_pct < 0.10:
            percent = 0.010 + ((profit_pct - 0.08) / 0.02) * 0.002
        elif profit_pct < 0.15:
            percent = 0.012 + ((profit_pct - 0.10) / 0.05) * 0.004
        else:
            percent = 0.020
    else:
        tier1_upper = config.dynamic_pct_tier1_upper
        tier2_upper = config.dynamic_pct_tier2_upper
        tier1_pct = config.dynamic_pct_tier1_percent
        tier2_pct = config.dynamic_pct_tier2_percent
        max_pct = config.max_percent_stop
        
        if profit_pct < tier1_upper:
            percent = tier1_pct * (profit_pct / tier1_upper) if tier1_upper > 0 else 0
        elif profit_pct < tier2_upper:
            range_width = tier2_upper - tier1_upper
            if range_width > 0:
                percent = tier1_pct + (tier2_pct - tier1_pct) * ((profit_pct - tier1_upper) / range_width)
            else:
                percent = tier1_pct
        else:
            extra_profit = profit_pct - tier2_upper
            extra_range = tier2_upper - tier1_upper
            if extra_range > 0:
                percent = tier2_pct + (max_pct - tier2_pct) * min(1.0, extra_profit / extra_range)
            else:
                percent = tier2_pct
            percent = min(percent, max_pct)
    
    return max(0, percent)


def get_progressive_stop_tier(profit_pct: float, config: TrailingStopConfig) -> int:
    """
    根据盈利百分比确定应该在哪个阶梯止损级别
    
    返回 0-8 对应:
    0: 保持原始止损 (profit < tier1)
    1-8: 移到对应tier止损位
    
    加密间距版本：每1%利润上移一次止损
    """
    if not getattr(config, 'progressive_stop_enabled', True):
        return 0
    
    tier_profits = [
        getattr(config, 'prog_tier1_profit', 0.01),  # 1%
        getattr(config, 'prog_tier2_profit', 0.02),  # 2%
        getattr(config, 'prog_tier3_profit', 0.03),  # 3%
        getattr(config, 'prog_tier4_profit', 0.04),  # 4%
        getattr(config, 'prog_tier5_profit', 0.05),  # 5%
        getattr(config, 'prog_tier6_profit', 0.06),  # 6%
        getattr(config, 'prog_tier7_profit', 0.07),  # 7%
        getattr(config, 'prog_tier8_profit', 0.08),  # 8%
    ]
    
    for i in range(len(tier_profits) - 1, -1, -1):
        if profit_pct >= tier_profits[i]:
            return i + 1
    
    return 0


def calculate_progressive_stop_price(
    position: TrailingStopPosition,
    target_tier: int,
    config: TrailingStopConfig
) -> Optional[float]:
    """
    根据目标阶梯计算新的止损价格
    
    加密间距版本 - 每个阶梯对应的止损位:
    tier1: 0% (保本)
    tier2: 0.5%
    tier3: 1.5%
    tier4: 2.5%
    tier5: 3.5%
    tier6: 4.5%
    tier7: 5.5%
    tier8: 6.5%
    """
    if target_tier <= 0:
        return None
    
    stop_at_map = {
        1: getattr(config, 'prog_tier1_stop_at', 0.0),
        2: getattr(config, 'prog_tier2_stop_at', 0.005),
        3: getattr(config, 'prog_tier3_stop_at', 0.015),
        4: getattr(config, 'prog_tier4_stop_at', 0.025),
        5: getattr(config, 'prog_tier5_stop_at', 0.035),
        6: getattr(config, 'prog_tier6_stop_at', 0.045),
        7: getattr(config, 'prog_tier7_stop_at', 0.055),
        8: getattr(config, 'prog_tier8_stop_at', 0.065),
    }
    
    stop_at_pct = stop_at_map.get(target_tier, 0.0)
    entry_price = position.entry_price
    is_long = position.side == 'long'
    
    if is_long:
        new_stop = entry_price * (1 + stop_at_pct)
    else:
        new_stop = entry_price * (1 - stop_at_pct)
    
    return new_stop


def check_and_adjust_progressive_stop(
    position: TrailingStopPosition,
    current_price: float,
    config: TrailingStopConfig
) -> Dict:
    """
    检查并执行阶梯止损上移
    
    返回:
    {
        'should_adjust': bool,
        'current_tier': int,
        'new_tier': int,
        'new_stop_price': float,
        'reason': str
    }
    """
    result = {
        'should_adjust': False,
        'current_tier': getattr(position, 'progressive_stop_tier', 0) or 0,
        'new_tier': 0,
        'new_stop_price': None,
        'reason': ''
    }
    
    # 检查是否启用阶梯止损
    if not getattr(config, 'progressive_stop_enabled', True):
        result['reason'] = '阶梯止损未启用'
        return result
    
    # 注意: 即使stop_loss_order_id为空，execute_progressive_stop_adjustment函数
    # 也会尝试查询Tiger API获取实际的订单ID，所以这里不再检查order_id
    
    # 计算当前盈利百分比
    is_long = position.side == 'long'
    if is_long:
        profit_pct = (current_price - position.entry_price) / position.entry_price
    else:
        profit_pct = (position.entry_price - current_price) / position.entry_price
    
    # 确定当前应该在哪个阶梯
    target_tier = get_progressive_stop_tier(profit_pct, config)
    current_tier = result['current_tier']
    
    result['new_tier'] = target_tier
    
    # 只向上移动，不回撤
    if target_tier <= current_tier:
        result['reason'] = f'当前tier={current_tier}, 目标tier={target_tier}, 无需调整'
        return result
    
    # 计算新止损价格
    new_stop_price = calculate_progressive_stop_price(position, target_tier, config)
    
    if new_stop_price is None:
        result['reason'] = f'无法计算tier {target_tier}的止损价格'
        return result
    
    # 检查新止损价是否比当前止损更有利
    # 使用current_trailing_stop（如果有）或fixed_stop_loss作为参考
    current_stop = position.current_trailing_stop or position.fixed_stop_loss or 0
    if is_long:
        if new_stop_price <= current_stop:
            result['reason'] = f'新止损${new_stop_price:.2f} <= 当前止损${current_stop:.2f}'
            return result
    else:
        if new_stop_price >= current_stop:
            result['reason'] = f'新止损${new_stop_price:.2f} >= 当前止损${current_stop:.2f}'
            return result
    
    # 需要调整
    result['should_adjust'] = True
    result['new_stop_price'] = new_stop_price
    tier_names = {
        1: '保本', 2: '0.5%利润', 3: '1.5%利润', 4: '2.5%利润',
        5: '3.5%利润', 6: '4.5%利润', 7: '5.5%利润', 8: '6.5%利润'
    }
    result['reason'] = f'盈利{profit_pct*100:.1f}%触发tier{target_tier}({tier_names.get(target_tier, "")}), 止损上移至${new_stop_price:.2f}'
    
    return result


def execute_progressive_stop_adjustment(
    position: TrailingStopPosition,
    new_stop_price: float,
    new_tier: int,
    account_type: str = 'real'
) -> Dict:
    """
    执行阶梯止损上移 - 通过Tiger API修改止损订单
    
    同时发送外部webhook信号:
    - 如果止盈订单还存在: cancel + exit(SL+TP)
    - 如果止盈已取消(切换到移动止损): cancel + exit(SL only)
    
    返回:
    {
        'success': bool,
        'new_order_id': str,
        'message': str,
        'webhook_result': dict
    }
    """
    from tiger_client import TigerClient, TigerPaperClient
    
    result = {
        'success': False,
        'new_order_id': None,
        'message': '',
        'webhook_result': None
    }
    
    try:
        # 选择正确的客户端
        if account_type == 'paper':
            client = TigerPaperClient()
        else:
            client = TigerClient()
        
        # 确定止损方向
        side = 'sell' if position.side == 'long' else 'buy'
        
        # 查询实际的止损订单ID（即使stored_order_id为空也尝试查询）
        actual_stop_order_id = get_actual_stop_order_id(
            client, position.symbol, position.stop_loss_order_id or ''
        )
        
        if not actual_stop_order_id:
            result['message'] = f"没有找到止损订单，无法执行阶梯止损调整"
            logger.error(f"⚠️ [{account_type.upper()}] {position.symbol} {result['message']}")
            return result
        
        if actual_stop_order_id != position.stop_loss_order_id:
            logger.info(f"📋 {position.symbol} 发现止损订单ID: {actual_stop_order_id}")
            position.stop_loss_order_id = actual_stop_order_id
        
        # 调用修改止损订单
        modify_result = client.modify_stop_loss_price(
            old_order_id=actual_stop_order_id,
            symbol=position.symbol,
            quantity=position.quantity,
            new_stop_price=new_stop_price,
            side=side
        )
        
        if modify_result['success']:
            # 更新position记录
            position.stop_loss_order_id = modify_result['new_order_id']
            position.progressive_stop_tier = new_tier
            position.last_stop_adjustment_price = new_stop_price
            position.stop_adjustment_count = (position.stop_adjustment_count or 0) + 1
            position.fixed_stop_loss = new_stop_price  # 更新固定止损价格
            position.current_trailing_stop = new_stop_price  # 同步更新移动止损显示
            
            db.session.commit()
            
            result['success'] = True
            result['new_order_id'] = modify_result['new_order_id']
            result['message'] = f'止损已上移至${new_stop_price:.2f} (tier {new_tier})'
            
            logger.info(f"📈 [{account_type.upper()}] {position.symbol} 止损上移成功: ${new_stop_price:.2f}, 新订单ID={modify_result['new_order_id']}")
            
            # 发送外部webhook信号
            # 检查止盈订单状态: 如果已切换到移动止损或没有止盈订单，则不带止盈
            take_profit_price = None
            if not position.has_switched_to_trailing and position.take_profit_order_id and position.fixed_take_profit:
                take_profit_price = position.fixed_take_profit
                logger.info(f"📤 {position.symbol} 阶梯止损上移: 保留止盈订单 TP=${take_profit_price:.2f}")
            else:
                logger.info(f"📤 {position.symbol} 阶梯止损上移: 止盈已取消或不存在")
            
            webhook_result = send_progressive_stop_webhook(
                symbol=position.symbol,
                new_stop_price=new_stop_price,
                take_profit_price=take_profit_price
            )
            result['webhook_result'] = webhook_result
            logger.info(f"📤 {position.symbol} 外部webhook发送结果: {webhook_result['message']}")
            
        else:
            result['message'] = f"修改止损订单失败: {modify_result.get('error', 'Unknown error')}"
            logger.error(f"❌ [{account_type.upper()}] {position.symbol} 止损上移失败: {result['message']}")
        
    except Exception as e:
        result['message'] = f"执行止损上移异常: {str(e)}"
        logger.error(f"❌ [{account_type.upper()}] {position.symbol} {result['message']}")
    
    return result


def calculate_trend_strength(
    bars: List[Dict],
    current_price: float,
    entry_price: float,
    side: str,
    atr: float,
    config: TrailingStopConfig
) -> Dict:
    """
    计算综合趋势强度评分 (0-100)
    
    三个指标:
    1. ATR收敛度 - 当前ATR vs 平均ATR，越小趋势越稳定
    2. 动量评分 - 价格移动距离 / ATR，越大趋势越强
    3. 连续创新高/低 - 连续多少根K线创新高或新低
    """
    result = {
        'trend_strength': 0.0,
        'atr_convergence': 1.0,
        'momentum_score': 0.0,
        'consecutive_highs': 0,
        'atr_convergence_score': 0.0,
        'momentum_normalized': 0.0,
        'consecutive_score': 0.0
    }
    
    if len(bars) < config.momentum_lookback + 1 or atr <= 0:
        return result
    
    is_long = side == 'long'
    
    recent_bars = bars[-(config.momentum_lookback + 5):]
    atrs = []
    for i in range(1, len(recent_bars)):
        high = recent_bars[i]['high']
        low = recent_bars[i]['low']
        prev_close = recent_bars[i-1]['close']
        tr = max(high - low, abs(high - prev_close), abs(low - prev_close))
        atrs.append(tr)
    
    if len(atrs) >= 2:
        avg_atr = sum(atrs) / len(atrs)
        if avg_atr > 0:
            atr_convergence = atr / avg_atr
            result['atr_convergence'] = atr_convergence
            if atr_convergence < 0.7:
                result['atr_convergence_score'] = 100
            elif atr_convergence < 0.85:
                result['atr_convergence_score'] = 70
            elif atr_convergence < 1.0:
                result['atr_convergence_score'] = 50
            elif atr_convergence < 1.2:
                result['atr_convergence_score'] = 30
            else:
                result['atr_convergence_score'] = 0
    
    lookback_bars = bars[-config.momentum_lookback:]
    if len(lookback_bars) >= 2:
        start_price = lookback_bars[0]['close']
        price_move = current_price - start_price
        if not is_long:
            price_move = -price_move
        
        momentum = price_move / atr if atr > 0 else 0
        result['momentum_score'] = momentum
        
        if momentum >= 3.0:
            result['momentum_normalized'] = 100
        elif momentum >= 2.0:
            result['momentum_normalized'] = 80
        elif momentum >= 1.0:
            result['momentum_normalized'] = 60
        elif momentum >= 0.5:
            result['momentum_normalized'] = 40
        elif momentum > 0:
            result['momentum_normalized'] = 20
        else:
            result['momentum_normalized'] = 0
    
    consecutive = 0
    recent_check = bars[-min(10, len(bars)):]
    
    if is_long:
        prev_high = None
        for bar in recent_check:
            if prev_high is not None and bar['high'] > prev_high:
                consecutive += 1
            else:
                consecutive = 0
            prev_high = bar['high']
    else:
        prev_low = None
        for bar in recent_check:
            if prev_low is not None and bar['low'] < prev_low:
                consecutive += 1
            else:
                consecutive = 0
            prev_low = bar['low']
    
    result['consecutive_highs'] = consecutive
    
    if consecutive >= 5:
        result['consecutive_score'] = 100
    elif consecutive >= 4:
        result['consecutive_score'] = 80
    elif consecutive >= 3:
        result['consecutive_score'] = 60
    elif consecutive >= 2:
        result['consecutive_score'] = 40
    elif consecutive >= 1:
        result['consecutive_score'] = 20
    else:
        result['consecutive_score'] = 0
    
    trend_strength = (
        result['atr_convergence_score'] * config.atr_convergence_weight +
        result['momentum_normalized'] * config.momentum_weight +
        result['consecutive_score'] * config.consecutive_weight
    )
    result['trend_strength'] = min(100, max(0, trend_strength))
    
    return result


def calculate_trailing_stop(
    position: TrailingStopPosition,
    current_price: float,
    atr: float,
    config: TrailingStopConfig
) -> Tuple[float, Dict]:
    """
    计算移动止损价格
    
    切换前: 使用阶梯止损（Progressive Stop）
    切换后: 使用ATR和动态百分比，取更宽松的值
    """
    is_long = position.side == 'long'
    is_switched = position.has_switched_to_trailing
    
    if is_long:
        if position.highest_price is None or current_price > position.highest_price:
            position.highest_price = current_price
        reference_price = position.highest_price
        profit_pct = (current_price - position.entry_price) / position.entry_price
    else:
        if position.lowest_price is None or current_price < position.lowest_price:
            position.lowest_price = current_price
        reference_price = position.lowest_price
        profit_pct = (position.entry_price - current_price) / position.entry_price
    
    position.current_profit_pct = profit_pct
    
    volatility_pct = calculate_volatility_pct(atr, current_price)
    position.volatility_pct = volatility_pct
    position.current_atr = atr
    
    tier = get_profit_tier(max(0, profit_pct), config)
    position.profit_tier = tier
    
    prog_tier = get_progressive_stop_tier(max(0, profit_pct), config)
    
    if is_switched:
        # Check if we should tighten trailing due to cost being close to current price
        # 成本距离比 = (当前价 - 平均成本) / 当前价 (做多)
        if is_long:
            cost_distance_ratio = (current_price - position.entry_price) / current_price if current_price > 0 else 0
        else:
            cost_distance_ratio = (position.entry_price - current_price) / current_price if current_price > 0 else 0
        
        # Get tighten thresholds from config (with defaults)
        tighten_threshold = getattr(config, 'tighten_threshold', 0.02)
        tighten_atr_multiplier = getattr(config, 'tighten_atr_multiplier', 0.6)
        tighten_trail_pct = getattr(config, 'tighten_trail_pct', 0.005)
        
        # Determine if tightening is needed
        should_tighten = cost_distance_ratio < tighten_threshold and cost_distance_ratio > 0
        
        if should_tighten:
            effective_multiplier = tighten_atr_multiplier
            dynamic_percent = tighten_trail_pct
            logger.debug(f"🔧 收紧trailing: 成本距离{cost_distance_ratio*100:.2f}% < {tighten_threshold*100}%, "
                        f"ATR倍数{effective_multiplier}, trail%={dynamic_percent*100}%")
        else:
            effective_multiplier = config.post_switch_multiplier
            dynamic_percent = calculate_dynamic_percent(max(0, profit_pct), config, is_switched=True)
        
        if is_long:
            stop_atr = reference_price - (atr * effective_multiplier)
        else:
            stop_atr = reference_price + (atr * effective_multiplier)
        
        if is_long:
            stop_percent = reference_price * (1 - dynamic_percent)
        else:
            stop_percent = reference_price * (1 + dynamic_percent)
        
        if is_long:
            new_stop = min(stop_atr, stop_percent)
        else:
            new_stop = max(stop_atr, stop_percent)
        
        if position.current_trailing_stop is not None:
            if is_long:
                new_stop = max(new_stop, position.current_trailing_stop)
            else:
                new_stop = min(new_stop, position.current_trailing_stop)
    else:
        stop_atr = 0
        dynamic_percent = 0
        stop_percent = 0
        effective_multiplier = 0
        
        if prog_tier > 0:
            prog_stop = calculate_progressive_stop_price(position, prog_tier, config)
            if prog_stop is not None:
                new_stop = prog_stop
                if position.current_trailing_stop is not None:
                    if is_long:
                        new_stop = max(new_stop, position.current_trailing_stop)
                    else:
                        new_stop = min(new_stop, position.current_trailing_stop)
            else:
                new_stop = position.fixed_stop_loss or position.current_trailing_stop or position.entry_price
        else:
            new_stop = position.fixed_stop_loss or position.current_trailing_stop or position.entry_price
    
    # Include tightening info in details (only available when switched)
    cost_dist = cost_distance_ratio if is_switched else None
    is_tightened = should_tighten if is_switched else False
    
    calculation_details = {
        'reference_price': reference_price,
        'profit_pct': profit_pct,
        'tier': tier,
        'prog_tier': prog_tier,
        'effective_multiplier': effective_multiplier,
        'atr': atr,
        'volatility_pct': volatility_pct,
        'stop_atr': stop_atr,
        'dynamic_percent': dynamic_percent,
        'stop_percent': stop_percent,
        'new_stop': new_stop,
        'is_switched': is_switched,
        'cost_distance_ratio': cost_dist,
        'is_tightened': is_tightened
    }
    
    return new_stop, calculation_details


def calculate_inverse_protection_stop(
    position: TrailingStopPosition,
    current_price: float,
    trend_strength: float,
    config: TrailingStopConfig
) -> Tuple[Optional[float], Dict]:
    """
    反向保护止损计算
    
    当价格反向移动（亏损方向），根据趋势强度决定是否收紧止损
    
    触发条件: 亏损 >= 止损距离的50%
    
    收紧规则:
    - 弱趋势(0-30): 收紧至止损距离的60% (快速止损)
    - 中趋势(30-60): 收紧至止损距离的70%
    - 强趋势(60+): 保持原止损不变
    """
    is_long = position.side == 'long'
    original_stop = position.fixed_stop_loss
    
    if original_stop is None:
        return None, {'reason': 'No original stop loss set'}
    
    if is_long:
        stop_distance = position.entry_price - original_stop
        current_loss = position.entry_price - current_price
    else:
        stop_distance = original_stop - position.entry_price
        current_loss = current_price - position.entry_price
    
    if stop_distance <= 0:
        return None, {'reason': 'Invalid stop distance'}
    
    loss_ratio = current_loss / stop_distance
    
    trigger_threshold = 0.50
    
    if loss_ratio < trigger_threshold:
        return None, {
            'reason': 'Loss ratio below threshold',
            'loss_ratio': loss_ratio,
            'threshold': trigger_threshold
        }
    
    if trend_strength >= 60:
        return None, {
            'reason': 'Strong trend - keep original stop',
            'loss_ratio': loss_ratio,
            'trend_strength': trend_strength,
            'tightening_factor': 1.0
        }
    elif trend_strength >= 30:
        tightening_factor = 0.70
    else:
        tightening_factor = 0.60
    
    if is_long:
        new_stop = position.entry_price - (stop_distance * tightening_factor)
    else:
        new_stop = position.entry_price + (stop_distance * tightening_factor)
    
    current_stop = position.current_trailing_stop or original_stop
    
    should_update = False
    if is_long:
        if new_stop > current_stop:
            should_update = True
    else:
        if new_stop < current_stop:
            should_update = True
    
    if not should_update:
        return None, {
            'reason': 'New stop not tighter than current',
            'loss_ratio': loss_ratio,
            'trend_strength': trend_strength,
            'new_stop': new_stop,
            'current_stop': current_stop
        }
    
    return new_stop, {
        'action': 'tighten',
        'loss_ratio': loss_ratio,
        'trend_strength': trend_strength,
        'tightening_factor': tightening_factor,
        'original_stop': original_stop,
        'new_stop': new_stop,
        'stop_distance': stop_distance,
        'current_loss': current_loss
    }


def check_switch_condition(
    position: TrailingStopPosition,
    current_price: float,
    config: TrailingStopConfig,
    trend_strength: float = 0.0
) -> Tuple[bool, str]:
    """
    检查是否应该切换到动态移动止损
    
    三种触发条件（满足任一即切换）：
    条件A (原有): 达到止盈比例 (90%/95%计划利润)
    条件B (新增): 利润>=5% 且 趋势强度>=60
    条件C (新增): 利润>=10% 强制切换
    """
    if position.has_switched_to_trailing:
        return False, "Already switched"
    
    is_long = position.side == 'long'
    
    if is_long:
        current_profit = current_price - position.entry_price
    else:
        current_profit = position.entry_price - current_price
    
    profit_pct = current_profit / position.entry_price if position.entry_price > 0 else 0
    
    switch_profit_threshold = getattr(config, 'switch_profit_threshold', 0.05)
    switch_force_profit = getattr(config, 'switch_force_profit', 0.10)
    
    if profit_pct >= switch_force_profit:
        return True, f"[条件C] 利润{profit_pct*100:.1f}% >= {switch_force_profit*100:.0f}% 强制切换"
    
    if profit_pct >= switch_profit_threshold and trend_strength >= config.trend_strength_threshold:
        return True, f"[条件B] 利润{profit_pct*100:.1f}% + 趋势强度{trend_strength:.0f} 触发切换"
    
    if position.fixed_take_profit is not None:
        planned_profit = abs(position.fixed_take_profit - position.entry_price)
        
        if planned_profit > 0:
            profit_achieved_ratio = current_profit / planned_profit
            
            if trend_strength >= config.trend_strength_threshold:
                switch_ratio = config.switch_profit_ratio_strong
                trend_label = "强势趋势"
            else:
                switch_ratio = config.switch_profit_ratio
                trend_label = "普通趋势"
            
            if profit_achieved_ratio >= switch_ratio:
                return True, f"[条件A-{trend_label}] 达到 {profit_achieved_ratio*100:.1f}% 计划利润"
            
            return False, f"[{trend_label}] 利润{profit_pct*100:.1f}%, 计划利润进度{profit_achieved_ratio*100:.1f}%"
    
    return False, f"利润{profit_pct*100:.1f}%, 趋势{trend_strength:.0f}, 未达切换条件"


def check_stop_triggered(
    position: TrailingStopPosition,
    current_price: float
) -> Tuple[bool, str]:
    
    if position.current_trailing_stop is None:
        return False, "No trailing stop set"
    
    is_long = position.side == 'long'
    
    if is_long:
        if position.fixed_stop_loss and position.current_trailing_stop <= position.fixed_stop_loss:
            return False, "Trailing stop below fixed stop loss, fixed stop takes precedence"
        
        if current_price <= position.current_trailing_stop:
            return True, f"Price ${current_price:.2f} <= Trailing Stop ${position.current_trailing_stop:.2f}"
    else:
        if position.fixed_stop_loss and position.current_trailing_stop >= position.fixed_stop_loss:
            return False, "Trailing stop above fixed stop loss, fixed stop takes precedence"
        
        if current_price >= position.current_trailing_stop:
            return True, f"Price ${current_price:.2f} >= Trailing Stop ${position.current_trailing_stop:.2f}"
    
    return False, "Stop not triggered"


EXTERNAL_WEBHOOK_URL = "https://webhook-migration.replit.app/webhook/signal"


def send_external_webhook_signal(signal_type: str, symbol: str, **kwargs) -> Dict:
    """
    发送外部webhook信号，支持多种信号类型
    
    Args:
        signal_type: 信号类型 - 'cancel', 'exit', 'close'
        symbol: 股票代码
        **kwargs: 其他参数
            - stop_loss: 止损价格 (用于exit)
            - take_profit: 止盈价格 (用于exit)
            - action: 'sell' 或 'buy' (用于close)
            - extras: 附加信息字典
    
    Returns:
        {'success': bool, 'response_code': int, 'message': str}
    """
    import requests
    
    # Clean symbol - remove [PAPER] prefix if present
    clean_symbol = symbol.replace('[PAPER]', '').strip()
    
    result = {
        'success': False,
        'response_code': None,
        'message': ''
    }
    
    try:
        if signal_type == 'cancel':
            # 取消该ticker下所有挂单
            signal = {
                'ticker': clean_symbol,
                'action': 'cancel'
            }
            
        elif signal_type == 'exit':
            # 下达止损/止盈订单
            signal = {
                'ticker': clean_symbol,
                'action': 'exit'
            }
            
            stop_loss = kwargs.get('stop_loss')
            take_profit = kwargs.get('take_profit')
            
            if stop_loss:
                signal['stop_loss'] = {'stop_price': stop_loss}
            if take_profit:
                signal['take_profit'] = {'limit_price': take_profit}
            
            # 添加extras如果有
            if kwargs.get('extras'):
                signal['extras'] = kwargs['extras']
                
        elif signal_type == 'close':
            # 平仓信号
            action = kwargs.get('action', 'sell')
            signal = {
                'action': action,
                'ticker': clean_symbol,
                'quantity': 'all',
                'sentiment': 'flat'
            }
            if kwargs.get('extras'):
                signal['extras'] = kwargs['extras']
        else:
            result['message'] = f'Unknown signal type: {signal_type}'
            return result
        
        logger.info(f"📤 Sending external webhook [{signal_type}] for {clean_symbol}: {signal}")
        
        response = requests.post(
            EXTERNAL_WEBHOOK_URL,
            json=signal,
            timeout=10
        )
        
        result['response_code'] = response.status_code
        result['success'] = response.status_code in [200, 201, 204]
        
        # 记录响应内容以便排查问题
        try:
            response_body = response.text[:500] if response.text else 'empty'
        except:
            response_body = 'could not read response'
        
        result['message'] = f"Response: {response.status_code}"
        result['response_body'] = response_body
        
        if result['success']:
            logger.info(f"✅ External webhook [{signal_type}] success for {symbol}: status={response.status_code}")
        else:
            logger.error(f"❌ External webhook [{signal_type}] failed for {symbol}: status={response.status_code}, body={response_body}")
        
    except Exception as e:
        result['message'] = str(e)
        logger.error(f"❌ Error sending external webhook for {symbol}: {str(e)}")
    
    return result


def send_progressive_stop_webhook(
    symbol: str,
    new_stop_price: float,
    take_profit_price: float = None
) -> Dict:
    """
    发送阶梯止损上移的外部webhook信号
    
    步骤:
    1. 先发送cancel取消所有挂单
    2. 再发送exit，带上新止损价格，如果有止盈则带上原止盈价格
    """
    results = {
        'cancel_sent': False,
        'exit_sent': False,
        'message': ''
    }
    
    # Step 1: 发送cancel
    cancel_result = send_external_webhook_signal('cancel', symbol)
    results['cancel_sent'] = cancel_result['success']
    
    if not cancel_result['success']:
        results['message'] = f"Cancel failed: {cancel_result['message']}"
        logger.warning(f"⚠️ Cancel signal failed for {symbol}, continuing with exit...")
    
    # Step 2: 发送exit
    import time
    time.sleep(0.3)  # 短暂等待确保cancel处理
    
    exit_kwargs = {
        'stop_loss': new_stop_price,
        'extras': {
            'indicator': 'progressive_stop_adjustment',
            'new_stop_price': new_stop_price
        }
    }
    
    if take_profit_price:
        exit_kwargs['take_profit'] = take_profit_price
        exit_kwargs['extras']['take_profit_price'] = take_profit_price
    
    exit_result = send_external_webhook_signal('exit', symbol, **exit_kwargs)
    results['exit_sent'] = exit_result['success']
    results['exit_response'] = exit_result.get('response_body', '')
    
    if exit_result['success']:
        tp_msg = f" + TP=${take_profit_price:.2f}" if take_profit_price else " (无止盈)"
        results['message'] = f"已发送: SL=${new_stop_price:.2f}{tp_msg}"
        logger.info(f"✅ {symbol} 阶梯止损调整完成: cancel={results['cancel_sent']}, exit={results['exit_sent']}")
    else:
        results['message'] = f"Exit failed: {exit_result['message']}"
        logger.error(f"❌ {symbol} 阶梯止损exit失败: {exit_result.get('message')} | response: {exit_result.get('response_body', 'N/A')}")
    
    return results


def send_switch_to_trailing_webhook(
    symbol: str,
    new_stop_price: float
) -> Dict:
    """
    发送切换到移动止损的外部webhook信号
    
    取消止盈后，重新下达只有止损的订单
    
    步骤:
    1. 发送cancel取消所有挂单
    2. 发送exit，只带止损价格（不带止盈）
    """
    results = {
        'cancel_sent': False,
        'exit_sent': False,
        'message': ''
    }
    
    # Step 1: 发送cancel
    cancel_result = send_external_webhook_signal('cancel', symbol)
    results['cancel_sent'] = cancel_result['success']
    
    if not cancel_result['success']:
        results['message'] = f"Cancel failed: {cancel_result['message']}"
        logger.warning(f"⚠️ Cancel signal failed for {symbol}, continuing with exit...")
    
    # Step 2: 发送exit (只有止损，没有止盈)
    import time
    time.sleep(0.3)
    
    exit_result = send_external_webhook_signal('exit', symbol, 
        stop_loss=new_stop_price,
        extras={
            'indicator': 'switch_to_trailing_stop',
            'stop_price': new_stop_price,
            'reason': 'take_profit_cancelled'
        }
    )
    results['exit_sent'] = exit_result['success']
    
    if exit_result['success']:
        results['message'] = f"已切换到移动止损: SL=${new_stop_price:.2f} (止盈已取消)"
    else:
        results['message'] = f"Exit failed: {exit_result['message']}"
    
    return results


def execute_trailing_stop_close(
    tiger,
    symbol: str,
    side: str,
    quantity: float,
    account_type: str,
    trigger_price: float,
    entry_price: float,
    profit_pct: float,
    timeframe: str = '15'
) -> Dict:
    import requests
    
    result = {
        'success': False,
        'tiger_order': None,
        'webhook_sent': False,
        'message': ''
    }
    
    try:
        action = 'sell' if side == 'SELL' else 'buy'
        
        close_signal = {
            'action': action,
            'ticker': symbol,
            'quantity': 'all',
            'sentiment': 'flat',
            'extras': {
                'indicator': 'trailing stop Exit',
                'referencePrice': trigger_price,
                'timeframe': timeframe,
                'entry_price': entry_price,
                'profit_pct': profit_pct,
                'account_type': account_type
            }
        }
        
        try:
            webhook_response = requests.post(
                EXTERNAL_WEBHOOK_URL,
                json=close_signal,
                timeout=10
            )
            result['webhook_sent'] = webhook_response.status_code in [200, 201, 204]
            logger.info(f"External webhook sent for {symbol}: status={webhook_response.status_code}")
        except Exception as e:
            logger.error(f"Error sending external webhook for {symbol}: {str(e)}")
            result['webhook_sent'] = False
        
        logger.info(f"🔴 Tiger close order check: tiger={tiger is not None}, tiger.client={getattr(tiger, 'client', None) is not None if tiger else 'N/A'}")
        
        if tiger and tiger.client:
            try:
                from tigeropen.common.util.contract_utils import stock_contract
                from tigeropen.common.util.order_utils import market_order
                from tigeropen.common.consts import Currency
                
                contract = stock_contract(symbol=symbol, currency=Currency.USD)
                
                logger.info(f"🔴 Placing Tiger market order: symbol={symbol}, side={side}, quantity={quantity}")
                
                order = market_order(
                    account=tiger.client_config.account,
                    contract=contract,
                    action=side,
                    quantity=int(quantity)
                )
                
                tiger_result = tiger.client.place_order(order)
                
                if tiger_result:
                    result['tiger_order'] = {
                        'order_id': getattr(tiger_result, 'id', None),
                        'status': getattr(tiger_result, 'status', None)
                    }
                    result['success'] = True
                    logger.info(f"🔴 Tiger market order placed for {symbol}: {result['tiger_order']}")
                else:
                    result['message'] = "Tiger order returned None"
                    logger.warning(f"🔴 Tiger order returned None for {symbol}")
                    
            except Exception as e:
                logger.error(f"🔴 Error placing Tiger order for {symbol}: {str(e)}")
                result['message'] = str(e)
        else:
            tiger_exists = tiger is not None
            client_exists = getattr(tiger, 'client', None) is not None if tiger else False
            result['message'] = f"Tiger client not available (tiger={tiger_exists}, client={client_exists})"
            logger.warning(f"🔴 {result['message']}")
            
    except Exception as e:
        logger.error(f"Error in execute_trailing_stop_close: {str(e)}")
        result['message'] = str(e)
    
    return result


def log_trailing_stop_event(
    position: TrailingStopPosition,
    event_type: str,
    current_price: float = None,
    details: str = None
):
    try:
        log_entry = TrailingStopLog(
            trailing_stop_id=position.id,
            event_type=event_type,
            current_price=current_price,
            highest_price=position.highest_price,
            trailing_stop_price=position.current_trailing_stop,
            atr_value=position.current_atr,
            profit_pct=position.current_profit_pct,
            details=details
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        logger.error(f"Error logging trailing stop event: {str(e)}")


def process_trailing_stop_check(position: TrailingStopPosition, tiger_positions: Dict = None) -> Dict:
    from tiger_client import get_tiger_quote_client, TigerClient, TigerPaperClient
    
    result = {
        'success': False,
        'position_id': position.id,
        'symbol': position.symbol,
        'action': None,
        'message': ''
    }
    
    try:
        config = get_trailing_stop_config()
        
        if not config.is_enabled:
            result['message'] = "Trailing stop system is disabled"
            return result
        
        clean_symbol = position.symbol.replace('[PAPER]', '').strip()
        
        if tiger_positions:
            account_positions = tiger_positions.get(position.account_type, {})
            tiger_pos = account_positions.get(clean_symbol)
            
            if tiger_pos:
                new_avg_cost = tiger_pos.get('average_cost')
                new_quantity = tiger_pos.get('quantity')
                
                if new_avg_cost and new_avg_cost != position.entry_price:
                    logger.info(f"📊 Syncing avg cost for {position.symbol}: {position.entry_price:.2f} -> {new_avg_cost:.2f}")
                    position.entry_price = new_avg_cost
                
                if new_quantity and new_quantity != position.quantity:
                    logger.info(f"📊 Syncing quantity for {position.symbol}: {position.quantity} -> {new_quantity}")
                    position.quantity = new_quantity
        
        quote_client = get_tiger_quote_client()
        
        # 使用智能价格获取 - 盘前盘后时段使用timeline API
        trade_data = quote_client.get_smart_price(clean_symbol)
        if not trade_data:
            result['message'] = f"Could not get price for {position.symbol}"
            return result
        
        current_price = trade_data['price']
        price_session = trade_data.get('session', 'unknown')
        price_source = trade_data.get('source', 'unknown')
        
        if price_session in ['pre_market', 'post_market']:
            logger.debug(f"📊 {clean_symbol} 使用{price_session}价格: ${current_price:.2f} (source: {price_source})")
        
        tf_mapping = {
            '1': '1min',
            '5': '5min',
            '15': '15min',
            '30': '30min',
            '60': '1hour',
            '240': 'day',
            'D': 'day',
            'W': 'week'
        }
        timeframe_str = tf_mapping.get(position.timeframe or '15', '15min')
        
        bars = quote_client.get_bars(
            clean_symbol,
            timeframe=timeframe_str,
            limit=config.atr_period + 5
        )
        
        atr = calculate_atr(bars, config.atr_period) if bars else 0
        
        if atr == 0 or len(bars) < config.atr_period:
            logger.warning(f"Insufficient data for ATR calculation for {position.symbol}, skipping trailing stop update")
            result['message'] = "Insufficient data for ATR calculation"
            return result
        
        trend_data = calculate_trend_strength(
            bars, current_price, position.entry_price, 
            position.side, atr, config
        )
        position.trend_strength = trend_data['trend_strength']
        position.atr_convergence = trend_data['atr_convergence']
        position.momentum_score = trend_data['momentum_score']
        position.consecutive_highs = trend_data['consecutive_highs']
        
        logger.info(f"[{position.symbol}] 趋势强度: {trend_data['trend_strength']:.1f} "
                   f"(ATR收敛: {trend_data['atr_convergence']:.2f}, "
                   f"动量: {trend_data['momentum_score']:.2f}, "
                   f"连续创新高: {trend_data['consecutive_highs']})")
        
        should_switch, switch_reason = check_switch_condition(
            position, current_price, config, trend_data['trend_strength']
        )
        
        if should_switch:
            position.has_switched_to_trailing = True
            position.switch_triggered_at = datetime.utcnow()
            position.switch_reason = switch_reason
            
            # 取消止盈订单 - 即使order_id为空也尝试查询获取
            try:
                if position.account_type == 'paper':
                    tiger = TigerPaperClient()
                else:
                    tiger = TigerClient()
                
                # 查询实际的止盈订单ID（即使stored_order_id为空也尝试查询）
                actual_tp_order_id = get_actual_take_profit_order_id(
                    tiger, position.symbol, position.take_profit_order_id or ''
                )
                
                if actual_tp_order_id:
                    if actual_tp_order_id != position.take_profit_order_id:
                        logger.info(f"📋 {position.symbol} 发现止盈订单ID: {actual_tp_order_id}")
                        position.take_profit_order_id = actual_tp_order_id
                    
                    cancel_result = tiger.cancel_order(actual_tp_order_id)
                    if cancel_result.get('success'):
                        logger.info(f"✅ Cancelled take profit order {actual_tp_order_id} for {position.symbol}")
                        position.take_profit_order_id = None
                    else:
                        logger.warning(f"⚠️ Failed to cancel TP order {actual_tp_order_id}: {cancel_result.get('error')}")
                else:
                    logger.info(f"📋 {position.symbol} 没有找到止盈订单，可能已取消或不存在")
            except Exception as e:
                logger.error(f"Error cancelling take profit order: {str(e)}")
            
            # 发送外部webhook: 取消止盈后只保留止损
            # 使用当前止损价格(fixed_stop_loss)
            current_stop = position.fixed_stop_loss or position.current_trailing_stop
            if current_stop:
                webhook_result = send_switch_to_trailing_webhook(
                    symbol=position.symbol,
                    new_stop_price=current_stop
                )
                logger.info(f"📤 {position.symbol} 切换移动止损webhook: {webhook_result['message']}")
            
            log_trailing_stop_event(position, 'switch', current_price, switch_reason)
            
            from discord_notifier import send_trailing_stop_notification
            send_trailing_stop_notification(
                position.symbol,
                'switch',
                current_price,
                position.entry_price,
                position.current_profit_pct,
                switch_reason
            )
            
            result['action'] = 'switch'
            result['message'] = switch_reason
        
        # 阶梯止损调整 (未切换到动态trailing时执行)
        if not position.has_switched_to_trailing:
            prog_result = check_and_adjust_progressive_stop(position, current_price, config)
            
            if prog_result['should_adjust']:
                exec_result = execute_progressive_stop_adjustment(
                    position=position,
                    new_stop_price=prog_result['new_stop_price'],
                    new_tier=prog_result['new_tier'],
                    account_type=position.account_type
                )
                
                if exec_result['success']:
                    result['action'] = 'progressive_adjust'
                    result['message'] = prog_result['reason']
                    result['new_tier'] = prog_result['new_tier']
                else:
                    logger.error(f"阶梯止损调整失败: {exec_result.get('message')}")
        
        new_stop, calc_details = calculate_trailing_stop(position, current_price, atr, config)
        
        inverse_stop, inverse_details = calculate_inverse_protection_stop(
            position, current_price, trend_data['trend_strength'], config
        )
        
        if inverse_stop is not None and inverse_details.get('action') == 'tighten':
            is_long = position.side == 'long'
            if is_long:
                if inverse_stop > new_stop:
                    new_stop = inverse_stop
            else:
                if inverse_stop < new_stop:
                    new_stop = inverse_stop
            
            loss_pct = inverse_details['current_loss'] / position.entry_price * 100
            
            logger.info(f"🛡️ [{position.symbol}] 反向保护触发: 亏损{loss_pct:.2f}%, "
                       f"趋势强度{trend_data['trend_strength']:.0f}, "
                       f"止损从${position.fixed_stop_loss:.2f}收紧至${inverse_stop:.2f} "
                       f"(收紧系数{inverse_details['tightening_factor']})")
            
            if position.current_trailing_stop is None or \
               (is_long and inverse_stop > position.current_trailing_stop) or \
               (not is_long and inverse_stop < position.current_trailing_stop):
                
                # 通过Tiger API修改止损订单 - 即使order_id为空也尝试查询获取
                if position.account_type == 'paper':
                    tiger_client = TigerPaperClient()
                else:
                    tiger_client = TigerClient()
                
                side = 'sell' if position.side == 'long' else 'buy'
                clean_symbol = position.symbol.replace('[PAPER]', '').strip()
                
                # 查询实际的止损订单ID（即使stored_order_id为空也尝试查询）
                actual_stop_order_id = get_actual_stop_order_id(
                    tiger_client, position.symbol, position.stop_loss_order_id or ''
                )
                
                if actual_stop_order_id:
                    if actual_stop_order_id != position.stop_loss_order_id:
                        logger.info(f"📋 {position.symbol} 发现止损订单ID: {actual_stop_order_id}")
                        position.stop_loss_order_id = actual_stop_order_id
                    
                    modify_result = tiger_client.modify_stop_loss_price(
                        old_order_id=actual_stop_order_id,
                        symbol=clean_symbol,
                        quantity=position.quantity,
                        new_stop_price=inverse_stop,
                        side=side
                    )
                    
                    if modify_result['success']:
                        position.stop_loss_order_id = modify_result['new_order_id']
                        position.fixed_stop_loss = inverse_stop
                        logger.info(f"📈 [{position.account_type.upper()}] {position.symbol} 反向保护止损修改成功: ${inverse_stop:.2f}, 新订单ID={modify_result['new_order_id']}")
                    else:
                        logger.error(f"❌ {position.symbol} 反向保护止损修改失败: {modify_result.get('message', 'Unknown error')}")
                else:
                    logger.warning(f"⚠️ {position.symbol} 没有找到止损订单，无法修改反向保护止损")
                
                webhook_result = send_progressive_stop_webhook(
                    symbol=position.symbol,
                    new_stop_price=inverse_stop,
                    take_profit_price=position.fixed_take_profit
                )
                logger.info(f"📤 {position.symbol} 反向保护webhook: {webhook_result['message']}")
                
                log_trailing_stop_event(
                    position, 
                    'inverse_protection', 
                    current_price, 
                    f"反向保护: 止损收紧至${inverse_stop:.2f} (趋势{trend_data['trend_strength']:.0f})"
                )
                
                from discord_notifier import send_trailing_stop_notification
                send_trailing_stop_notification(
                    position.symbol,
                    'inverse_protection',
                    current_price,
                    position.entry_price,
                    position.current_profit_pct,
                    f"反向保护触发: 止损收紧至${inverse_stop:.2f}"
                )
                
                position.stop_adjustment_count = (position.stop_adjustment_count or 0) + 1
                position.last_stop_adjustment_price = current_price
        
        position.previous_trailing_stop = position.current_trailing_stop
        position.current_trailing_stop = new_stop
        position.last_check_at = datetime.utcnow()
        
        # 动态trailing阶段：如果止损价格有变化且已切换，更新Tiger止损订单
        # 即使stop_loss_order_id为空也尝试查询获取实际的订单ID
        if position.has_switched_to_trailing:
            prev_stop = position.previous_trailing_stop
            if prev_stop is None or \
               (position.side == 'long' and new_stop > prev_stop) or \
               (position.side == 'short' and new_stop < prev_stop):
                
                if position.account_type == 'paper':
                    tiger_client = TigerPaperClient()
                else:
                    tiger_client = TigerClient()
                
                side = 'sell' if position.side == 'long' else 'buy'
                clean_symbol = position.symbol.replace('[PAPER]', '').strip()
                
                # 查询实际的止损订单ID（即使stored_order_id为空也尝试查询）
                actual_stop_order_id = get_actual_stop_order_id(
                    tiger_client, position.symbol, position.stop_loss_order_id or ''
                )
                
                if not actual_stop_order_id:
                    logger.warning(f"⚠️ {position.symbol} 没有找到止损订单，无法修改动态trailing止损")
                else:
                    if actual_stop_order_id != position.stop_loss_order_id:
                        logger.info(f"📋 {position.symbol} 发现止损订单ID: {actual_stop_order_id}")
                        position.stop_loss_order_id = actual_stop_order_id
                    
                    modify_result = tiger_client.modify_stop_loss_price(
                        old_order_id=actual_stop_order_id,
                        symbol=clean_symbol,
                        quantity=position.quantity,
                        new_stop_price=new_stop,
                        side=side
                    )
                    
                    if modify_result['success']:
                        position.stop_loss_order_id = modify_result['new_order_id']
                        position.fixed_stop_loss = new_stop
                        prev_stop_str = f"${prev_stop:.2f}" if prev_stop else "N/A"
                        logger.info(f"📈 [{position.account_type.upper()}] {position.symbol} 动态trailing止损上移: {prev_stop_str} -> ${new_stop:.2f}, 新订单ID={modify_result['new_order_id']}")
                        
                        # 发送外部webhook (不带止盈，因为已切换到trailing)
                        webhook_result = send_switch_to_trailing_webhook(
                            symbol=position.symbol,
                            new_stop_price=new_stop
                        )
                        logger.info(f"📤 {position.symbol} 动态trailing webhook: {webhook_result['message']}")
                    else:
                        logger.error(f"❌ {position.symbol} 动态trailing止损修改失败: {modify_result.get('message', 'Unknown error')}")
        
        is_triggered, trigger_reason = check_stop_triggered(position, current_price)
        
        if is_triggered:
            position.is_triggered = True
            position.triggered_at = datetime.utcnow()
            position.triggered_price = current_price
            position.trigger_reason = trigger_reason
            position.is_active = False
            
            log_trailing_stop_event(position, 'trigger', current_price, trigger_reason)
            
            if position.account_type == 'paper':
                tiger = TigerPaperClient()
            else:
                tiger = TigerClient()
            
            # 取消止损订单 - 即使order_id为空也尝试查询获取
            try:
                actual_stop_order_id = get_actual_stop_order_id(
                    tiger, position.symbol, position.stop_loss_order_id or ''
                )
                if actual_stop_order_id:
                    tiger.cancel_order(actual_stop_order_id)
                    logger.info(f"✅ {position.symbol} 平仓时取消止损订单: {actual_stop_order_id}")
            except Exception as e:
                logger.warning(f"⚠️ {position.symbol} 取消止损订单失败: {str(e)}")
            
            # 取消止盈订单 - 即使order_id为空也尝试查询获取
            try:
                actual_tp_order_id = get_actual_take_profit_order_id(
                    tiger, position.symbol, position.take_profit_order_id or ''
                )
                if actual_tp_order_id:
                    tiger.cancel_order(actual_tp_order_id)
                    logger.info(f"✅ {position.symbol} 平仓时取消止盈订单: {actual_tp_order_id}")
            except Exception as e:
                logger.warning(f"⚠️ {position.symbol} 取消止盈订单失败: {str(e)}")
            
            close_side = 'SELL' if position.side == 'long' else 'BUY'
            clean_symbol = position.symbol.replace('[PAPER]', '').strip()
            
            close_order_result = execute_trailing_stop_close(
                tiger=tiger,
                symbol=clean_symbol,
                side=close_side,
                quantity=position.quantity,
                account_type=position.account_type,
                trigger_price=current_price,
                entry_price=position.entry_price,
                profit_pct=position.current_profit_pct,
                timeframe=position.timeframe or '15'
            )
            
            result['close_order'] = close_order_result
            
            from discord_notifier import send_trailing_stop_notification
            send_trailing_stop_notification(
                position.symbol,
                'trigger',
                current_price,
                position.entry_price,
                position.current_profit_pct,
                trigger_reason
            )
            
            result['action'] = 'trigger'
            result['message'] = trigger_reason
            result['close_side'] = close_side
            
            # Update CompletedTrade record
            try:
                completed_trade = CompletedTrade.query.filter_by(
                    trailing_stop_id=position.id,
                    is_open=True
                ).first()
                
                if not completed_trade:
                    # Try to find by symbol and account_type
                    completed_trade = CompletedTrade.query.filter_by(
                        symbol=position.symbol,
                        account_type=position.account_type,
                        is_open=True
                    ).order_by(CompletedTrade.created_at.desc()).first()
                
                if completed_trade:
                    # Determine exit method based on trigger_reason
                    if 'trailing' in trigger_reason.lower() or '动态' in trigger_reason:
                        completed_trade.exit_method = ExitMethod.TRAILING_STOP
                    elif '止损' in trigger_reason or 'stop' in trigger_reason.lower():
                        completed_trade.exit_method = ExitMethod.STOP_LOSS
                    elif '止盈' in trigger_reason or 'take profit' in trigger_reason.lower():
                        completed_trade.exit_method = ExitMethod.TAKE_PROFIT
                    else:
                        completed_trade.exit_method = ExitMethod.TRAILING_STOP
                    
                    completed_trade.exit_time = datetime.utcnow()
                    completed_trade.exit_price = current_price
                    completed_trade.exit_quantity = position.quantity
                    completed_trade.is_open = False
                    completed_trade.final_stop_loss = position.current_trailing_stop
                    completed_trade.highest_price = position.highest_price
                    completed_trade.lowest_price = position.lowest_price
                    completed_trade.stop_adjustment_count = position.stop_adjustment_count or 0
                    
                    # Calculate P&L
                    if completed_trade.entry_price:
                        if position.side == 'long':
                            completed_trade.pnl_amount = (current_price - completed_trade.entry_price) * completed_trade.entry_quantity
                            completed_trade.pnl_percent = ((current_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                            if position.highest_price:
                                completed_trade.max_profit_pct = ((position.highest_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                        else:  # short
                            completed_trade.pnl_amount = (completed_trade.entry_price - current_price) * completed_trade.entry_quantity
                            completed_trade.pnl_percent = ((completed_trade.entry_price - current_price) / completed_trade.entry_price) * 100
                            if position.lowest_price:
                                completed_trade.max_profit_pct = ((completed_trade.entry_price - position.lowest_price) / completed_trade.entry_price) * 100
                    
                    # Calculate hold duration
                    if completed_trade.entry_time:
                        hold_duration = datetime.utcnow() - completed_trade.entry_time
                        completed_trade.hold_duration_seconds = int(hold_duration.total_seconds())
                    
                    logger.info(f"📊 Updated CompletedTrade #{completed_trade.id} with {completed_trade.exit_method.value}, P&L: {completed_trade.pnl_percent:.2f}%")
                else:
                    logger.warning(f"📊 No open CompletedTrade found for {position.symbol}")
            except Exception as ct_error:
                logger.error(f"📊 Failed to update CompletedTrade on trigger: {str(ct_error)}")
        else:
            log_trailing_stop_event(position, 'check', current_price, f"Stop: ${new_stop:.2f}")
        
        db.session.commit()
        result['success'] = True
        
        result['current_price'] = current_price
        result['trailing_stop'] = new_stop
        result['profit_pct'] = position.current_profit_pct
        result['atr'] = atr
        
        return result
        
    except Exception as e:
        logger.error(f"Error processing trailing stop for {position.symbol}: {str(e)}")
        result['message'] = str(e)
        return result


def check_and_deactivate_closed_positions() -> List[Dict]:
    """
    检查Tiger API中的实际持仓，如果追踪列表中的仓位已不存在，自动停用追踪
    
    Returns:
        停用的仓位列表
    """
    from tiger_client import TigerClient, TigerPaperClient
    
    deactivated = []
    
    active_positions = TrailingStopPosition.query.filter_by(is_active=True).all()
    if not active_positions:
        return deactivated
    
    real_positions = [p for p in active_positions if p.account_type == 'real']
    paper_positions = [p for p in active_positions if p.account_type == 'paper']
    
    if real_positions:
        try:
            tiger = TigerClient()
            result = tiger.get_positions()
            if result.get('success'):
                real_symbols = {p['symbol'] for p in result.get('positions', [])}
                
                for pos in real_positions:
                    clean_symbol = pos.symbol.replace('[PAPER]', '').strip()
                    if clean_symbol not in real_symbols:
                        pos.is_active = False
                        pos.trigger_reason = "Position closed externally (not in Tiger positions)"
                        pos.triggered_at = datetime.utcnow()
                        deactivated.append({
                            'symbol': pos.symbol,
                            'account_type': 'real',
                            'reason': 'Position not found in Tiger API'
                        })
                        logger.info(f"🛑 Auto-deactivated {pos.symbol} (real): position closed externally")
        except Exception as e:
            logger.error(f"Error checking real positions: {e}")
    
    if paper_positions:
        try:
            tiger_paper = TigerPaperClient()
            result = tiger_paper.get_positions()
            if result.get('success'):
                paper_symbols = {p['symbol'] for p in result.get('positions', [])}
                
                for pos in paper_positions:
                    clean_symbol = pos.symbol.replace('[PAPER]', '').strip()
                    if clean_symbol not in paper_symbols:
                        pos.is_active = False
                        pos.trigger_reason = "Position closed externally (not in Tiger positions)"
                        pos.triggered_at = datetime.utcnow()
                        deactivated.append({
                            'symbol': pos.symbol,
                            'account_type': 'paper',
                            'reason': 'Position not found in Tiger API'
                        })
                        logger.info(f"🛑 Auto-deactivated {pos.symbol} (paper): position closed externally")
        except Exception as e:
            logger.error(f"Error checking paper positions: {e}")
    
    if deactivated:
        db.session.commit()
    
    return deactivated


_cached_positions = {'real': {}, 'paper': {}, 'timestamp': None}

def get_cached_tiger_positions(force_refresh=False) -> Dict:
    """
    获取Tiger持仓数据，带缓存（30秒有效期）避免频繁API调用
    """
    from tiger_client import TigerClient, TigerPaperClient
    import time
    
    global _cached_positions
    
    current_time = time.time()
    cache_valid = _cached_positions['timestamp'] and (current_time - _cached_positions['timestamp'] < 30)
    
    if cache_valid and not force_refresh:
        return _cached_positions
    
    try:
        tiger = TigerClient()
        result = tiger.get_positions()
        if result.get('success'):
            _cached_positions['real'] = {p['symbol']: p for p in result.get('positions', [])}
    except Exception as e:
        logger.warning(f"Failed to get real positions: {e}")
    
    try:
        tiger_paper = TigerPaperClient()
        result = tiger_paper.get_positions()
        if result.get('success'):
            _cached_positions['paper'] = {p['symbol']: p for p in result.get('positions', [])}
    except Exception as e:
        logger.warning(f"Failed to get paper positions: {e}")
    
    _cached_positions['timestamp'] = current_time
    return _cached_positions


def process_all_active_positions() -> List[Dict]:
    tiger_positions = get_cached_tiger_positions(force_refresh=True)
    
    deactivated = []
    active_positions = TrailingStopPosition.query.filter_by(is_active=True).all()
    
    for pos in active_positions:
        clean_symbol = pos.symbol.replace('[PAPER]', '').strip()
        account_positions = tiger_positions.get(pos.account_type, {})
        
        if clean_symbol not in account_positions:
            pos.is_active = False
            pos.trigger_reason = "Position closed externally (not in Tiger positions)"
            pos.triggered_at = datetime.utcnow()
            deactivated.append({
                'symbol': pos.symbol,
                'account_type': pos.account_type,
                'reason': 'Position not found in Tiger API',
                'entry_price': pos.entry_price,
                'side': pos.side
            })
            logger.info(f"🛑 Auto-deactivated {pos.symbol} ({pos.account_type}): position closed externally")
            
            # Update CompletedTrade record when position is closed externally
            try:
                from models import CompletedTrade, ExitMethod
                completed_trade = CompletedTrade.query.filter_by(
                    symbol=pos.symbol,
                    account_type=pos.account_type,
                    is_open=True
                ).order_by(CompletedTrade.created_at.desc()).first()
                
                if completed_trade:
                    # Get current price for exit estimation - 使用智能价格获取
                    try:
                        quote_client = get_tiger_quote_client()
                        quote_result = quote_client.get_smart_price(clean_symbol)
                        
                        if quote_result:
                            exit_price = quote_result.get('price', pos.current_price or pos.entry_price)
                        else:
                            exit_price = pos.current_price or pos.entry_price
                    except Exception:
                        exit_price = pos.current_price or pos.entry_price
                    
                    completed_trade.exit_method = ExitMethod.EXTERNAL
                    completed_trade.exit_time = datetime.utcnow()
                    completed_trade.exit_price = exit_price
                    completed_trade.exit_quantity = pos.quantity
                    completed_trade.is_open = False
                    
                    if completed_trade.entry_price and exit_price:
                        if completed_trade.side == 'long':
                            completed_trade.pnl_percent = ((exit_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                            completed_trade.pnl_amount = (exit_price - completed_trade.entry_price) * completed_trade.entry_quantity
                        else:
                            completed_trade.pnl_percent = ((completed_trade.entry_price - exit_price) / completed_trade.entry_price) * 100
                            completed_trade.pnl_amount = (completed_trade.entry_price - exit_price) * completed_trade.entry_quantity
                    
                    logger.info(f"📊 Updated CompletedTrade #{completed_trade.id} with external exit, P&L: {completed_trade.pnl_percent:.2f}%")
                else:
                    logger.warning(f"📊 No open CompletedTrade found for {pos.symbol}")
            except Exception as ct_error:
                logger.error(f"📊 Failed to update CompletedTrade on external exit: {str(ct_error)}")
    
    if deactivated:
        db.session.commit()
    
    results = []
    
    active_positions = TrailingStopPosition.query.filter_by(is_active=True).all()
    
    for position in active_positions:
        result = process_trailing_stop_check(position, tiger_positions)
        results.append(result)
    
    for d in deactivated:
        results.append({
            'symbol': d['symbol'],
            'action': 'deactivate',
            'message': d['reason']
        })
    
    return results


def create_trailing_stop_for_trade(
    trade_id: int,
    symbol: str,
    side: str,
    entry_price: float,
    quantity: float,
    account_type: str = 'real',
    fixed_stop_loss: float = None,
    fixed_take_profit: float = None,
    stop_loss_order_id: str = None,
    take_profit_order_id: str = None,
    mode: TrailingStopMode = TrailingStopMode.BALANCED,
    timeframe: str = '15'
) -> TrailingStopPosition:
    
    existing = TrailingStopPosition.query.filter_by(
        symbol=symbol,
        account_type=account_type,
        is_active=True
    ).first()
    
    if existing:
        existing.entry_price = entry_price
        existing.quantity = quantity
        existing.fixed_stop_loss = fixed_stop_loss
        existing.fixed_take_profit = fixed_take_profit
        existing.stop_loss_order_id = stop_loss_order_id
        existing.take_profit_order_id = take_profit_order_id
        existing.timeframe = timeframe
        db.session.commit()
        logger.info(f"Updated existing trailing stop for {symbol}")
        return existing
    
    position = TrailingStopPosition(
        symbol=symbol,
        account_type=account_type,
        side=side,
        entry_price=entry_price,
        first_entry_price=entry_price,  # Preserve first entry price (never updated on scaling)
        quantity=quantity,
        trade_id=trade_id,
        fixed_stop_loss=fixed_stop_loss,
        fixed_take_profit=fixed_take_profit,
        stop_loss_order_id=stop_loss_order_id,
        take_profit_order_id=take_profit_order_id,
        mode=mode,
        timeframe=timeframe,
        highest_price=entry_price if side == 'long' else None,
        lowest_price=entry_price if side == 'short' else None,
        current_trailing_stop=fixed_stop_loss,  # Initialize with fixed stop loss for Tier 0
        profit_tier=0,  # Start at Tier 0
        is_active=True
    )
    
    db.session.add(position)
    db.session.commit()
    
    logger.info(f"Created trailing stop for {symbol}: entry={entry_price}, SL={fixed_stop_loss}, TP={fixed_take_profit}")
    
    return position


def update_trailing_stop_on_position_increase(
    symbol: str,
    account_type: str,
    new_quantity: float,
    new_entry_price: float,
    new_stop_loss_price: float,
    new_take_profit_price: float = None,
    new_stop_loss_order_id: str = None,
    new_take_profit_order_id: str = None
) -> Dict:
    """
    Update TrailingStopPosition when position is increased (加仓).
    
    Key behaviors:
    - Updates quantity and entry_price (from Tiger's average cost)
    - Updates stop_loss_order_id (new order created after canceling old one)
    - If already switched to dynamic trailing: only update stop loss, no take profit
    - If still in progressive phase: update both stop loss and take profit
    - Preserves: highest_price, profit_tier, has_switched_to_trailing, current_trailing_stop
    
    Args:
        symbol: Stock symbol
        account_type: 'real' or 'paper'
        new_quantity: Total position quantity after increase
        new_entry_price: New average entry price (from Tiger API)
        new_stop_loss_price: New stop loss price from latest signal
        new_take_profit_price: New take profit price from latest signal
        new_stop_loss_order_id: New stop loss order ID from Tiger
        new_take_profit_order_id: New take profit order ID from Tiger
        
    Returns:
        dict with success status and message
    """
    result = {'success': False, 'message': '', 'updated': False}
    
    try:
        position = TrailingStopPosition.query.filter_by(
            symbol=symbol,
            account_type=account_type,
            is_active=True
        ).first()
        
        if not position:
            result['message'] = f"No active trailing stop found for {symbol}"
            logger.warning(f"📊 加仓更新: {result['message']}")
            return result
        
        old_quantity = position.quantity
        old_entry = position.entry_price
        old_stop = position.fixed_stop_loss
        has_switched = position.has_switched_to_trailing
        
        # Ensure quantity is always positive
        position.quantity = abs(new_quantity) if new_quantity else position.quantity
        position.entry_price = new_entry_price
        
        # Update stop loss order ID (always update since old order was cancelled)
        if new_stop_loss_order_id:
            position.stop_loss_order_id = new_stop_loss_order_id
        
        # Stop loss price: only tighten (for long: only move up, for short: only move down)
        # Exception: new signal may have higher stop for long if entry is higher
        # Format helper for safe logging
        def fmt_price(p):
            return f"${p:.2f}" if p else "N/A"
        
        if position.side == 'long':
            # For long positions, higher stop is tighter (better)
            if new_stop_loss_price and (not old_stop or new_stop_loss_price > old_stop):
                position.fixed_stop_loss = new_stop_loss_price
                logger.info(f"📊 加仓更新 {symbol}: 止损收紧 {fmt_price(old_stop)}->{fmt_price(new_stop_loss_price)}")
            elif new_stop_loss_price and old_stop:
                # Keep old stop if new is lower (looser) - but still update order ID
                logger.info(f"📊 加仓更新 {symbol}: 保持原止损 {fmt_price(old_stop)} (新信号止损{fmt_price(new_stop_loss_price)}更低)")
        else:
            # For short positions, lower stop is tighter (better)
            if new_stop_loss_price and (not old_stop or new_stop_loss_price < old_stop):
                position.fixed_stop_loss = new_stop_loss_price
                logger.info(f"📊 加仓更新 {symbol}: 止损收紧 {fmt_price(old_stop)}->{fmt_price(new_stop_loss_price)}")
            elif new_stop_loss_price and old_stop:
                logger.info(f"📊 加仓更新 {symbol}: 保持原止损 {fmt_price(old_stop)} (新信号止损{fmt_price(new_stop_loss_price)}更高)")
        
        # Update take profit only if NOT switched to dynamic trailing
        if not has_switched:
            if new_take_profit_price:
                position.fixed_take_profit = new_take_profit_price
            if new_take_profit_order_id:
                position.take_profit_order_id = new_take_profit_order_id
            if new_take_profit_price:
                logger.info(f"📊 加仓更新 {symbol}: 更新止盈 TP=${new_take_profit_price:.2f} (阶梯止损阶段)")
        else:
            # Already switched - don't update take profit
            logger.info(f"📊 加仓更新 {symbol}: 已切换到动态trailing，不更新止盈，仅更新止损")
        
        # PRESERVE: profit_tier, current_trailing_stop, highest_price, lowest_price
        # Do NOT reset these values - preserve current tracking state
        
        # Also update CompletedTrade's entry_price to reflect new avg cost
        # This ensures P&L calculation is accurate when position is closed
        try:
            completed_trade = CompletedTrade.query.filter_by(
                trailing_stop_id=position.id,
                is_open=True
            ).first()
            
            if completed_trade and new_entry_price:
                old_ct_entry = completed_trade.entry_price
                completed_trade.entry_price = new_entry_price
                completed_trade.entry_quantity = abs(new_quantity) if new_quantity else completed_trade.entry_quantity
                logger.info(f"📊 加仓更新 CompletedTrade #{completed_trade.id}: entry_price ${old_ct_entry:.2f} -> ${new_entry_price:.2f}")
        except Exception as ct_err:
            logger.warning(f"📊 加仓更新 CompletedTrade失败: {str(ct_err)}")
        
        db.session.commit()
        
        result['success'] = True
        result['updated'] = True
        entry_str = f"${old_entry:.2f}" if old_entry else "N/A"
        new_entry_str = f"${new_entry_price:.2f}" if new_entry_price else "N/A"
        result['message'] = f"加仓更新成功: qty {old_quantity}->{new_quantity}, entry {entry_str}->{new_entry_str}"
        
        logger.info(f"✅ 加仓更新 {symbol} ({account_type}): {result['message']}")
        logger.info(f"   新止损: {fmt_price(new_stop_loss_price)}, 止损订单ID: {new_stop_loss_order_id}")
        if not has_switched and new_take_profit_price:
            logger.info(f"   新止盈: {fmt_price(new_take_profit_price)}, 止盈订单ID: {new_take_profit_order_id}")
        
        return result
        
    except Exception as e:
        logger.error(f"❌ 加仓更新trailing stop异常 {symbol}: {str(e)}")
        result['message'] = str(e)
        return result


def calculate_optimal_stop_after_scaling(
    symbol: str,
    account_type: str,
    current_price: float,
    tiger_client
) -> Dict:
    """
    加仓后立即计算最优止损价格并更新止损订单
    
    双入场价逻辑:
    1. 计算基于平均入场价的盈利% (profit_pct_avg)
    2. 计算基于首笔入场价的盈利% (profit_pct_first)
    3. 用两个盈利%确定各自的tier，取更高的tier
    4. 如果基于首笔入场价的盈利≥5%，自动切换到动态trailing
    5. 止损价格始终基于平均入场价计算（这是真正的成本）
    
    Returns:
        dict with 'success', 'message', 'stop_updated', 'new_stop_price', 'switched_to_trailing'
    """
    result = {
        'success': False,
        'message': '',
        'stop_updated': False,
        'new_stop_price': None,
        'old_stop_price': None,
        'profit_pct': 0,
        'profit_pct_first': 0,
        'tier': 0,
        'switched_to_trailing': False
    }
    
    try:
        position = TrailingStopPosition.query.filter_by(
            symbol=symbol,
            account_type=account_type,
            is_active=True
        ).first()
        
        if not position:
            result['message'] = f"No active trailing stop found for {symbol}"
            return result
        
        if not position.entry_price or position.entry_price <= 0:
            result['message'] = "Invalid entry price"
            return result
        
        if not current_price or current_price <= 0:
            result['message'] = "Invalid current price"
            return result
        
        # Get config (no parameter needed)
        config = get_trailing_stop_config()
        
        is_long = position.side == 'long'
        
        # Calculate profit based on AVERAGE entry price (current cost)
        if is_long:
            profit_pct_avg = (current_price - position.entry_price) / position.entry_price
        else:
            profit_pct_avg = (position.entry_price - current_price) / position.entry_price
        
        result['profit_pct'] = profit_pct_avg * 100
        
        # Calculate profit based on FIRST entry price (original position)
        first_entry = position.first_entry_price or position.entry_price
        if is_long:
            profit_pct_first = (current_price - first_entry) / first_entry
        else:
            profit_pct_first = (first_entry - current_price) / first_entry
        
        result['profit_pct_first'] = profit_pct_first * 100
        
        # Determine tier based on both entry prices, take the HIGHER tier
        tier_from_avg = get_progressive_stop_tier(profit_pct_avg, config)
        tier_from_first = get_progressive_stop_tier(profit_pct_first, config)
        target_tier = max(tier_from_avg, tier_from_first)
        result['tier'] = target_tier
        
        logger.info(f"📊 加仓止损优化 {symbol}: 平均入场${position.entry_price:.2f}盈利{profit_pct_avg*100:.2f}%(tier{tier_from_avg}), "
                   f"首笔入场${first_entry:.2f}盈利{profit_pct_first*100:.2f}%(tier{tier_from_first}) -> 取tier{target_tier}")
        
        # Check if we should switch to dynamic trailing based on first entry profit
        # Condition: first entry profit >= 5% and not already switched
        EARLY_SWITCH_THRESHOLD = 0.05  # 5%
        if profit_pct_first >= EARLY_SWITCH_THRESHOLD and not position.has_switched_to_trailing:
            logger.info(f"🚀 {symbol} 首笔入场盈利{profit_pct_first*100:.2f}% >= 5%, 提前切换到动态trailing!")
            position.has_switched_to_trailing = True
            position.switch_triggered_at = datetime.utcnow()
            position.switch_reason = f"Early switch: first entry profit {profit_pct_first*100:.1f}% >= 5%"
            result['switched_to_trailing'] = True
            
            # Cancel take profit order since we're switching to trailing
            if position.take_profit_order_id and tiger_client:
                try:
                    cancel_result = tiger_client.cancel_order(position.take_profit_order_id)
                    if cancel_result.get('success'):
                        logger.info(f"📝 取消止盈订单 {position.take_profit_order_id}")
                        position.take_profit_order_id = None
                except Exception as e:
                    logger.warning(f"取消止盈订单失败: {e}")
        
        if target_tier <= 0:
            result['success'] = True
            result['message'] = f"盈利{profit_pct_avg*100:.2f}%/首笔{profit_pct_first*100:.2f}%未达tier1阈值，无需调整止损"
            db.session.commit()  # Commit any switch changes
            return result
        
        # Calculate the stop price for this tier (ALWAYS based on average entry price - this is true cost)
        tier_stop_price = calculate_progressive_stop_price(position, target_tier, config)
        
        if not tier_stop_price:
            result['message'] = "Failed to calculate tier stop price"
            return result
        
        # Get current stop price
        current_stop = position.fixed_stop_loss or position.current_trailing_stop
        result['old_stop_price'] = current_stop
        
        # Compare: for long, higher stop is tighter; for short, lower stop is tighter
        should_update = False
        if is_long:
            if not current_stop or tier_stop_price > current_stop:
                should_update = True
        else:
            if not current_stop or tier_stop_price < current_stop:
                should_update = True
        
        if not should_update:
            result['success'] = True
            current_stop_str = f"${current_stop:.2f}" if current_stop else "N/A"
            result['message'] = f"当前止损{current_stop_str}已经优于tier{target_tier}止损${tier_stop_price:.2f}，无需更新"
            db.session.commit()  # Commit any switch changes
            return result
        
        # Need to update the stop loss order immediately
        result['new_stop_price'] = tier_stop_price
        
        # First, query current open orders for this symbol to find the actual stop order
        # (加仓后会产生新的止损订单，order_id已经变了)
        if tiger_client:
            logger.info(f"🔄 加仓后立即优化止损 {symbol}: 当前价${current_price:.2f}, tier{target_tier} (基于更高盈利)")
            old_stop_str = f"${current_stop:.2f}" if current_stop else "$0"
            logger.info(f"   止损调整: {old_stop_str} -> ${tier_stop_price:.2f}")
            
            # Query current open orders to find the actual stop order
            open_orders_result = tiger_client.get_open_orders_for_symbol(symbol)
            actual_stop_order_id = None
            
            if open_orders_result.get('success'):
                for order in open_orders_result.get('orders', []):
                    order_type = getattr(order, 'order_type', '')
                    order_type_str = str(order_type).upper()
                    # Stop orders have type 'STP' or 'STOP' or similar
                    if 'STP' in order_type_str or 'STOP' in order_type_str:
                        actual_stop_order_id = order.id
                        logger.info(f"📋 找到当前止损订单: {actual_stop_order_id} (type={order_type})")
                        break
            
            if not actual_stop_order_id:
                # Fallback to the stored order_id
                actual_stop_order_id = position.stop_loss_order_id
                logger.info(f"📋 使用存储的止损订单ID: {actual_stop_order_id}")
            
            if not actual_stop_order_id:
                # No stop order found, create new one
                logger.info(f"📋 未找到止损订单，创建新订单")
                stop_result = tiger_client.create_stop_order(
                    symbol=symbol,
                    quantity=abs(position.quantity),
                    stop_price=tier_stop_price,
                    side='sell' if is_long else 'buy'
                )
                
                if stop_result.get('success'):
                    position.stop_loss_order_id = stop_result.get('order_id')
                    position.fixed_stop_loss = tier_stop_price
                    position.current_trailing_stop = tier_stop_price
                    position.profit_tier = target_tier
                    db.session.commit()
                    
                    result['success'] = True
                    result['stop_updated'] = True
                    result['message'] = f"✅ 创建新止损订单成功: tier{target_tier}, 止损${tier_stop_price:.2f}"
                    logger.info(result['message'])
                else:
                    result['message'] = f"Failed to create stop order: {stop_result.get('error')}"
                    logger.error(result['message'])
                return result
            
            # Update stored order_id if different
            if actual_stop_order_id != position.stop_loss_order_id:
                logger.info(f"📝 更新止损订单ID: {position.stop_loss_order_id} -> {actual_stop_order_id}")
                position.stop_loss_order_id = actual_stop_order_id
            
            # Try modify_order first
            modify_result = tiger_client.modify_order(
                order_id=actual_stop_order_id,
                stop_price=tier_stop_price
            )
            
            if modify_result.get('success'):
                # Update position record
                position.fixed_stop_loss = tier_stop_price
                position.current_trailing_stop = tier_stop_price
                position.profit_tier = target_tier
                db.session.commit()
                
                result['success'] = True
                result['stop_updated'] = True
                result['message'] = f"✅ 加仓后立即优化止损成功: tier{target_tier}, 止损${tier_stop_price:.2f} (盈利{profit_pct_avg*100:.2f}%)"
                logger.info(result['message'])
                
                # Log event
                log_trailing_stop_event(
                    symbol=symbol,
                    account_type=account_type,
                    event_type='scaling_stop_optimization',
                    details={
                        'profit_pct': profit_pct_avg * 100,
                        'tier': target_tier,
                        'old_stop': current_stop,
                        'new_stop': tier_stop_price,
                        'current_price': current_price,
                        'entry_price': position.entry_price
                    }
                )
            else:
                # modify_order failed, try cancel and recreate
                logger.warning(f"modify_order failed: {modify_result.get('error')}, trying cancel+recreate")
                
                # Cancel the actual stop order (use actual_stop_order_id, not stored order_id)
                cancel_result = tiger_client.cancel_order(actual_stop_order_id)
                if cancel_result.get('success'):
                    import time
                    time.sleep(0.3)
                    
                    # Create new stop order
                    stop_result = tiger_client.create_stop_order(
                        symbol=symbol,
                        quantity=abs(position.quantity),
                        stop_price=tier_stop_price,
                        side='sell' if is_long else 'buy'
                    )
                    
                    if stop_result.get('success'):
                        position.stop_loss_order_id = stop_result.get('order_id')
                        position.fixed_stop_loss = tier_stop_price
                        position.current_trailing_stop = tier_stop_price
                        position.profit_tier = target_tier
                        db.session.commit()
                        
                        result['success'] = True
                        result['stop_updated'] = True
                        result['message'] = f"✅ 加仓后止损优化成功(重建订单): tier{target_tier}, 止损${tier_stop_price:.2f}"
                        logger.info(result['message'])
                    else:
                        result['message'] = f"Failed to create new stop order: {stop_result.get('error')}"
                        logger.error(result['message'])
                else:
                    result['message'] = f"Failed to cancel old order: {cancel_result.get('error')}"
                    logger.error(result['message'])
        else:
            # Just update the database record, no order to modify
            position.fixed_stop_loss = tier_stop_price
            position.current_trailing_stop = tier_stop_price
            position.profit_tier = target_tier
            db.session.commit()
            
            result['success'] = True
            result['stop_updated'] = True
            result['message'] = f"Updated stop in database (no order ID to modify): ${tier_stop_price:.2f}"
        
        return result
        
    except Exception as e:
        logger.error(f"❌ calculate_optimal_stop_after_scaling异常 {symbol}: {str(e)}")
        result['message'] = str(e)
        return result


def _update_completed_trade_on_exit(position: TrailingStopPosition, exit_method: ExitMethod, exit_price: float):
    """
    Helper function to update CompletedTrade when a position is closed via stop loss or take profit.
    """
    completed_trade = CompletedTrade.query.filter_by(
        trailing_stop_id=position.id,
        is_open=True
    ).first()
    
    if not completed_trade:
        # Try to find by symbol and account_type
        completed_trade = CompletedTrade.query.filter_by(
            symbol=position.symbol,
            account_type=position.account_type,
            is_open=True
        ).order_by(CompletedTrade.created_at.desc()).first()
    
    if completed_trade:
        completed_trade.exit_method = exit_method
        completed_trade.exit_time = datetime.utcnow()
        completed_trade.exit_price = exit_price
        completed_trade.exit_quantity = position.quantity
        completed_trade.is_open = False
        completed_trade.final_stop_loss = position.current_trailing_stop
        completed_trade.highest_price = position.highest_price
        completed_trade.lowest_price = position.lowest_price
        completed_trade.stop_adjustment_count = position.stop_adjustment_count or 0
        
        # Calculate P&L
        if completed_trade.entry_price and exit_price:
            if position.side == 'long':
                completed_trade.pnl_amount = (exit_price - completed_trade.entry_price) * completed_trade.entry_quantity
                completed_trade.pnl_percent = ((exit_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
                if position.highest_price:
                    completed_trade.max_profit_pct = ((position.highest_price - completed_trade.entry_price) / completed_trade.entry_price) * 100
            else:  # short
                completed_trade.pnl_amount = (completed_trade.entry_price - exit_price) * completed_trade.entry_quantity
                completed_trade.pnl_percent = ((completed_trade.entry_price - exit_price) / completed_trade.entry_price) * 100
                if position.lowest_price:
                    completed_trade.max_profit_pct = ((completed_trade.entry_price - position.lowest_price) / completed_trade.entry_price) * 100
        
        # Calculate hold duration
        if completed_trade.entry_time:
            hold_duration = datetime.utcnow() - completed_trade.entry_time
            completed_trade.hold_duration_seconds = int(hold_duration.total_seconds())
        
        logger.info(f"📊 Updated CompletedTrade #{completed_trade.id} with {exit_method.value}, P&L: {completed_trade.pnl_percent:.2f}%")
    else:
        logger.warning(f"📊 No open CompletedTrade found for {position.symbol}")


def deactivate_trailing_stop(symbol: str, account_type: str = 'real', reason: str = None):
    position = TrailingStopPosition.query.filter_by(
        symbol=symbol,
        account_type=account_type,
        is_active=True
    ).first()
    
    if position:
        position.is_active = False
        position.trigger_reason = reason or "Manually deactivated"
        db.session.commit()
        logger.info(f"Deactivated trailing stop for {symbol}: {reason}")
        return True
    
    return False


def sync_position_with_tiger(position: TrailingStopPosition, tiger_client) -> Dict:
    """
    Synchronize a single TrailingStopPosition with Tiger API order status.
    
    Checks if local order IDs are still valid in Tiger and updates status accordingly.
    
    Returns:
        Dict with sync results and any fixes applied
    """
    from datetime import datetime
    
    result = {
        'symbol': position.symbol,
        'account_type': position.account_type,
        'checks_performed': [],
        'issues_found': [],
        'fixes_applied': []
    }
    
    if not tiger_client:
        result['error'] = 'Tiger client not available'
        return result
    
    # Check stop loss order status - 即使order_id为空也尝试查询获取
    result['checks_performed'].append('stop_loss_order')
    try:
        # 查询实际的止损订单ID
        actual_stop_order_id = get_actual_stop_order_id(
            tiger_client, position.symbol, position.stop_loss_order_id or ''
        )
        
        if actual_stop_order_id:
            if actual_stop_order_id != position.stop_loss_order_id:
                result['issues_found'].append(f'Stop loss order ID updated: {position.stop_loss_order_id} -> {actual_stop_order_id}')
                position.stop_loss_order_id = actual_stop_order_id
                result['fixes_applied'].append('Updated stop_loss_order_id from Tiger API')
            
            order_status = tiger_client.get_order_status(actual_stop_order_id)
            if order_status.get('success'):
                status = order_status.get('status', '')
                
                if status == 'filled':
                    # Stop loss was triggered - position should be closed
                    result['issues_found'].append(f'Stop loss order {actual_stop_order_id} was filled but position still active')
                    position.is_active = False
                    position.is_triggered = True
                    position.triggered_at = datetime.utcnow()
                    position.trigger_reason = "止损订单已成交 (同步检测)"
                    result['fixes_applied'].append('Deactivated position - stop loss filled')
                    
                    # Update CompletedTrade
                    try:
                        _update_completed_trade_on_exit(
                            position, 
                            ExitMethod.STOP_LOSS, 
                            order_status.get('filled_price') or position.fixed_stop_loss
                        )
                    except Exception as ct_e:
                        logger.error(f"Failed to update CompletedTrade on stop loss: {ct_e}")
                    
                elif status == 'cancelled':
                    # Stop loss was cancelled - might be an issue
                    result['issues_found'].append(f'Stop loss order {actual_stop_order_id} was cancelled')
                    position.stop_loss_order_id = None
                    result['fixes_applied'].append('Cleared invalid stop_loss_order_id')
                    
                elif status == 'rejected':
                    result['issues_found'].append(f'Stop loss order {actual_stop_order_id} was rejected')
                    position.stop_loss_order_id = None
                    result['fixes_applied'].append('Cleared rejected stop_loss_order_id')
                    
            else:
                # Order not found - might be expired or invalid
                error = order_status.get('error', 'Unknown error')
                if 'not found' in error.lower() or 'invalid' in error.lower():
                    result['issues_found'].append(f'Stop loss order {actual_stop_order_id} not found in Tiger')
                    position.stop_loss_order_id = None
                    result['fixes_applied'].append('Cleared missing stop_loss_order_id')
        else:
            if position.stop_loss_order_id:
                result['issues_found'].append(f'Stored stop_loss_order_id {position.stop_loss_order_id} but no order found in Tiger')
                position.stop_loss_order_id = None
                result['fixes_applied'].append('Cleared orphaned stop_loss_order_id')
                    
    except Exception as e:
        result['checks_performed'].append(f'stop_loss_check_error: {str(e)}')
    
    # Check take profit order status - 即使order_id为空也尝试查询获取
    result['checks_performed'].append('take_profit_order')
    try:
        # 查询实际的止盈订单ID
        actual_tp_order_id = get_actual_take_profit_order_id(
            tiger_client, position.symbol, position.take_profit_order_id or ''
        )
        
        if actual_tp_order_id:
            if actual_tp_order_id != position.take_profit_order_id:
                result['issues_found'].append(f'Take profit order ID updated: {position.take_profit_order_id} -> {actual_tp_order_id}')
                position.take_profit_order_id = actual_tp_order_id
                result['fixes_applied'].append('Updated take_profit_order_id from Tiger API')
            
            order_status = tiger_client.get_order_status(actual_tp_order_id)
            if order_status.get('success'):
                status = order_status.get('status', '')
                
                if status == 'filled':
                    # Take profit was triggered - position should be closed
                    result['issues_found'].append(f'Take profit order {actual_tp_order_id} was filled but position still active')
                    position.is_active = False
                    position.triggered_at = datetime.utcnow()
                    position.trigger_reason = "止盈订单已成交 (同步检测)"
                    result['fixes_applied'].append('Deactivated position - take profit filled')
                    
                    # Update CompletedTrade
                    try:
                        _update_completed_trade_on_exit(
                            position, 
                            ExitMethod.TAKE_PROFIT, 
                            order_status.get('filled_price') or position.fixed_take_profit
                        )
                    except Exception as ct_e:
                        logger.error(f"Failed to update CompletedTrade on take profit: {ct_e}")
                    
                elif status == 'cancelled':
                    result['issues_found'].append(f'Take profit order {actual_tp_order_id} was cancelled')
                    position.take_profit_order_id = None
                    result['fixes_applied'].append('Cleared cancelled take_profit_order_id')
                    
                elif status == 'rejected':
                    result['issues_found'].append(f'Take profit order {actual_tp_order_id} was rejected')
                    position.take_profit_order_id = None
                    result['fixes_applied'].append('Cleared rejected take_profit_order_id')
                    
            else:
                error = order_status.get('error', 'Unknown error')
                if 'not found' in error.lower() or 'invalid' in error.lower():
                    result['issues_found'].append(f'Take profit order {actual_tp_order_id} not found in Tiger')
                    position.take_profit_order_id = None
                    result['fixes_applied'].append('Cleared missing take_profit_order_id')
        else:
            if position.take_profit_order_id:
                result['issues_found'].append(f'Stored take_profit_order_id {position.take_profit_order_id} but no order found in Tiger')
                position.take_profit_order_id = None
                result['fixes_applied'].append('Cleared orphaned take_profit_order_id')
                    
    except Exception as e:
        result['checks_performed'].append(f'take_profit_check_error: {str(e)}')
    
    # Commit changes if any fixes were applied
    if result['fixes_applied']:
        db.session.commit()
        logger.info(f"🔄 Sync fixes for {position.symbol}: {result['fixes_applied']}")
    
    return result


def sync_all_active_positions(tiger_client) -> List[Dict]:
    """
    Synchronize all active TrailingStopPositions with Tiger API.
    
    This should be called periodically to detect and fix data inconsistencies.
    
    Returns:
        List of sync results for each position
    """
    results = []
    
    active_positions = TrailingStopPosition.query.filter_by(is_active=True).all()
    
    logger.info(f"🔄 Starting sync check for {len(active_positions)} active positions")
    
    for position in active_positions:
        try:
            result = sync_position_with_tiger(position, tiger_client)
            results.append(result)
            
            if result.get('issues_found'):
                logger.warning(f"⚠️ Issues found for {position.symbol}: {result['issues_found']}")
                
        except Exception as e:
            logger.error(f"Error syncing position {position.symbol}: {str(e)}")
            results.append({
                'symbol': position.symbol,
                'account_type': position.account_type,
                'error': str(e)
            })
    
    # Summary
    total_issues = sum(len(r.get('issues_found', [])) for r in results)
    total_fixes = sum(len(r.get('fixes_applied', [])) for r in results)
    
    logger.info(f"🔄 Sync complete: {len(results)} positions checked, {total_issues} issues found, {total_fixes} fixes applied")
    
    return results
