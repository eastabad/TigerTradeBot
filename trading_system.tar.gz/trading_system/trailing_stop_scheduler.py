import threading
import time
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

_scheduler_thread = None
_scheduler_running = False
_last_check_time = None


def is_market_hours():
    """Check if current time is within US market hours (9:30 AM - 4:00 PM ET)"""
    import pytz
    
    try:
        et = pytz.timezone('US/Eastern')
        now = datetime.now(et)
        
        if now.weekday() >= 5:
            return False
        
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        extended_open = now.replace(hour=4, minute=0, second=0, microsecond=0)
        extended_close = now.replace(hour=20, minute=0, second=0, microsecond=0)
        
        return extended_open <= now <= extended_close
    except:
        return True


def check_pending_orders_and_create_trailing_stops(app):
    """Check PENDING orders, if filled create trailing stop positions"""
    try:
        with app.app_context():
            from app import db
            from models import Trade, OrderStatus, TrailingStopPosition, TrailingStopMode
            from tiger_client import TigerClient, TigerPaperClient
            from trailing_stop_engine import create_trailing_stop_for_trade, get_trailing_stop_config
            from datetime import datetime, timedelta
            
            ts_config = get_trailing_stop_config()
            if not ts_config.is_enabled:
                return
            
            cutoff_time = datetime.utcnow() - timedelta(hours=24)
            pending_trades = Trade.query.filter(
                Trade.status == OrderStatus.PENDING,
                Trade.created_at >= cutoff_time
            ).all()
            
            if not pending_trades:
                return
            
            logger.debug(f"Checking {len(pending_trades)} pending orders for fill status")
            
            for trade in pending_trades:
                try:
                    if not trade.tiger_order_id:
                        continue
                    
                    if trade.account_type == 'paper':
                        tiger_client = TigerPaperClient()
                    else:
                        tiger_client = TigerClient()
                    
                    status_result = tiger_client.get_order_status(trade.tiger_order_id)
                    
                    if not status_result.get('success'):
                        continue
                    
                    tiger_status = status_result.get('status')
                    
                    if tiger_status == 'filled':
                        trade.status = OrderStatus.FILLED
                        filled_price = status_result.get('filled_price', 0)
                        filled_qty = status_result.get('filled_quantity', trade.quantity)
                        
                        if filled_price:
                            trade.filled_price = filled_price
                        if filled_qty:
                            trade.filled_quantity = filled_qty
                        
                        logger.info(f"📦 Order {trade.tiger_order_id} ({trade.symbol}) filled at ${filled_price:.2f}")
                        
                        existing_ts = TrailingStopPosition.query.filter_by(
                            trade_id=trade.id,
                            is_active=True
                        ).first()
                        
                        if not existing_ts and not getattr(trade, 'is_close_position', False):
                            ts_side = 'long' if trade.side.value == 'buy' else 'short'
                            entry_price = filled_price or trade.reference_price or trade.price
                            
                            if entry_price and entry_price > 0:
                                ts_symbol = trade.symbol
                                
                                trailing_position = create_trailing_stop_for_trade(
                                    trade_id=trade.id,
                                    symbol=ts_symbol,
                                    side=ts_side,
                                    entry_price=entry_price,
                                    quantity=filled_qty or trade.quantity,
                                    account_type=trade.account_type or 'real',
                                    fixed_stop_loss=trade.stop_loss_price,
                                    fixed_take_profit=trade.take_profit_price,
                                    stop_loss_order_id=trade.stop_loss_order_id,
                                    take_profit_order_id=trade.take_profit_order_id,
                                    mode=TrailingStopMode.BALANCED,
                                    timeframe='15'
                                )
                                logger.info(f"🎯 Auto-created trailing stop for {ts_symbol}, side={ts_side}, entry=${entry_price:.2f}")
                        
                        db.session.commit()
                    
                    elif tiger_status in ['cancelled', 'rejected', 'expired', 'invalid']:
                        if tiger_status == 'cancelled' or tiger_status == 'expired':
                            trade.status = OrderStatus.CANCELLED
                        else:
                            trade.status = OrderStatus.REJECTED
                        db.session.commit()
                        logger.info(f"📋 Order {trade.tiger_order_id} ({trade.symbol}) status updated to {tiger_status}")
                        
                except Exception as e:
                    logger.error(f"Error checking order {trade.tiger_order_id}: {str(e)}")
                    continue
                    
    except Exception as e:
        logger.error(f"Error in check_pending_orders: {str(e)}")


def cleanup_stale_pending_orders(app):
    """Mark old PENDING orders (>24h) as EXPIRED to keep database clean"""
    try:
        with app.app_context():
            from app import db
            from models import Trade, OrderStatus
            from datetime import datetime, timedelta
            
            cutoff_time = datetime.utcnow() - timedelta(hours=24)
            stale_orders = Trade.query.filter(
                Trade.status == OrderStatus.PENDING,
                Trade.created_at < cutoff_time
            ).all()
            
            if stale_orders:
                for trade in stale_orders:
                    trade.status = OrderStatus.CANCELLED
                    logger.info(f"🧹 Auto-cancelled stale PENDING order: {trade.symbol} (created {trade.created_at})")
                db.session.commit()
                logger.info(f"🧹 Cleaned up {len(stale_orders)} stale PENDING orders")
    except Exception as e:
        logger.error(f"Error in cleanup_stale_pending_orders: {str(e)}")


def run_trailing_stop_check(app):
    """Run the trailing stop check with app context"""
    global _last_check_time
    
    try:
        check_pending_orders_and_create_trailing_stops(app)
        cleanup_stale_pending_orders(app)
        
        with app.app_context():
            from trailing_stop_engine import process_all_active_positions, get_trailing_stop_config
            from models import TrailingStopPosition
            
            config = get_trailing_stop_config()
            if not config.is_enabled:
                logger.debug("Trailing stop system is disabled")
                return
            
            active_count = TrailingStopPosition.query.filter_by(is_active=True).count()
            if active_count == 0:
                logger.debug("No active trailing stop positions to check")
                return
            
            logger.info(f"🔄 Auto-check: Processing {active_count} active trailing stop positions")
            
            results = process_all_active_positions()
            
            _last_check_time = datetime.utcnow()
            
            actions_taken = [r for r in results if r.get('action')]
            if actions_taken:
                logger.info(f"🔄 Auto-check complete: {len(actions_taken)} actions taken")
                for r in actions_taken:
                    logger.info(f"  - {r.get('symbol')}: {r.get('action')} - {r.get('message')}")
            else:
                logger.debug(f"🔄 Auto-check complete: No actions needed")
                
    except Exception as e:
        logger.error(f"Error in trailing stop auto-check: {str(e)}")


def scheduler_loop(app, interval_seconds=5):
    """Background loop that runs checks periodically (default 5 seconds for real-time Tiger data)"""
    global _scheduler_running
    
    logger.info(f"📊 Trailing stop scheduler started (interval: {interval_seconds}s)")
    
    while _scheduler_running:
        try:
            if is_market_hours():
                run_trailing_stop_check(app)
            else:
                logger.debug("Outside market hours, skipping check")
            
            with app.app_context():
                from trailing_stop_engine import get_trailing_stop_config
                config = get_trailing_stop_config()
                interval_seconds = config.check_interval_seconds or 5
            
        except Exception as e:
            logger.error(f"Scheduler loop error: {str(e)}")
        
        for _ in range(interval_seconds):
            if not _scheduler_running:
                break
            time.sleep(1)
    
    logger.info("📊 Trailing stop scheduler stopped")


def start_scheduler(app, interval_seconds=5):
    """Start the background scheduler thread"""
    global _scheduler_thread, _scheduler_running
    
    if _scheduler_running:
        logger.info("Scheduler already running")
        return False
    
    _scheduler_running = True
    _scheduler_thread = threading.Thread(
        target=scheduler_loop,
        args=(app, interval_seconds),
        daemon=True,
        name="TrailingStopScheduler"
    )
    _scheduler_thread.start()
    
    logger.info(f"📊 Started trailing stop scheduler thread")
    return True


def stop_scheduler():
    """Stop the background scheduler"""
    global _scheduler_running
    
    _scheduler_running = False
    logger.info("📊 Stopping trailing stop scheduler...")


def get_scheduler_status():
    """Get current scheduler status"""
    global _scheduler_running, _last_check_time
    
    return {
        'running': _scheduler_running,
        'last_check': _last_check_time.isoformat() if _last_check_time else None
    }
