import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///trading.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

def run_migrations():
    """Run database migrations to add missing columns"""
    from sqlalchemy import text, inspect
    
    migrations = [
        # TrailingStopPosition: first_entry_price
        ("trailing_stop_position", "first_entry_price", "ALTER TABLE trailing_stop_position ADD COLUMN first_entry_price FLOAT"),
        # TrailingStopConfig: tightening settings
        ("trailing_stop_config", "tighten_threshold", "ALTER TABLE trailing_stop_config ADD COLUMN tighten_threshold FLOAT DEFAULT 0.02"),
        ("trailing_stop_config", "tighten_atr_multiplier", "ALTER TABLE trailing_stop_config ADD COLUMN tighten_atr_multiplier FLOAT DEFAULT 0.6"),
        ("trailing_stop_config", "tighten_trail_pct", "ALTER TABLE trailing_stop_config ADD COLUMN tighten_trail_pct FLOAT DEFAULT 0.005"),
    ]
    
    inspector = inspect(db.engine)
    
    for table_name, column_name, sql in migrations:
        try:
            if table_name in inspector.get_table_names():
                columns = [col['name'] for col in inspector.get_columns(table_name)]
                if column_name not in columns:
                    db.session.execute(text(sql))
                    db.session.commit()
                    logging.info(f"✅ Migration: Added {column_name} to {table_name}")
        except Exception as e:
            db.session.rollback()
            logging.warning(f"Migration skipped for {table_name}.{column_name}: {e}")
    
    # Update existing config values (data migration)
    try:
        # Update switch_profit_ratio from 0.90 to 0.85 and switch_profit_ratio_strong from 0.95 to 0.90
        db.session.execute(text("""
            UPDATE trailing_stop_config 
            SET switch_profit_ratio = 0.85, switch_profit_ratio_strong = 0.90 
            WHERE switch_profit_ratio = 0.90 AND switch_profit_ratio_strong = 0.95
        """))
        db.session.commit()
        logging.info("✅ Updated switch_profit_ratio to 0.85 and switch_profit_ratio_strong to 0.90")
    except Exception as e:
        db.session.rollback()
        logging.warning(f"Data migration skipped: {e}")

with app.app_context():
    # Import models to ensure tables are created
    import models
    db.create_all()
    
    # Run migrations to add any missing columns
    run_migrations()

# Import routes
from routes import *

# Start trailing stop scheduler (only in main process)
def start_trailing_stop_scheduler():
    try:
        from trailing_stop_scheduler import start_scheduler
        start_scheduler(app, interval_seconds=5)
        logging.info("📊 Trailing stop auto-scheduler initialized")
    except Exception as e:
        logging.error(f"Failed to start trailing stop scheduler: {str(e)}")

# Start scheduler when app initializes
start_trailing_stop_scheduler()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
