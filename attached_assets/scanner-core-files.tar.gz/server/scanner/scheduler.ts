import cron, { ScheduledTask } from "node-cron";
import * as scanner from "./scanner-core";
import { runAllActiveStrategiesWithTracking, SignalStateChange, AuxiliaryMatchInfo } from "./strategy-engine";
import { sendScanResultsToDiscord } from "./discord-notifier";
import { ensureCalendarLoaded } from "./market-time";

interface SchedulerState {
  isRunning: boolean;
  lastRun: Record<string, Date | null>;
  nextRun: Record<string, Date | null>;
  results: Record<string, { matches: number; newEntries: number; timestamp: Date }>;
  errors: Record<string, string>;
  latestNewEntries: SignalStateChange[];
  // Auxiliary matches from other timeframes for the most recent scan
  latestAuxiliaryMatches: AuxiliaryMatchInfo[];
}

const state: SchedulerState = {
  isRunning: false,
  lastRun: {
    "5Min": null,
    "15Min": null,
    "1Hour": null,
    "4Hour": null,
  },
  nextRun: {
    "5Min": null,
    "15Min": null,
    "1Hour": null,
    "4Hour": null,
  },
  results: {},
  errors: {},
  latestNewEntries: [],
  latestAuxiliaryMatches: [],
};

const scheduledTasks: Record<string, ScheduledTask> = {};
let globalScanLock = false;

function updateNextRun(timeframe: string): void {
  const now = new Date();
  const intervals: Record<string, number> = {
    "5Min": 5 * 60 * 1000,
    "15Min": 15 * 60 * 1000,
    "1Hour": 60 * 60 * 1000,
    "4Hour": 4 * 60 * 60 * 1000,
  };
  const interval = intervals[timeframe] || 15 * 60 * 1000;
  state.nextRun[timeframe] = new Date(Math.ceil(now.getTime() / interval) * interval);
}

const scanQueue: Array<{ timeframe: string; resolve: () => void }> = [];

async function processQueue(): Promise<void> {
  if (globalScanLock) return;
  const next = scanQueue.shift();
  if (!next) return;
  
  globalScanLock = true;
  try {
    await executeScan(next.timeframe);
  } finally {
    globalScanLock = false;
    next.resolve();
    if (scanQueue.length > 0) {
      processQueue();
    }
  }
}

async function runTimeframeScan(timeframe: string): Promise<void> {
  const alreadyQueued = scanQueue.some(q => q.timeframe === timeframe);
  if (alreadyQueued || (globalScanLock && scanQueue.length > 0 && scanQueue.some(q => q.timeframe === timeframe))) {
    console.log(`[Scheduler] ${timeframe} scan already queued, skipping`);
    return;
  }
  
  return new Promise<void>((resolve) => {
    scanQueue.push({ timeframe, resolve });
    processQueue();
  });
}

async function executeScan(timeframe: string): Promise<void> {
  console.log(`[Scheduler] Starting ${timeframe} scan at ${new Date().toISOString()}`);
  
  try {
    const watchlist = await scanner.getActiveWatchlist();
    console.log(`[Scheduler] Scanning ${watchlist.length} symbols for ${timeframe}`);
    
    const startTime = Date.now();
    await scanner.updateBatchIncremental(watchlist, timeframe);
    
    let processedCount = 0;
    let errorCount = 0;
    
    for (const symbol of watchlist) {
      try {
        await scanner.scanSymbolIndicatorsOnly(symbol, timeframe);
        processedCount++;
      } catch (error) {
        errorCount++;
        console.error(`[Scheduler] Error calculating indicators for ${symbol} ${timeframe}:`, error);
      }
    }
    
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[Scheduler] ${timeframe} data+indicators complete in ${elapsed}s: ${processedCount} success, ${errorCount} errors`);
    
    const trackingResult = await runAllActiveStrategiesWithTracking(timeframe);
    
    let totalMatches = 0;
    trackingResult.allMatches.forEach((r) => {
      totalMatches += r.matches?.length || 0;
    });
    
    state.lastRun[timeframe] = new Date();
    state.results[timeframe] = {
      matches: totalMatches,
      newEntries: trackingResult.newEntries.length,
      timestamp: new Date(),
    };
    
    if (trackingResult.newEntries.length > 0) {
      state.latestNewEntries = [...trackingResult.newEntries, ...state.latestNewEntries].slice(0, 20);
    }
    
    // Store auxiliary matches from other timeframes (for decision support)
    state.latestAuxiliaryMatches = trackingResult.auxiliaryMatches;
    
    delete state.errors[timeframe];
    
    updateNextRun(timeframe);
    
    const auxInfo = trackingResult.auxiliaryMatches.map(a => `${a.timeframe}:${a.matches.length}`).join(", ");
    console.log(`[Scheduler] ${timeframe} scan complete. Matches: ${totalMatches}, New entries: ${trackingResult.newEntries.length}, Exits: ${trackingResult.exits.length}, Aux: [${auxInfo}]`);
    
    // Send results to Discord (only NEW entries for current timeframe, not continuing)
    await sendScanResultsToDiscord(
      timeframe,
      trackingResult.newEntries,
      trackingResult.auxiliaryMatches
    );
    
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    state.errors[timeframe] = errorMsg;
    console.error(`[Scheduler] ${timeframe} scan failed:`, errorMsg);
  }
}

let startupCheckComplete = false;

async function runStartupCheck(): Promise<void> {
  console.log("[Scheduler] Running startup data completeness check...");
  try {
    await ensureCalendarLoaded();
    const watchlist = await scanner.getActiveWatchlist();
    if (watchlist.length === 0) {
      console.log("[Scheduler] No symbols in watchlist, skipping startup check");
      startupCheckComplete = true;
      return;
    }

    for (const tf of ["5Min", "15Min", "1Hour", "4Hour"]) {
      console.log(`[Scheduler] Checking ${tf} data completeness...`);
      const statuses = await scanner.checkDataCompleteness(watchlist, tf);
      const needsWork = statuses.filter((s) => s.status !== "ok");
      if (needsWork.length > 0) {
        const backfill = needsWork.filter((s) => s.status === "backfill").length;
        const incremental = needsWork.filter((s) => s.status === "incremental").length;
        console.log(`[Scheduler] ${tf}: ${backfill} need backfill, ${incremental} need incremental update`);
        await scanner.updateBatchIncremental(watchlist, tf);
      } else {
        console.log(`[Scheduler] ${tf}: all ${watchlist.length} symbols up-to-date`);
      }
    }

    const postCheck = await scanner.checkDataCompleteness(watchlist, "4Hour");
    const stillMissing = postCheck.filter((s) => s.status === "backfill");
    if (stillMissing.length > 0) {
      console.warn(`[Scheduler] Post-check: ${stillMissing.length} symbols still need 4Hour backfill after startup check: ${stillMissing.map(s => s.symbol).join(", ")}`);
    }

    startupCheckComplete = true;
    console.log("[Scheduler] Startup data completeness check done");
  } catch (error) {
    console.error("[Scheduler] Startup check failed:", error);
    startupCheckComplete = true;
  }
}

export function startScheduler(): void {
  if (state.isRunning) {
    console.log("[Scheduler] Already running");
    return;
  }

  console.log("[Scheduler] Starting automated scanner scheduler...");

  runStartupCheck().catch((err) => {
    console.error("[Scheduler] Startup check error:", err);
  });

  scheduledTasks["5Min"] = cron.schedule("*/5 * * * *", async () => {
    if (!startupCheckComplete || !isTimeframeActive("5Min")) return;
    await runTimeframeScan("5Min");
  });

  scheduledTasks["15Min"] = cron.schedule("*/15 * * * *", async () => {
    if (!startupCheckComplete || !isTimeframeActive("15Min")) return;
    await runTimeframeScan("15Min");
  });

  scheduledTasks["1Hour"] = cron.schedule("0 * * * *", async () => {
    if (!startupCheckComplete || !isTimeframeActive("1Hour")) return;
    await runTimeframeScan("1Hour");
  });

  scheduledTasks["4Hour"] = cron.schedule("0 */4 * * *", async () => {
    if (!startupCheckComplete || !isTimeframeActive("4Hour")) return;
    await runTimeframeScan("4Hour");
  });

  scheduledTasks["cleanup"] = cron.schedule("0 3 * * *", async () => {
    console.log("[Scheduler] Running daily cleanup...");
    try {
      await scanner.cleanupOldData(7);
    } catch (error) {
      console.error("[Scheduler] Cleanup failed:", error);
    }
  });

  state.isRunning = true;
  
  const now = new Date();
  state.nextRun["5Min"] = new Date(Math.ceil(now.getTime() / (5 * 60 * 1000)) * (5 * 60 * 1000));
  state.nextRun["15Min"] = new Date(Math.ceil(now.getTime() / (15 * 60 * 1000)) * (15 * 60 * 1000));
  state.nextRun["1Hour"] = new Date(Math.ceil(now.getTime() / (60 * 60 * 1000)) * (60 * 60 * 1000));
  state.nextRun["4Hour"] = new Date(Math.ceil(now.getTime() / (4 * 60 * 60 * 1000)) * (4 * 60 * 60 * 1000));

  console.log("[Scheduler] Scheduler started with schedules:");
  console.log("  - 5Min:  every 5 minutes  (8:30 AM - 5:00 PM ET)");
  console.log("  - 15Min: every 15 minutes (6:30 AM - 6:00 PM ET)");
  console.log("  - 1Hour: every hour at :00 (4:00 AM - 8:00 PM ET)");
  console.log("  - 4Hour: every 4 hours at :00 (4:00 AM - 8:00 PM ET)");
}

export function stopScheduler(): void {
  if (!state.isRunning) {
    console.log("[Scheduler] Not running");
    return;
  }

  Object.values(scheduledTasks).forEach(task => task.stop());
  Object.keys(scheduledTasks).forEach(key => delete scheduledTasks[key]);
  
  state.isRunning = false;
  state.nextRun = {
    "5Min": null,
    "15Min": null,
    "1Hour": null,
    "4Hour": null,
  };

  console.log("[Scheduler] Scheduler stopped");
}

export function getSchedulerStatus(): SchedulerState & { schedules: Record<string, string>; marketOpen: boolean } {
  return {
    ...state,
    marketOpen: isMarketHours(),
    schedules: {
      "5Min": "*/5 * * * * (every 5 min, 8:30 AM - 5:00 PM ET)",
      "15Min": "*/15 * * * * (every 15 min, 6:30 AM - 6:00 PM ET)",
      "1Hour": "0 * * * * (every hour, 4:00 AM - 8:00 PM ET)",
      "4Hour": "0 */4 * * * (every 4 hours, 4:00 AM - 8:00 PM ET)",
    },
  };
}

export async function triggerManualScan(timeframe?: string): Promise<{ 
  timeframe: string; 
  matches: number;
  newEntries: number;
}[]> {
  const results: { timeframe: string; matches: number; newEntries: number }[] = [];
  
  if (timeframe) {
    await runTimeframeScan(timeframe);
    results.push({ 
      timeframe, 
      matches: state.results[timeframe]?.matches || 0,
      newEntries: state.results[timeframe]?.newEntries || 0,
    });
  } else {
    for (const tf of ["5Min", "15Min", "1Hour", "4Hour"]) {
      await runTimeframeScan(tf);
      results.push({ 
        timeframe: tf, 
        matches: state.results[tf]?.matches || 0,
        newEntries: state.results[tf]?.newEntries || 0,
      });
    }
  }
  
  return results;
}

export function getLatestNewEntries(): SignalStateChange[] {
  return state.latestNewEntries;
}

export function getLatestAuxiliaryMatches(): AuxiliaryMatchInfo[] {
  return state.latestAuxiliaryMatches;
}

const TIMEFRAME_HOURS: Record<string, { open: number; close: number; label: string }> = {
  "5Min":  { open: 8 * 60 + 30, close: 17 * 60, label: "8:30 AM - 5:00 PM ET" },
  "15Min": { open: 6 * 60 + 30, close: 18 * 60, label: "6:30 AM - 6:00 PM ET" },
  "1Hour": { open: 4 * 60,      close: 20 * 60, label: "4:00 AM - 8:00 PM ET" },
  "4Hour": { open: 4 * 60,      close: 20 * 60, label: "4:00 AM - 8:00 PM ET" },
};

function isTimeframeActive(timeframe: string): boolean {
  const now = new Date();
  const nyTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const day = nyTime.getDay();
  if (day === 0 || day === 6) return false;

  const timeInMinutes = nyTime.getHours() * 60 + nyTime.getMinutes();
  const hours = TIMEFRAME_HOURS[timeframe];
  if (!hours) return false;

  return timeInMinutes >= hours.open && timeInMinutes <= hours.close;
}

export function isMarketHours(): boolean {
  return isTimeframeActive("1Hour");
}
