const ALPACA_DATA_URL = "https://data.alpaca.markets/v2";
const ALPACA_TRADING_URL = "https://paper-api.alpaca.markets/v2";

interface TradingDay {
  date: string;
  open: string;
  close: string;
}

let tradingCalendarCache: TradingDay[] = [];
let calendarLastFetched: Date | null = null;

const TIMEFRAMES = ["5Min", "15Min", "1Hour", "4Hour"] as const;
type Timeframe = typeof TIMEFRAMES[number];

const TIMEFRAME_MINUTES: Record<string, number> = {
  "5Min": 5,
  "15Min": 15,
  "1Hour": 60,
  "4Hour": 240,
};

const SESSION_START_MINUTES = 4 * 60;
const SESSION_END_MINUTES = 20 * 60;

const LAST_BAR_OFFSET: Record<string, number> = {
  "5Min": 19 * 60 + 55,
  "15Min": 19 * 60 + 45,
  "1Hour": 19 * 60,
  "4Hour": 16 * 60,
};

export async function loadTradingCalendar(): Promise<void> {
  try {
    const apiKey = process.env.strategytest_apikey;
    const secretKey = process.env.strategytest_SECRETkey;

    if (!apiKey || !secretKey) {
      console.warn("[MarketTime] No API keys, using weekend-only calendar");
      return;
    }

    const now = new Date();
    const startDate = new Date(now);
    startDate.setFullYear(startDate.getFullYear() - 1);
    const endDate = new Date(now);
    endDate.setMonth(endDate.getMonth() + 3);

    const url = `${ALPACA_TRADING_URL}/calendar?start=${startDate.toISOString().split("T")[0]}&end=${endDate.toISOString().split("T")[0]}`;

    const response = await fetch(url, {
      headers: {
        "APCA-API-KEY-ID": apiKey,
        "APCA-API-SECRET-KEY": secretKey,
      },
    });

    if (!response.ok) {
      throw new Error(`Calendar API error: ${response.status}`);
    }

    tradingCalendarCache = await response.json();
    calendarLastFetched = new Date();
    console.log(`[MarketTime] Loaded ${tradingCalendarCache.length} trading days`);
  } catch (error) {
    console.error("[MarketTime] Failed to load trading calendar:", error);
  }
}

function isTradingDay(dateStr: string): boolean {
  if (tradingCalendarCache.length > 0) {
    return tradingCalendarCache.some((d) => d.date === dateStr);
  }
  const date = new Date(dateStr + "T12:00:00Z");
  const day = date.getUTCDay();
  return day !== 0 && day !== 6;
}

function getNYTime(now?: Date): Date {
  const d = now || new Date();
  const nyStr = d.toLocaleString("en-US", { timeZone: "America/New_York" });
  return new Date(nyStr);
}

function formatDateStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function getPreviousTradingDay(fromDateStr: string): string | null {
  if (tradingCalendarCache.length > 0) {
    const sorted = tradingCalendarCache
      .filter((d) => d.date < fromDateStr)
      .sort((a, b) => b.date.localeCompare(a.date));
    return sorted.length > 0 ? sorted[0].date : null;
  }

  const date = new Date(fromDateStr + "T12:00:00Z");
  for (let i = 1; i <= 10; i++) {
    const prev = new Date(date);
    prev.setUTCDate(prev.getUTCDate() - i);
    const prevStr = formatDateStr(prev);
    if (isTradingDay(prevStr)) {
      return prevStr;
    }
  }
  return null;
}

function dateStrToUTCDate(dateStr: string, hoursET: number, minutesET: number): Date {
  const localStr = `${dateStr}T${String(hoursET).padStart(2, "0")}:${String(minutesET).padStart(2, "0")}:00`;
  const nyDate = new Date(localStr);
  const utcStr = new Date(
    nyDate.toLocaleString("en-US", { timeZone: "America/New_York" })
  );
  const offset = nyDate.getTime() - utcStr.getTime();
  return new Date(nyDate.getTime() + offset);
}

function etToUTC(dateStr: string, totalMinutesET: number): Date {
  const hours = Math.floor(totalMinutesET / 60);
  const minutes = totalMinutesET % 60;
  const etStr = `${dateStr}T${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:00`;

  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });

  const targetET = new Date(etStr);
  const parts = formatter.formatToParts(targetET);
  const getPart = (type: string) => parts.find((p) => p.type === type)?.value || "";
  const nyParsed = new Date(
    `${getPart("year")}-${getPart("month")}-${getPart("day")}T${getPart("hour")}:${getPart("minute")}:${getPart("second")}`
  );
  const diff = targetET.getTime() - nyParsed.getTime();
  return new Date(targetET.getTime() + diff);
}

export function getExpectedLatestBar(
  timeframe: string,
  now?: Date
): { expectedTime: Date; isTradingNow: boolean } | null {
  const ny = getNYTime(now);
  const todayStr = formatDateStr(ny);
  const currentMinutes = ny.getHours() * 60 + ny.getMinutes();
  const tfMinutes = TIMEFRAME_MINUTES[timeframe];

  if (!tfMinutes) return null;

  const todayIsTrading = isTradingDay(todayStr);

  if (todayIsTrading && currentMinutes >= SESSION_START_MINUTES && currentMinutes < SESSION_END_MINUTES) {
    const minutesSinceOpen = currentMinutes - SESSION_START_MINUTES;
    const barsCompleted = Math.floor(minutesSinceOpen / tfMinutes);
    const latestBarMinutes = SESSION_START_MINUTES + barsCompleted * tfMinutes;

    return {
      expectedTime: etToUTC(todayStr, latestBarMinutes),
      isTradingNow: true,
    };
  }

  let lastTradingDateStr: string | null;
  if (todayIsTrading && currentMinutes >= SESSION_END_MINUTES) {
    lastTradingDateStr = todayStr;
  } else {
    lastTradingDateStr = getPreviousTradingDay(todayStr);
  }

  if (!lastTradingDateStr) return null;

  const lastBarMinutes = LAST_BAR_OFFSET[timeframe];
  return {
    expectedTime: etToUTC(lastTradingDateStr, lastBarMinutes),
    isTradingNow: false,
  };
}

export function isDataStale(
  latestBarTime: Date | null,
  barCount: number,
  timeframe: string,
  now?: Date
): "ok" | "incremental" | "backfill" {
  if (!latestBarTime || barCount === 0) {
    return "backfill";
  }

  if (barCount < 510) {
    return "backfill";
  }

  const expected = getExpectedLatestBar(timeframe, now);
  if (!expected) {
    return "ok";
  }

  const diffMs = expected.expectedTime.getTime() - latestBarTime.getTime();
  const tfMinutes = TIMEFRAME_MINUTES[timeframe] || 15;

  if (diffMs <= 0) {
    return "ok";
  }

  const oneTradingDayMs = 16 * 60 * 60 * 1000;
  if (diffMs > oneTradingDayMs) {
    return "backfill";
  }

  return "incremental";
}

export async function ensureCalendarLoaded(): Promise<void> {
  if (
    tradingCalendarCache.length === 0 ||
    !calendarLastFetched ||
    Date.now() - calendarLastFetched.getTime() > 30 * 24 * 60 * 60 * 1000
  ) {
    await loadTradingCalendar();
  }
}

export function getCalendarStatus(): { loaded: boolean; days: number; lastFetched: Date | null } {
  return {
    loaded: tradingCalendarCache.length > 0,
    days: tradingCalendarCache.length,
    lastFetched: calendarLastFetched,
  };
}
